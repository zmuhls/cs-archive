# Columbia County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 34)

**Extraction Method:** full

**Processed:** 2026-01-01T19:33:56.759289

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Hillsdale | 5 November 1897 |  | 5 |  |
| 1 | New Lebanon | 22 May 1911 |  | 6 |  |
| 8 | Canaan | 29 January 1914 | March 1914 | 2 | Not legal support |
| 8 | Copake | 27 June 1919 |  | 5 |  |
| 2 | Germantown | 3 May 1922 |  | 5 |  |
| 1 | Stockport | 30 July 1924 |  | 3 |  |
| 1 5 | Claverack & Grempot | 23 June 1903 |  | 1 | see order |
| 1 | Austerlitz |  |  |  |  |
