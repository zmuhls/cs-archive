# Dutchess County County

**Table Type:** Unknown

**Source:** District-Consolidation-Data_100-116.pdf (Page 49)

**Extraction Method:** full

**Processed:** 2026-01-01T19:36:32.594600

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| NYS #2 1,2,3,4,6,7,8,9 | Clover Union Vale | Effective date Dec 31, 1946 | 2 Apr |  |  |
| CRS | NYS #2 1,2,3,4,5,6,7,8,9 | Laid out June 5, 1950 Meeting held June 27, 1950 | CRS |  | last meeting Monday |
| C.S. #8 7 2 | North East Cons with 6 North East, U.T. | Aug 7, 1952 | Apr 11, 1951 | 6 North East | Amnie |
|  |  | U.T.S. | June 30, 1953 | 2 Dore |  |
