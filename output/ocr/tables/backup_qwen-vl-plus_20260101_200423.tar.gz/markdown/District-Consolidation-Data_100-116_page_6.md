# Cattaraugus County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 6)

**Extraction Method:** full

**Processed:** 2026-01-01T15:13:30.676700

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 9 | Dayton | 29 January 1901 | 25 March 1901 | 3 |  |
| 1 | Freedom | 12 October 1900 |  | 5 |  |
| 1 | Randolph | 16 November 1888 |  | 9 |  |
| 7 | Yorkshire | 29 August 1893 |  | 3 |  |
| 4 | Carrollton | 13 March 1915 | 13 April 1915 | 3 |  |
| 1 | East Otto | 22 December 1920 |  | 3 |  |
| 10 | Windsale |  |  |  | See affidavit under folder |
