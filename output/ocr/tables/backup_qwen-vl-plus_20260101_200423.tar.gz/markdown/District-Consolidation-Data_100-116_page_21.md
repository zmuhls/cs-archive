# County County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 21)

**Extraction Method:** chunked

**Processed:** 2026-01-01T18:23:33.921357

---

| No. of dist | NAME OF TOWN | DATE OF SCHOOL-MEETING ORGANIZING-DISTRICT | DATE ON WHICH PAPERS WERE APPROVED AT DEPARTMENT | No. new dist | REMARKS |
| --- | --- | --- | --- | --- | --- |
| 6,7,9 | X Van Etten | 14 July 1914 | 6 13,725 15 | 9 Van Etten |  |
| 14 8 | X Van Etten | 1 August 1919 | 12 13,325 15 | 1 Van Etten |  |
| 14 4 | X Van Etten | 15 June 1920 | 8 14,929 14 | 1 Van Etten | at Ashland |
| 14 3 | X Ashland | 28 August 1925 | 24 17,591 25 | 1 Van Etten |  |
| 1 | Van Etten |  |  | Van Etten & Spencer |  |
| 2 | Van Etten |  |  | Van Etten & Baldwin |  |
| 5 | Van Etten |  |  | Van Etten & Newfield |  |
| 11 | Van Etten |  |  | Van Etten & Spur |  |
| 15 | Baldwin |  |  | Baldwin, Erwin & Chemung |  |
| 19 | Barton |  |  | Barton, Baldwin & Chemung |  |
| 24 | Barton |  |  | Barton & Van Etten |  |
| 7 | Newfield |  |  | Newfield, Van Etten & Bayuga |  |
| 1 | Van Etten | 14 July 1915 | 6 13,725 | 9 Van Etten |  |
| 8 | Van Etten | 1 August 1919 | 12 39,950 | 1 Van Etten |  |
| 4 | Van Etten | 15 June 1920 | 8 316,229 | 1 Van Etten | of Ashland |
| 3 | Ashland | 28 August 1925 | 29 298,679 | 1 Van Etten | at Van Etten, |
|  |  |  |  | Baldwin, Erin | Chemung Co., Spencer, Barton, |
|  |  |  |  | Baldwin, Chemung | Sunger Co., Newfield, Jamphe, |
|  |  |  |  | Co., Cayuta, Schuyler Co. |  |
|  |  | Laid out 31 Aug 1938 |  | 10 Catlin |  |
|  |  | Meeting held 15 Sept 1938 |  |  |  |
|  |  | Designation of dist. 19 Sept 1938 |  |  |  |
|  |  | 120 Jan. 1943 to take effect 1 May 1943 |  | 10 Catlin |  |
|  |  | 27 March 1950 to take effect 1st July 1950 |  | Horseheads & Chenango |  |
|  |  | Laid out Mar 27, 1950 |  |  |  |
|  |  | Meeting held Apr 27, 1950 |  |  |  |
