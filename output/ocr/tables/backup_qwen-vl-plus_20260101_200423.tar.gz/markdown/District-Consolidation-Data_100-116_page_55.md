# Essex County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 55)

**Extraction Method:** full

**Processed:** 2026-01-01T19:37:22.268302

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Schroon | 3 April 1891 |  | 3 |  |
| 1 | Keene | 1 May 1916 |  | 5 |  |
| 2 | Moriah | 26 June 1920 |  | 5 |  |
| 1 | Minerva | 18 July 1922 |  | 3 |  |
