# Madison County

**Table Type:** Central Rural Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 93)

**Extraction Method:** full

**Processed:** 2026-01-01T19:45:47.412720

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 23-8 | Eaton | 15 April 1935 |  | 1 | Eaton Nelson Lebanon |
| 41-14 | Eaton Lebanon | 2 May 1935 | 18 June 1935 | 2 | Zimmer Smithfield Madison Co |
| 2-6-6 | Nelson Eaton Zinner Smithfield |  |  | 3 | Stockbridge |
| 4 | Eaton Smithfield Stockbridge |  |  | 4 |  |
| 21 | Brookfield | 15 July 1935 | 15 October 1935 | 5 | Brookfield |
| 9 | Pompey | 19 September 1935 | 31 December 1935 | 6 | Cazenovia |
| 20 | Cazenovia | 10 May 1937 | 14 August 1937 | 7 | Cazenovia |
| 24 | Hamilton | 5 May 1937 | 10 August 1937 | 8 | Hamilton |
| 9 | Seabrook | 13 May 1937 | 1 August 1937 | 9 | Hamilton |
| 19 | Brookfield | 28 August 1937 | 28 November 1937 | 10 | Brookfield |
| 8 | Shenango (Chenango) | 1 July 1937 | 1 October 1937 | 11 | Sherburne (Chenango) |
| 19 | Hamilton | 27 April 1937 | 21 July 1937 | 12 | Brookfield |
| 16 | Hamilton | 16 May 1938 | 1 September 1938 | 13 | Eaton |
| 3 | Eaton Smithfield | 11 June 1938 | 10 September 1938 | 14 | Eaton |
| 3 | Eaton Smithfield | 21 June 1938 | 20 September 1938 | 15 | Eaton |
| Part of 5 Brookfield or R.S. 9 Brookfield | Eaton | 1 August 1938 | 5 November 1938 | 16 | Eaton |
| 9 | Sangerfield | 9 May 1939 | 9 August 1939 | 17 | Sangerfield |
| 20 | Brookfield | 3 June 1940 | 2 September 1940 | 18 | Brookfield |
| 9 | Henrietta | 24 June 1940 | 30 November 1940 | 19 | Henrietta |
| 10 | Cazenovia | 27 August 1940 | 30 November 1940 | 20 | Cazenovia |
| 27 | Hamilton | 27 August 1940 | 13 September 1941 | 21 | Hamilton |
| 24 | Henrietta | 12 June 1941 | 13 September 1941 | 22 | Cazenovia |
| 12 | Cazenovia | 12 June 1941 | 13 September 1941 | 23 | Cazenovia |
| 15 | Cazenovia | 15 May 1941 | 30 August 1941 | 24 | Cazenovia |
| 11 | Stockbridge | 12 January 1941 | 10 July 1941 | 25 | Madison |
| 10 | Nelson Georgetown | 23 August 1941 | 1 December 1941 | 26 | Georgetown |
| 10 | Cazenovia Sullivan | 30 August 1941 | 15 December 1941 | 27 | Cazenovia |
| 1 | Cazenovia Binghamton | 1 April 1943 | 5 July 1943 | 28 | Cazenovia |
| 6 | Stockbridge | 6 May 1943 | 9 August 1943 | 29 | Stockbridge |
| 31 | Stockbridge | 31 March 1944 | 1 July 1944 | 30 | Ge Ayer |
| 15 | Stockbridge | 15 March 1944 | 1 July 1944 | 31 | Stockbridge |
| 10 | Stockbridge | 15 March 1944 | 1 September 1944 | 32 | Stockbridge |
| 2 | Smithfield Stockbridge | 15 March 1944 | 1 September 1944 | 33 | Eaton |
| 1 | Smithfield Stockbridge | 15 March 1944 | 1 September 1944 | 34 | Stockbridge |
