# County County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 17)

**Extraction Method:** chunked

**Processed:** 2026-01-01T16:47:50.487402

---

| No. of Dis | NAME OF TOWN | DATE OF SCHOOL MEETING | DATE ON WHICH PAPERS WERE APPROVED AT DEPARTMENT | No. new dist. |
| --- | --- | --- | --- | --- |
| 749 | Harmony | 30 September 1913 | 7 12-13 1913 | 9 Harmony |
| 12 | Chautauqua | 12 October 1914 | 12 1914 | 3 Chautauqua |
| 3 | Chautauqua | 14 November 1918 | 15 1918 | 3 Chautauqua |
| 7410 | Stockton | 15 August 1918 | 2 1918 | 7 Stockton |
| 245 | Ellington | 23 October 1924 | 2 1924 | 2 Ellington |
| 243 | Stockton | 31 December 1927 | 8 1927 | 3 Stockton |
| 6+8 | Ellery | 6 July 1926 | 12 1926 | 6 Ellery |
|  | Stockton | 31 July 1926 | 25 1926 | 5 Stockton |
| 3+7 | Clymer | 20 May 1935 | 22 1935 | 3 Clymer |
| C.R.S. | Clymer | Raid out 10 October 1935 |  | C.R.S. 1 Clymer, Harmony and French Creek, Chautauqua Co. |
| 1,2,3,4,5 | Chautauqua, Harmony, French Creek, Clymer | Meeting held 21 October 1935 | 24 October 1935 | C.R.S. 1 Sherman, Chautauqua, Minor, Ripley, Westfield, Clymer, French Creek, Chautauqua Co. |
| 1,2,3,4,5,6 | Sherman, Clymer, No Harmony | Laid out 25 November 1935 | 10 December 1935 | C.R.S. 1 Sherman, Chautauqua, Minor, Ripley, Westfield, Clymer, French Creek, Chautauqua Co. |
