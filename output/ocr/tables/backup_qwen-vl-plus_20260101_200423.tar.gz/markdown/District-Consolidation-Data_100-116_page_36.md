# Columbia County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 36)

**Extraction Method:** full

**Processed:** 2026-01-01T19:34:15.578521

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 14 2 | New Lebanon | 31 August 1914 | 13 July 1915 | 1 | New Lebanon |
| 88 10 | Ghent | 10 May 1915 | 28 July 1915 | 3 | Ghent |
| 34 10 | Ghent | 5 May 1915 | 31 July 1915 | 3 | Ghent |
| 14 2 | New Lebanon | 29 July 1916 | 15 May 1916 | 1 | New Lebanon |
| 4 7 8 | Copake | 2d April 1919 | 11 April 1919 | 6 | Copake |
| 64 13 | Chatham | 7 May 1921 | 21 April 1921 | 15 | Chatham |
| 2 4 5 | V Germantown 4 30 | 17 November 1921 | 22 November 1921 | 2 | Germantown Clermont |
|  |  |  |  |  | C.R.S. New Lebanon 1d also above consol. dists. 2 New Lebanon + New Lob. (formerly 12) |
| 14 6 | New Lebanon | 5 February 1929 | 9 January 1928 | 1 | New Lebanon |
|  |  |  | Laid out 9 Jl. 1928 | 1 | Canaan |
|  |  |  | Design. dist 25 Jl. 1928 | 7 | 100 10 010 |
|  |  |  | 1 3030 03-1* | 1 |  |
|  |  |  |  |  | Willsdale + Copake C.R.S. |
| 37 89 10 | Willsdale | 6 February 1931 | Clawack, Taghkanic | 1 | Willsdale, Copake |
|  | Clawack |  | Meeting held 19 Jl. 1928 | 1 | Clawack, Taghkanic |
|  | Anaram + Nw East |  | 31 February 1931 | 1 | Anaram + Nw East |
|  | Copake + Taghkanic |  | Designation allahat (Col. co.) | 7 | Anaram + Taghkanic |
|  | Willsdale + Anaram |  | of district 9 Mr. 1931 | 3 | The East (Out. co.) |
|  | Copake + Zaghkani |  |  | 3d | Willsdale |
|  | Taghkanic + Copake |  |  | 3 | Ballatin |
|  | Claverack (24 Cot.) |  |  | 1 |  |
| X 6 | Elephantown (2d Rmnd.) | 29 May 1931 | 1 September 1930 | 1 | New Lebanon |
| 2d 3 | Germantown + Clermont | 7 May 1931 | 16 Jl. 1931 | 2 | Germantown |
| 1 3 | Germantown |  | Laid out 19 Jl. 1931 | Designation plus 1/31, and Clermont | 1 |
| 105 3 | New Lebanon | 28 May 1937 | 30 August 1937 | 1 | New Lebanon |
|  |  | 19 June 1942 | 17 September 1942 | 1 | C.R.S. |
| C.R.S. | 1 | New Lebanon | 2 5 1943 | Reaport June 4 1946 | 1 |
|  | 6 | Chatham |  | Meeting of June 26, 1946 | 2 |
|  | 18 | Shingletown |  |  | 2 |
|  | 16 | Schodack (Renum. C) | May 23 1913 | (see coud and 9 Chatham) | 1 |
