# Dutchess County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 46)

**Extraction Method:** full

**Processed:** 2026-01-01T19:36:08.405283

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 4 | Washington | 18 April 1892 |  | 3 |  |
| 10 | Stanford | 7 June 1921 |  | 3 |  |
| 4 | Poughkeepsie | 30 October 1875 |  | 3 |  |
