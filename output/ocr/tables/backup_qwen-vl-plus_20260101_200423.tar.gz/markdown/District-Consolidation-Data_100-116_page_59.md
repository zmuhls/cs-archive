# Franklin County County

**Table Type:** Town School Units

**Source:** District-Consolidation-Data_100-116.pdf (Page 59)

**Extraction Method:** full

**Processed:** 2026-01-01T19:38:00.660725

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Moira | 3 4 9 10 |  | U.F.S. 1 and |  |
| 2 | Moira | 5 6 7 8 11 |  | U.F.S. 2 |  |
