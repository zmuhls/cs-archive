# Erie County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 51)

**Extraction Method:** full

**Processed:** 2026-01-01T19:36:57.483304

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Sloan | 6 April 1914 | 9 April 1914 | 9 | Cheektowaga |
|  | Checktowagg | 27 April 1914 | 12 April 1914 |  |  |
|  | East Hamburg | 15 March 1915 | 12 March 1915 | 1 | East Hamburg |
| 2 | Amherst | 1 May 1914 | 1 May 1914 | 1 | Amherst |
|  | Tonawanda | 1 August 1914 | 1 August 1914 | 1 | Tonawanda |
|  | Evans | 27 September 1919 | 10 October 1919 | 1 | Evans |
| 3 | Newstead | 8 June 1921 | 1 August 1921 | 1 | Newstead |
|  | Collins | 8 July 1921 | 1 August 1921 | 1 | Collins |
|  | Tonawanda | 30 April 1924 | 1 August 1924 | 1 | Tonawanda |
| 4 | Amherst | 2 April 1929 | 1 April 1929 | 1 | Amherst |
|  | Aurora | 23 January 1930 | 12 January 1930 | 1 | Aurora |
| 5 | Holland | 30 June 1932 | 12 September 1932 | 1 | Holland |
|  | Holland | 18 June 1935 | 18 September 1935 | 1 | Holland |
|  | Tonawanda | 7 June 1938 | 6 September 1938 | 1 | Tonawanda |
|  | Holland | 10 November 1938 | 30 June 1939 | 1 | Holland |
|  | Holland | 10 November 1938 | 30 June 1939 | 1 | Holland |
| 6 | Eden | 15 September 1938 | 3 October 1938 | 1 | Eden |
|  | Evans | 1 October 1938 | 3 October 1938 | 1 | Evans |
|  | Bortner | 1 October 1938 | 3 October 1938 | 1 | Bortner |
|  | Collins | 1 October 1938 | 3 October 1938 | 1 | Collins |
| 7 | Concord | 29 May 1941 | 19 July 1941 | 1 | Concord |
|  | Gardner | 29 May 1941 | 19 July 1941 | 1 | Gardner |
|  | Sardinia | 29 May 1941 | 19 July 1941 | 1 | Sardinia |
| 8 | Arcade | 23 June 1943 | 1 July 1943 | 1 | Arcade |
|  | Arcade | 18 June 1943 | 20 September 1943 | 1 | Arcade |
|  | Wynona | 18 June 1943 | 20 September 1943 | 1 | Wynona |
|  | Holland | 24 June 1943 | 25 September 1943 | 1 | Holland |
| 9 | Orchard Park | 13 June 1944 | 30 June 1944 | 1 | Orchard Park |
|  | Hamburg | 13 June 1944 | 30 June 1944 | 1 | Hamburg |
|  | Amherst | 13 June 1944 | 30 June 1944 | 1 | Amherst |
|  | Eden | 13 June 1944 | 30 June 1944 | 1 | Eden |
