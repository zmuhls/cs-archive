# Lewis County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 84)

**Extraction Method:** full

**Processed:** 2026-01-01T19:43:49.136169

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| Part of 23 Greghan & 11 Croghan |  | 26 June 1937 | 11 October 1937 | 11 20 | Croghan |
| 9 | Watson | 4 January 1939 to take effect 13 April 1939 |  | 8 | C.R.S. |
| 8 | Martinsburg | 16 July 1940 | 16 October 1940 | 2 | Martinsburg |
| C.R.S. | 2 |  |  | 8 | Montague |
| 6 | Diana | Laid out 12 June 1941 | 29 July 1941 | 1 | Diana Croghan |
| 1,2,3,7,8,10 | Diana Croghan | Meeting held 24 June 1941 |  | Wilna Jefferson Co | Diana Antwerp Wilma |
| 12,14,17 | Diana Antwerp Wilma | Designating dist. |  |  | Wilna Jefferson Co |
| 1+5 | Orecla | 5 June 1941 to take effect 25 September 1941 |  | C.R.S. | Lewis |
| 7 | Lewis | 21 June 1941 | 25 September 1941 | 1 | Lewis |
| 4+7 | Lewis | 21 June 1941 | 25 September 1941 | 1 | Lewis |
| 13 | Lewis | 21 June 1941 | 25 September 1941 | 2 | Highmarket |
| 1+5 | Lewis | 18 May 1942 | 20 August 1942 | 8 | Martinsburg |
| 1 | Martinsburg | 24 March 1942 | 30 June 1943 | 1 | Diana |
| 1+5 | Martinsburg | 12 July 1943 | 11 October 1943 | 2 | Lynedale |
| C.R.S. | 2+5+8+1st |  |  | 7 | New Bremen Croghan |
| C.R.S. | 2+5+8+1st |  |  | 13,3,4,6,11,12,13 | New Bremer Croghan |
| C.R.S. | 2+5+8+1st |  |  | 10 | New Bremer Croghan |
| C.R.S. | 2+5+8+1st |  |  | 1+5 | New Bremer |
| C.R.S. | 2+5+8+1st | Hail out June 8, 1945 Meeting held June 27, 1945 |  | 7 | New Bremer |
| 7 | Lynedale Greig (on motion) | Effective date Mar 3, 1947 |  | 6 | Lynedale |
| 13 | Martinsburg C.O. and | Effective date May 20, 1947 |  | 11 | Martinsburg |
| 1 | Montague (com 15 Aug 1949) | Effective date Nov 15, 1949 |  | 6 | Montague |
| 17 | Martinsburg com May 23/49 | Effective date Aug 24, 1949 |  | 15 | Martinsburg |
| 2 | Lewis com they 24/49 | Effective date Aug 27, 1949 |  | 1 | Lewisie |
| 7 | Montague com sid 6 | 7 Oct 1951 |  | 6 | Montague |
