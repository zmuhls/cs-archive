# County County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 63)

**Extraction Method:** full

**Processed:** 2026-01-01T19:39:34.462831

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 2 | Bleecker Mayfield one with dist | 4 | Bleecker Caroga | 1/55 | effective 9/25/55 Bleecker |
