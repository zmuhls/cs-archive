# County County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 53)

**Extraction Method:** full

**Processed:** 2026-01-01T19:37:13.758583

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 6.S. 10 | Aurora cons with Aurora (Village of East Aurora) | Aug 12, 1952 |  | 1 | Aurora |
| 11 | Aurora |  | Aug 5, 1953 (approved) | 1 |  |
| 2 | Aurora |  | Aug 5, 1953 | 1 |  |
| 4 | Aurora |  | Aug 7, 1954 | 1 |  |
| 5 | Aurora |  | Aug 26, 1954 | 1 |  |
| 7 | Aurora |  |  | 1 | Aurora |
