# Delaware County

**Table Type:** Central Rural Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 43)

**Extraction Method:** full

**Processed:** 2026-01-01T19:35:37.491044

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 4 + 1916 | Franklin | 23 May 1930 | 11 Sept 1930 | C.R.S. L. Franklin | No of new dist |
| 24 + 1916 | Ropburg | 9 July 1930 | 12 June 1930 | C.R.S. L. Ropburg | Meeting held 24 June 1930 |
| 23458912 | Hancock | 20 May 1923 | 3 Jan 1931 | C.R.S. L. Hancock | Designation of district as 11 July 1930 |
| 131517 | Tomphina | 18 June 1931 | 24 Oct 1931 | C.R.S. L. Tomphina | Meeting held 24 Oct 1931 |
| 67141518 | Hancock | 24 July 1931 | 24 Oct 1931 | C.R.S. L. Hancock | Designation + Dec 1931 |
| 19 | Tomphina | 15 Aug 1931 | 15 Nov 1931 | C.R.S. L. Hancock | Designation of district as 2nd |
| 6117 | Hancock | 2 July 1932 | 5 Dec 1932 | C.R.S. L. Hancock | Meeting held 2 July 1932 |
| 1119 | Colchester | 26 July 1933 | 27 Oct 1933 | C.R.S. L. Colchester | Designation of district as 19th |
|  | U.S. Dist. Andro | 5 Oct 1933 | 13 Nov 1933 | C.R.S. L. Andro | Laid out 5 Oct 1933, Meeting held 26 Oct 1933, Designation of district 13 Nov 1933 |
|  | C.R.S. Stamford | 3 Oct 1935 | 4 Dec 1935 | C.R.S. L. Stamford | Laid out 3 Oct 1935, Meeting held 11 Nov 1935, Designation of district 4 Dec 1935 |
|  | Delhi | 20 April 1936 | 4 May 1936 | C.R.S. L. Delhi | Laid out 20 April 1936, Meeting held 4 May 1936, Designation of district |
|  | Delhi | 12 July 1937 | 1 Jan 1937 | C.R.S. L. Delhi | Meeting held 15 Sept 1936 to take effect 1 Jan 1937 |
|  | Delhi | 15 Jan 1937 | 1 May 1937 | C.R.S. L. Delhi | Meeting held 21 Jan 1937 |
|  | Delhi | 21 Feb 1937 | 1 July 1937 | C.R.S. L. Delhi | Meeting held 27 Feb 1937 to take effect 1 July 1937 |
|  | Delhi | 1 March 1937 | 1 July 1937 | C.R.S. L. Delhi | Meeting held 1 March 1937 to take effect 1 July 1937 |
|  | Delhi | 3 March 1937 | 1 July 1937 | C.R.S. L. Delhi | Meeting held 3 March 1937 to take effect 1 July 1937 |
|  | Colchester | 1 July 1937 | 1 Oct 1937 | C.R.S. L. Colchester | Meeting held 1 July 1937 to take effect 1 Oct 1937 |
