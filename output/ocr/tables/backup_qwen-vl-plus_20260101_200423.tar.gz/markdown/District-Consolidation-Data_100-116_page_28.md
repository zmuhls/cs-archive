# Chenango County County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 28)

**Extraction Method:** full

**Processed:** 2026-01-01T19:33:14.756746

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 2 | Preston | 1 June 1942 to take effect | 1 Sept 1942 | E.R.S. | 1 Oxford |
| 2 | McDonough | 25 May 1943 | 1 Sept 1943 | E.R.S. | 1 Oxford |
| 2 | Orford | 25 May 1943 | 1 Sept 1943 | E.R.S. | 1 Oxford |
| 1 | Cincinnati (Cnt Co) | 25 May 1943 | 15 Sept 1944 | 1 Cincinnati (Cnt Co) |  |
| 3 | McDonough | 26 June 1944 | 30 Sept 1944 | 3 McDonough |  |
| 4 | German | Effective April 2, 1945 |  | E.R.S. | 1 Greene |
| 5 | German | Effective October 31, 1945 |  | E.R.S. | 1 Atelai |
| 5 | German | Effective November 20, 1945 |  | E.R.S. | 1 Cincinnati |
