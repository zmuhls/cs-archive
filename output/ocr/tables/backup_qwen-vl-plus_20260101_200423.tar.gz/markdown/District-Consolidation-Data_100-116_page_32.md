# Clinton County

**Table Type:** Unknown

**Source:** District-Consolidation-Data_100-116.pdf (Page 32)

**Extraction Method:** full

**Processed:** 2026-01-01T19:33:42.727871

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 5,7914 | Chazy | 17 October 1913 | 5 September 1913 | 5 Chazy | No new dist. |
| 8413 | Altona | 14 August 1915 | 8 September 1915 | 8 Altona | 15-16 |
|  |  | 2.3.9,12.15,14 | 1916 | 1 Chazy & Champlain |  |
|  |  | 6.7.12415 | 6 January 1916 | 1 | Take effect 7 Jan. |
|  |  | 8.9.11 | 20 July 1916 | 8 Moers | Order with Drawn |
|  |  | 12.7.14.15 | 30 July 1921 | 1 | Ellemburg |
|  |  | 10.5 | 16 October 1923 | 1 Peru | No 923 slip to C. & L. 1780 |
|  |  | 20 December 1929 | 29 September 1929 | 1 | Saranac |
|  |  |  |  |  | Boundaries of 11 Peru altered by taking them from all the lands formerly contained in what was prior to Oct. 6, 1923, sch. dist. No 5 Peru. 31 Aug. 1927. New dist. No 8 Peru created. |
| C.R.S. | Saranac | 20 December 1929 | 29 September 1929 | 1 | Saranac |
|  |  | 2.1/3.16 | 19 March 1932 | 1 | Dannemora |
| C.R.S. | Altoma | 13 May 1931 | 25 June 1931 | 1 | Altoma |
| C.R.S. | Altoma & Beckmantown | 13 August 1935 | 29 August 1935 | 1 | Beckmantown |
| C.R.S. | Ausable & Chesterfield | 25 October 1938 | 2 March 1938 | 1 | Ausable, Peru, Chesterfield |
| C.R.S. | Ausable & Penn | 21 September 1935 | 29 June 1936 | 1 | Altona |
| C.R.S. | Moore | 11 June 1936 | 29 June 1936 | 1 | Moore, Champlain, Chazy |
| C.R.S. | Moore | 21 January 1938 | 23 May 1938 | 1 | Moore |
| C.R.S. | Peru | 25 October 1937 | 18 November 1937 | 1 | Peru, Ausable, Saranac, Schuyler Falls, Black Brook |
| C.R.S. | Peru & Ausable | 5 February 1938 | 2 March 1938 | 1 | Ellemburg, Altona, Moers, Clinton |
| C.R.S. | Ellemburg, Altona, Moors | 19 April 1938 | 19 April 1938 | 1 | Schuyler Falls |
| C.R.S. | Ellemburg, Altona, Moors | 19 April 1938 | 19 April 1938 | 1 | Schuyler Falls |
