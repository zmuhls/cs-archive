# Chenango County

**Table Type:** Unknown

**Source:** District-Consolidation-Data_100-116.pdf (Page 27)

**Extraction Method:** chunked

**Processed:** 2026-01-01T19:33:07.174494

---

| No. of Dist | Name of Town | Date of School Meeting | Date on which Papers were Approved | No. of New Dist |
| --- | --- | --- | --- | --- |
| 1,891/12 | Alton & Country | 27 May 1932 | 15 Dec. 1932 | Alton, Coventry, Binghambridge (Chen. co.) |
| 20/11 | Alton & Binghambridge | 17 June 1932 |  | Binghambridge (Broome co.) |
| 5 | Alton & Colville (B. co.) | 15 June 1932 |  | Colville & Sanford (Broome co.) |
| 6 | Alton & Sanfin (B. co.) | 15 June 1932 |  |  |
| 2 | Countryside | 17 June 1932 |  |  |
| 10 | Countryside | 15 June 1932 |  |  |
| 16 | Countryside | 15 June 1932 |  |  |
| 17 | Countryside | 15 June 1932 |  |  |
| 5 | Columbus | 31 Aug. 1933 | 15 Dec. 1933 | Sherburne |
| 1 | Columbus | 31 Aug. 1933 |  | Sherburne |
| C.R.S. | New Berlin |  | 16 June 1935 | New Berlin & Columbus (Chen. co.) |
| 3,9/18/12 | New Berlin | 28 June 1935 | 24 July 1935 | Pittsfield |
