# County County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 62)

**Extraction Method:** full

**Processed:** 2026-01-01T19:39:30.275484

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 2 | Bleecker Mayfield cons with dis | 4 July 1915 | Bleecker George | 483 | effective 7/25/15 |
