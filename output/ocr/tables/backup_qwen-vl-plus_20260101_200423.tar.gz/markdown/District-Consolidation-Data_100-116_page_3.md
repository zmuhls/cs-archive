# Broom County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 3)

**Extraction Method:** full

**Processed:** 2026-01-01T15:11:41.462762

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 548 | Fenton | 6 July 1915 | 5-6 14.300 Consel appealed & dist | 5 Fenton |  |
| 20427 | Colesville | 1 September 1917 | 17-29 19.979 reestablished 31Ag 1915 | 20 Colesville |  |
| 18514 | Sanford | 10 October 1914 | 19 September 1915 to take effect 28Sept | 19 Sanford | After 17 Sanford 4 |
| 18519 | Sanford | 17-19 | 17-19 | 8 Kirkwood |  |
|  | Dickinson & Kirkwood | 30 October 1915 | 8-8 88.278 | 1 Dickinson | n Canklun |
|  | Fenton | 2 February 1917 | 14-2 17.913 New papers recd | 1 Canklun |  |
| 1242 | Conklin | 17 August 1919 | 31 91.950 | 3 Colesville |  |
| 331 | Colesville | 1 September 1919 | 31 91.950 | 3 Colesville |  |
| 147 | Maine | 28 August 1919 | Pendular 19.181 | 1 Maine | Newark Valley |
|  | Part of 15 Richford & 7 List | 13 August 1920 | all Ag 1920 | 7 List | Richford |
|  | Union (in a Vill) | 29 April 1921 | 3- 61.947 Extra | 1 Union | List |
|  | Brittis Richford & 7 List | 28 August 1924 to take effect 19Ag 1924 | 58.521 | 1 Mindao | Colesville |
|  | Mindao | 29 May 1931 | 27 May 1932 Meeting | 1 Mindao | Colesville |
|  | Colesville & Windso | 14 December 1934 | 27 December 1934 Designation of district | 1 Colesville, Denton, Sanford, Windosan (Chernege) | Chernege Co. |
|  | Colesville | 25 | 25 | 1 Triange, Lisle | Barker, Chenango |
|  | Colesville & Windso | 13 | 13 | Nanticoke + Maine | Broom Co., Marathon |
|  | Colesville | 16 | 16 | F Willett, Scotland Co. | Greene & Smithville |
|  | Colesville | 16 | 16 | F Willett, Smithville | Chenango Co. |
|  | Colesville | 16 | 16 | F Willett, Smithville | Chenango Co. |
