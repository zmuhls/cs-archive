# Onondaga County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 114)

**Extraction Method:** full

**Processed:** 2026-01-01T19:56:07.868134

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 5,722 | Onondaga | 27 March 1916 | 5 July 1916 | 5 | No new district. |
| 11/3 | Manlius | 7 August 1918 | 22 August 1918 | 11 | Onondaga |
|  | Part of 11 and 3 Manlius | 30 April 1918 | 22 August 1918 | 11 | Manlius |
|  | Part of 11 and 4 Van Buren | 17 June 1921 | 22 June 1921 | 11 | Van Buren |
| 6 + 7 | Manlius | 24 June 1922 | 22 June 1922 | 10 | Manlius |
| 15 + 21 | Onondaga | 7 October 1926 | 11 October 1926 | 15 | Onondaga |
|  | Onondaga a City, Syracuse | 1 January 1927 | 1 January 1927 | City of Syracuse |  |
| 3,941 | Elbridge | 24 September 1928 | 2 January 1929 | 3 | Elbridge, Onondaga, C.R.S. |
|  | Elbridge Onondaga & Bruyn Co. | 30 October 1927 | 20 February 1930 | 6 | Pompey |
|  | Tompkins | 15 January 1930 | 15 January 1930 | 6 | Tompkins |
|  | Tully, Fabius | 15 January 1930 | 15 January 1930 | 6 | Tully, Fabius |
|  | C.R.S. | 15 January 1930 | 15 January 1930 | 6 | C.R.S. |
|  | Tompkins, Van Buren | 15 January 1930 | 15 January 1930 | 6 | Tompkins, Van Buren |
|  | Tully, Fabius | 15 January 1930 | 15 January 1930 | 6 | Tully, Fabius |
|  | C.R.S. | 15 January 1930 | 15 January 1930 | 6 | C.R.S. |
|  | Elbridge | 23 May 1930 | 23 May 1930 | 3 | Elbridge |
|  | Onondaga, Manlius | 16 January 1930 | 23 January 1930 | 1 | La Fayette, Atico |
|  | Onondaga, Manlius | 16 January 1930 | 23 January 1930 | 1 | La Fayette, Atico |
| 178,945 | Fabius | 29 July 1930 | 29 July 1930 | 1 | DeWitt, Tully |
|  | Pompey | 29 July 1930 | 29 July 1930 | 1 | C.R.S. |
|  | C.R.S. | 29 July 1930 | 29 July 1930 | 1 | C.R.S. |
|  | Fabius | 27 December 1930 | 2 January 1931 | 2 | Fabius, Tully |
|  | C.R.S. | 27 December 1930 | 2 January 1931 | 2 | C.R.S. |
|  | Marcellus, Skaneateles | 15 January 1935 | 15 January 1935 | 3 | Marcellus, Skaneateles |
|  | Marcellus, Camillus | 15 January 1935 | 15 January 1935 | 3 | Marcellus, Camillus, Onondaga, Spafford & Cicero |
|  | Marcellus, Cicero | 15 January 1935 | 15 January 1935 | 3 | Marcellus, Cicero |
|  | Skaneateles, Marcellus | 15 January 1935 | 15 January 1935 | 3 | Skaneateles, Marcellus |
| 3011 | Fabius | 5 November 1936 | 12 February 1937 | 11 | Fabius |
| 23,457 | La Fayette | 27 May 1931 | 19 March 1937 | 7 | La Fayette, Fabius, Cicero |
|  | La Fayette, Fabius | 13 May 1938 | 15 August 1938 | 7 | La Fayette, Fabius, Cicero |
|  | La Fayette, Fabius | 28 October 1937 | 1 July 1939 | 7 | La Fayette, Fabius, Cicero |
|  | La Fayette, Fabius | 25 May 1942 | 25 August 1942 | 7 | La Fayette, Fabius, Cicero |
|  | La Fayette, Fabius | 1 April 1943 | 5 July 1943 | 7 | La Fayette, Fabius, Cicero |
|  | La Fayette, Fabius | 19 March 1943 | 2 July 1943 | 7 | La Fayette, Fabius, Cicero |
