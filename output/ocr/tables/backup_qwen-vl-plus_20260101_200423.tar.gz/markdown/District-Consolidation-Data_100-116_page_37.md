# Cartland County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 37)

**Extraction Method:** full

**Processed:** 2026-01-01T19:34:20.698403

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Homer | 25 July 1873 | 11 February 1916 | 9 |  |
| 2 | Scott | 4 January 1916 | 5 February 1916 |  |  |
