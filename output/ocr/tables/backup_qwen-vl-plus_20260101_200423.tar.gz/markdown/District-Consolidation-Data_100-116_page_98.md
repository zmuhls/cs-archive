# Montgomery County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 98)

**Extraction Method:** full

**Processed:** 2026-01-01T19:47:22.247824

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 14 | Minden | 18 March 1893 |  | 5 |  |
| 12 | Amsterdam | 24 March 1866 |  | 3 |  |
| 7 | Anajoharie | 34 October 1872 |  |  |  |
| 3 | Palestine | 30 June 1918 |  |  | Copy of papers filed Feb 15/62 |
