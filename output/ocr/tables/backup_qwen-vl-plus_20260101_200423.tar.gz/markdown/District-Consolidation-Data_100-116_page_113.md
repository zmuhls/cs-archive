# Onondaga County

**Table Type:** Town School Units

**Source:** District-Consolidation-Data_100-116.pdf (Page 113)

**Extraction Method:** full

**Processed:** 2026-01-01T19:55:47.429039

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Camillus | U.F.S. 2 and 1 | 4 July 1915 | 5 & 6 |  |
| 2 | Camillus | 9 | 3 July 1915 | 8 |  |
| 1 | DeWitt | 11 | 7 July 1915 | 10, 12 & 13 |  |
| 2 | DeWitt | 14 | 1, 2, 3 & 4 |  |  |
| 1 | Elbridge | 4 | 2, 5, 7 & 10 |  |  |
| 2 | Elbridge | 9 | 1, 3, 6 & 11 |  |  |
| 1 | Lysander | 5 | 1, 4, 9, 10, 13, 14 & 15 | 19 |  |
| 2 | Lysander | 17 | 2, 3, 6, 7, 8, 11, 12 & 18 |  |  |
| 1 | Manlius | 6 | 1, 3, 7, 8, 9, 13, 14, 15 & 18 |  |  |
| 2 | Manlius | 2 | 4, 5, 10, 12, 16, 17, 19 & 20 |  |  |
