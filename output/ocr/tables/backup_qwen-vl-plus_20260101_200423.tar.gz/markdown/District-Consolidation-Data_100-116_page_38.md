# County County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 38)

**Extraction Method:** full

**Processed:** 2026-01-01T19:34:35.246729

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 2 13 | Cuyler | 3 December 1914 | 6 December 1915 | 1 Cuyler |  |
| 3 5 | Scott | 22 April 1915 | 18 August 1916 | 2 Scott |  |
| 12 48 | Freetown | 27 April 1917 | Appealed | 10 Freetown |  |
| 7 10 | Virgil | 23 May 1919 | 30 May 1923 | 3 Virgil |  |
| 34 8 | Lapeer | 9 September 1926 | 30 July 1927 | 3 Lapeer |  |
| 8 9 | Taylor | 30 July 1927 | 30 July 1927 | 1 Taylor |  |
| 4 5 | Solon | 3 August 1929 | 24 October 1929 | 5 Solon |  |
| 14 4 | Truxton | 3 August 1929 | 24 October 1929 | 4 Truxton |  |
| 7 49 | Marathon | 21 April 1930 | 21 May 1930 | 1 Freetown, Lapeer |  |
| 1 3 8 | Virgil | 21 May 1930 | 21 May 1930 | Virgil, Millett, Lapeer + Harford |  |
| 1 3 4 | Marathon | 21 May 1930 | 21 May 1930 | Marathon + Virgil |  |
| 1 2 6 | Lapeer | 21 May 1930 | 21 May 1930 | Lapeer + Harford |  |
| 7 8 | Virgil | 21 May 1930 | 21 May 1930 | Virgil + Lapeer |  |
| 1 2 3 8 | Truxton | 21 May 1930 | 21 May 1930 | Truxton, Solon |  |
| 1 4 9 | Solon | 20 February 1931 | 11 February 1931 | Solon |  |
| 1 4 | Cuyler | 20 February 1931 | 11 February 1931 | Cuyler + Homer |  |
| 1 1 4 | Homer | 20 February 1931 | 11 February 1931 | Homer + Pible |  |
| 1 4 6 | Pible | 20 February 1931 | 11 February 1931 | Pible + Cuyler |  |
| 12 36 | Cincinnati | 20 February 1931 | 11 February 1931 | Cincinnati + Millett |  |
| 1 1 4 6 | Taylor | 20 February 1931 | 11 February 1931 | Taylor (Cat.c) + Pitsch (Chen) |  |
