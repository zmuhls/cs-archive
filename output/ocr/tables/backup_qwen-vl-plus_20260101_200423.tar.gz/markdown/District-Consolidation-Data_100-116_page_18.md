# Chautauqua County

**Table Type:** Unknown

**Source:** District-Consolidation-Data_100-116.pdf (Page 18)

**Extraction Method:** chunked

**Processed:** 2026-01-01T17:22:41.885053

---

| No. of Dist | Name of Town | Date of School Meeting | Date on which Papers Were Approved | No. of New Dist. |
| --- | --- | --- | --- | --- |
| C.R.S. | Charlotte & Gerry | 13 Aug. 1938 | 15 Sept. 1938 | 1 Charlotte, Gerry, Stockton, Arkwright, Pemblet, Elling, Cherry Creek, Ellbert, and Ellington, Chautauqua Co. |
|  | Gerry |  |  |  |
|  | Starkton |  |  |  |
|  | Charlotte | 20 June 1938 | 20 June 1938 |  |
|  | Charlotte Stockton | 4 July 1938 | 4 July 1938 |  |
|  | Charlotte Arkright | 7 July 1938 | 7 July 1938 |  |
|  | Charlotte, Gerry & Cherry Creek | 10 July 1938 | 10 July 1938 |  |
|  | Gerry & Ellcott | 24 Aug. 1938 | 24 Aug. 1938 |  |
|  | Starkton & Ellington | 9 Sept. 1938 | 9 Sept. 1938 |  |
|  | Starkton & Pomblet | 12 Sept. 1938 | 12 Sept. 1938 |  |
|  | Pomblet & Stockton | 15 Sept. 1938 | 15 Sept. 1938 |  |
| C.R.S. | Hanover & Sheridan | 16 Sept. 1938 | 20 Sept. 1938 | 3 Hanover, Sheridan, Arkright, Villanova, Chaut Co., Parrsburg, Catt. Co. |
