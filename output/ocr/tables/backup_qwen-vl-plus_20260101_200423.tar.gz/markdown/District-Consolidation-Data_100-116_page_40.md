# Delaware County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 40)

**Extraction Method:** full

**Processed:** 2026-01-01T19:34:57.101141

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 21 | Colchester | 26 September 1903 |  | 7 |  |
| 17 | Middletown | 5 November 1892 |  | 9 |  |
| 7 | Davenport | 23 July 1912 |  | 3 |  |
| 19 | Roxbury | 4 May 1920 |  | 5 |  |
| 1 | Kortright | 14 March 1922 |  | 5 |  |
