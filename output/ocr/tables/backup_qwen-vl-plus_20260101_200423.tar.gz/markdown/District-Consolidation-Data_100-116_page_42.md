# Delaware County County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 42)

**Extraction Method:** full

**Processed:** 2026-01-01T19:35:22.243904

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 13415 | Harpersfield | 23 May 1914 | 13 May 1914 | 15 |  |
| 2 | Kortright | 31 August 1914 | 2 August 1914 | 3 |  |
| 1 | Kortright | (?) | 10 April 1913 | 1 | Consolidated |
| 142 | Tompkins | 11 June 1913 | 2 June 1913 | 1 |  |
| 4723 | Tompkins | 1 September 1914 | 29 September 1914 | 4 |  |
| 15 | Middletown | 29 September 1914 | 29 September 1914 | 15 |  |
| 3414 | Davenport | 4 September 1915 | 4 September 1915 | 3 |  |
| 2710 | Masonville | 12 May 1917 | 12 May 1917 | 2 |  |
|  | Masonville |  |  | 1 | Kortright |
| 1716 | Harpersfield | 15 September 1916 | 16 September 1916 | 1 |  |
| 523 | Walton | 4 January 1919 | to take effect Feb 1919 | 5 |  |
| 2410 | Hamden | 30 December 1918 | to take effect 1 Jan 1919 | 2 |  |
| 62325 | Middletown | 1 August 1919 | Appeal dismissed 29 Aug 1920 | 2.5 | Appeal dismissed 29 Aug 1920 |
| 62325 | Masonville | 10 May 1920 | to take effect 30 April 1920 | 12 | Appeal dismissed 29 Aug 1920 |
|  | Masonville | 8 August 1920 |  |  | Order revoked by Supr. Ag. Sidney |
| 116 | Kortright | 9 February 1922 | 10 February 1922 | 1 |  |
| 9 | Stamford | 9 February 1922 | 10 February 1922 | 4 |  |
|  | Maryland Otsego | 30 December 1922 | 30 December 1922 | 4 | Davenport |
| 4416 | Davenport | 8 August 1923 | 8 August 1923 | 4 | Colchester |
| 8412 | Davenport | 15 January 1926 | 15 January 1926 | 8 | Davenport |
| 162123 | Franklin | Meeting held Nov 26 1926 | CRS. Tabled by C.R.S. Dist. No. 16 Feb 1927 | 16 | Franklin (Meredith) |
| 586 | Meredith | 1 July 1927 | to take effect 20 Aug 1927 | 20 | Hancock |
| 910 | Sidney | 6 September 1927 | 6 September 1927 | 9 |  |
| 17424 | Tompkins | 6 September 1927 | 6 September 1927 | 19 |  |
| 27 | Harpersfield | 18 September 1927 | 18 September 1927 | 2 |  |
| 1121 | Walton | 20 April 1927 | 20 April 1927 | 21 |  |
|  | Colchester | 27 August 1928 | 27 August 1928 | 17 |  |
| 17428 | Franklin | 25 May 1929 | See sheet with C.R.S. | 18 |  |
| 9 | Franklin | 25 May 1929 | Designation of dist. 2 June 1929 | 13 | Franklin + Sidney ot top, Otsego Co. |
|  | Sidney | 2 April 1929 | Laid out 2 April 1929 | 1 | Repurbing Del Co. gilbreath sch |
| 14 | Franklin | 17 July 1929 | Covered with C.R.S. | 14 | Masonville - Otsego Co. |
| 1910 | Franklin | 17 July 1929 | Meeting held 1 July 1929 | 19 | Masonville - Otsego Co. |
|  | Franklin | 17 July 1929 | Meeting held 1 July 1929 | 19 | Masonville - Otsego Co. |
|  | Franklin | 17 July 1929 | Meeting held 1 July 1929 | 19 | Masonville - Otsego Co. |
