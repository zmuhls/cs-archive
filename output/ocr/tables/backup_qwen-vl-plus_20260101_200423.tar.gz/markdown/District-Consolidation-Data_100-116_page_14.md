# County County

**Table Type:** Unknown

**Source:** District-Consolidation-Data_100-116.pdf (Page 14)

**Extraction Method:** chunked

**Processed:** 2026-01-01T16:30:44.391187

---

| No. | Town | School Meeting | Approved | Remarks |
| --- | --- | --- | --- | --- |
| 1 | Cato & Ira | 25 May 1938 | 16 June 1938 | Cato, Ira, Congrest, Victory and Sterling, Cayuga Co., Lyander, Onondaga Co., Butler, Wayne Co., Hemlock, Oswego Co. |
| 2 | Cato | 25 May 1938 | 16 June 1938 |  |
| 3 | Cato & Congrest | 25 May 1938 | 16 June 1938 |  |
| 4 | Cato & Ira | 25 May 1938 | 16 June 1938 |  |
| 5 | Cato & Ira | 25 May 1938 | 16 June 1938 |  |
| 6 | Cato & Ira | 25 May 1938 | 16 June 1938 |  |
| 7 | Cato & Ira | 25 May 1938 | 16 June 1938 |  |
| 8 | Cato & Ira | 25 May 1938 | 16 June 1938 |  |
| 9 | Cato & Ira | 25 May 1938 | 16 June 1938 |  |
| 10 | Cato & Ira | 25 May 1938 | 16 June 1938 |  |
| 11 | Cato & Ira | 25 May 1938 | 16 June 1938 |  |
| 12 | Cato & Ira | 25 May 1938 | 16 June 1938 |  |
