# Chenango County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 26)

**Extraction Method:** full

**Processed:** 2026-01-01T19:32:03.889329

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1,2,4,5,6,7,10,15,16 | Oxford | 16 July 1929 | 30 July 1929 | Oakland, Preston, McBrought, Smithill |  |
| 1,6,7 | Preston |  |  |  |  |
| 2 | Smithville | 11 January 1930 | 11 January 1930 | Guilford, Plainbridge, Guilford | See proposals for annexation and alinement |
|  | Part of B. Guilford + Guilford, Chenango |  |  | Guilford, Norwich |  |
|  | 13 Guilford + Smithville, Chen |  |  | Guilford, Norwich, Offard |  |
| C.R.S. | B. | 31 December 1929 | 22 January 1930 | 1 Smithville | Meeting held 22 Jan 1930 |
|  | Guilford + Norwich | 14 | 17 April 1930 | 8 | Designation of district 17 April 1930 |
|  | 9,13 | 25 | 11 July 1930 | 1 Smithville | Compensate in folder |
|  | Smithville | + 1930 Donough | 15 October 1930 | 1 Smithville | Mc Donough (Onondaga) |
|  | Part of 3. | Smithville + Smithville | 3 July 1930 | 8 | Compensate in folder |
|  | Sherburne | 6,7,8,10,14 | 24 July 1930 | Sherburne No. 1 | Meeting held 24 July 1930 |
|  | New Berlin + Butternut | 23 August 1930 | 11 September 1930 | New Berlin, Norwich | Standing out 23 Aug 1930 |
|  | Norwich + Butternut | 25 September 1930 | 25 September 1930 | Chen, Co + Morris | Designation of district 25 September 1930 |
|  | New Berlin + Norwich | 25 September 1930 | 25 September 1930 | Petroleum, Otsego Co. |  |
|  | Pharaslan | 17 May 1931 | 17 May 1931 | Alatico, Linschlaun |  |
|  | Linschlaun + Otse | 17 June 1931 | 17 June 1931 |  Smyrna, Pharaslan + Pitscher |  |
|  | Guilford (Chen co) | 15 April 1931 | 27 May 1931 | Guilford, Norwich | Meeting held 27 May 1931 |
|  | Unadilla + Butternut (Otse | 27 May 1931 | 27 May 1931 | Unadilla (Otse | Designation of district 27 May 1931 |
|  | Norwich (Chen) | 27 May 1931 | 27 May 1931 | Bainbridge |  |
|  | Bainbridge after | 27 May 1931 | 17 September 1931 | Coventry, Oxford | Standing out 27 May 1931 |
|  | After | 27 May 1931 | 17 September 1931 | Suffield + Afton | Meeting held 17 Sep 1931 |
|  | Suffield | 27 May 1931 | 17 September 1931 | Chen co) | Designation of district 23 September 1931 |
|  | Suffield | 27 May 1931 | 17 September 1931 | Del co) | Designation of district 23 September 1931 |
|  | Suffield | 27 May 1931 | 17 September 1931 | Sanford |  |
|  | Suffield | 27 May 1931 | 17 September 1931 | Browne co |  |
