# Greene County

**Table Type:** Town School Units

**Source:** District-Consolidation-Data_100-116.pdf (Page 66)

**Extraction Method:** full

**Processed:** 2026-01-01T19:40:01.448175

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Hunter | U.F.S. 4 and 6, 8, 10 |  |  |  |
| 2 | Hunter | 2 | 1, 3, 7, 9 |  |  |
