# County County

**Table Type:** Central Rural Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 75)

**Extraction Method:** full

**Processed:** 2026-01-01T19:42:15.438100

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 5 | Litchfield | Effective | October 1, 1945 | CRS | 2 Paris - oneida Co. |
| 2 | Paris - oneida Co. | Effective | August 1, 1946 | 2 Paris - oneida Co. | 8751 german platte V |
| 7 | Platte | June 3, 1946 |  |  | german platte and oneida May 3, 1946 |
