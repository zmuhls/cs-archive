# County County

**Table Type:** Unknown

**Source:** District-Consolidation-Data_100-116.pdf (Page 110)

**Extraction Method:** full

**Processed:** 2026-01-01T19:50:03.683456

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 14 10 | Sangerfield | 24 October 1930 | 1 January 1931 | 1 Sangerfield |  |
| X 4 1 | Herkland | 3d 24 March 1931 | 13 June 1931 | 4 Herkland |  |
| 3 | Herkland | Whitestown + New Hartford | Gleason 15 June 1931 | 1 Herkland |  |
| 3 | New Hartford | Brenna | CP&S Meeting held 30 June 1931 | New Hartford |  |
| 3 | Brenna | CP&S | Meeting held 30 June 1931 | Brenna |  |
| 3 | Brenna | Rome | Gleason 10 June 1931 | Brenna |  |
| 5 8 10 | Herkland | Herkland | Gleason 10 June 1931 | Herkland |  |
| 1 | Whitestown | CP&S | Laid out 13 January 1931 | Whitestown |  |
| 1 | Whitestown | Marcey + Pliny | Meeting held 22 June 1931 | Marcey, Marcey + Pliny |  |
| 2 3 4 4 8 | Marshall | CP&S | Designation of dies 15 August 1931 | Marshall |  |
| 1 | Sangerfield | CP&S | 1 July 1932 | Sangerfield |  |
| 6 1 1 3 | Stulen | 5 June 1932 | 6 April 1932 | 13 Stulen |  |
| 1 | Sangerfield | CP&S | 11 May 1932 | Sangerfield |  |
| 1 | Rome + Sutton | CP&S | Laid out 26 May 1933 | Rome, Sutton |  |
| 2 4 5 3 | Stulen | CP&S | Meeting held 16 June 1933 | Stulen, Bonnell + Forestport |  |
| 1 | Stulen | CP&S | Dissolution of dies 29 June 1933 | Stulen |  |
| 12 | Trenton | CRS | Laid out 8 June 1934 | CRS |  |
| CRS | Trenton | Trenton + Deerfield | Meeting held 29 June 1934 | CRS |  |
| 3 4 6 11 8 | Floyd | Stulen + Trenton | Designation of dies 16 July 1934 | CRS |  |
| 3 8 12 | Stulen | Western + Stulen | Gleason 11 July 1934 | CRS |  |
| $10 | Whitestown | CP&S | Laid out 28 May 1935 | 10 Whitestown |  |
| 5 4 6 | Marcey | Overfield | Meeting held 14 June 1935 | CRS |  |
| 8 14 | Stulen | Overfield | Designation of dies 20 June 1935 | CRS |  |
| 17 5 16 | Western | Rome + Stulen | 25 September 1935 | 31 December 1935 | CRS |
| 5 | Sangerfield | CP&S | 25 September 1935 | 20 October 1935 | CRS |
| 11 9 27 | Sangerfield | CP&S | 18 July 1937 | 1 July 1937 | CRS |
| 5 | Sangerfield | CP&S | 12 July 1937 | 12 October 1937 | CRS |
| 11 9 27 | Sangerfield | CP&S | 11 September 1937 | 11 October 1937 | CRS |
| 5 | Sangerfield | CP&S | 28 June 1937 | 14 September 1937 | CRS |
| 5 | Sangerfield | CP&S | 28 June 1937 | 14 September 1937 | CRS |
