# Chemung County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 20)

**Extraction Method:** full

**Processed:** 2026-01-01T17:27:03.781948

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 2 | Virgil | 3 May 1920 | 5 May 1920 | 5 |  |
| 8 | Veteran | 7 May 1946 | 6 May 1946 | 6 |  |
