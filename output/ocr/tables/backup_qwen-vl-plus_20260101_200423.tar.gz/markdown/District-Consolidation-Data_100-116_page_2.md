# County County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 2)

**Extraction Method:** full

**Processed:** 2026-01-01T15:10:48.233280

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Oyslet Bay |  |  |  |  |
| 2 | Indicott |  |  |  |  |
| 3 | Sloan |  |  |  |  |
| 4 | Keimore |  |  |  |  |
| 5 | Huntington |  |  |  |  |
| 6 | Nathopot |  |  |  |  |
| 7 | Dansville |  |  |  |  |
| 8 | Ballston Spa |  |  |  |  |
| 9 | Pryach |  |  |  |  |
| 10 | Tarrytown |  |  |  |  |
