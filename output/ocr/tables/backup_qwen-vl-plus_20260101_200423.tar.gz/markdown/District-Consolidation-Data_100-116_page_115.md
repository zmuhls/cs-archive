# Onondaga County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 115)

**Extraction Method:** full

**Processed:** 2026-01-01T19:56:43.297294

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Tully & Spafford | 28 May 1943 | 7 September 1943 | CRS | Tully |
| 2 | DeRuyter, Madison Co | 15 March 1944 | 1 July 1944 | CRS | DeRuyter, Madison |
| 3 | Fabius | 15 March 1944 | 1 July 1944 | CRS | Fabius |
| 4 | Fabius | 15 March 1944 | 1 July 1944 | CRS | Fabius |
| 5 | La Fayette | 15 March 1944 | 15 August 1944 | CRS | La Fayette |
| 6 | La Fayette | Effective March 1, 1945 | CRS | La Fayette | None |
| 7 | Suffield (voters only) | Effective September 1, 1945 | CRS | Suffield | None |
| 8 | Suffield (voters only) | Effective September 15, 1945 | CRS | Suffield | None |
| 9 | Marcellus | Effective October 31, 1945 | CRS | Marcellus | None |
| 10 | CRS | 12 Clay, 3 S.C. 14,17,18 Clay, 3,4,6,7,8,7/12,13,15 Onondaga, 7,7, Salina (advisory) | Laid out June 6, 1949 | CRS | 3 Clay |
| 11 | CRS | 16 Onondaga, 23,4,6,7,8,7/12,13,17 Expander, 4 Clay, 7,7,10 Days (and monies) | Meeting held June 17, 1949 | CRS | 1 Onondaga |
| 12 | CRS | N.S. Dist, C.S. Dist | Laid out May 29, 1950 | CRS | 2 Elbridge, Van Buren, Camillus (con Brushton), Cogswell, Cogswell |
| 13 | CRS | N.S. Dist, C.S. Dist | Meeting held May 23, 1950 | CRS | 1 Salina - Clay |
| 14 | CRS | Subdivision 2 Salina, 3 Salina to Clay, 3 Melrose - Salina | Laid out May 23, 1950 | CRS | Salina - Clay |
| 15 | CRS | 3 Subdivision (Cayuga), 10 Proximity, 20 Onondaga + 10 Witt | Meeting held June 28, 1950 | CRS | De Witt - Onondaga, Defiance + Manlius |
| 16 | CRS | M.S. Dist, P.S. Dist | Laid out May 3, 1950 | CRS | Shanestown - Manlius, Syracuse in Onondaga Co |
