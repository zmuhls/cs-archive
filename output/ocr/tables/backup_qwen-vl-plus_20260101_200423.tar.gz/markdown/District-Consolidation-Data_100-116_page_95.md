# Monroe County County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 95)

**Extraction Method:** full

**Processed:** 2026-01-01T19:46:00.846012

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 6 | Pittsford | 16 April 1890 |  | 7 |  |
| 1 | Greece | 9 July 1915 |  | 5 |  |
| 10 | Rush | 10 June 1919 |  | 5 |  |
| 9 | Sweden | 13 July 1926 |  | 3 |  |
| 1 | Brighton | 31 August 1928 |  | 5 |  |
| 1 | Irondequoit | 6 May 1930 |  | 3 |  |
| 7 | Gates | 13 May 1931 |  | 3 |  |
| 8 | Wheatland | 1 January 1942 |  | 1 |  |
| 1 | Greece | 18 March 1946 |  | 4 |  |
| 4 | Irondequoit | 25 June 1946 |  | 4 |  |
| 4 | Gates | 17 April 1947 |  | 4 |  |
| 7 | Brighton | 6 June 1947 |  | 7 |  |
