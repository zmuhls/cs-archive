# Greene County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 67)

**Extraction Method:** full

**Processed:** 2026-01-01T19:40:33.461751

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 24 7 | Jewett | 13 May 1914 | 2 1914 | 7 Jewett |  |
| 8 9 | Jewett | 26 September 1913 | 8 1913 | 8 Jewett |  |
| 64 16 | Greenville | 17 June 1919 | 16 1919 | 6 Greenville |  |
| 4 9 13 | New Baltimore | 17 June 1919 | 4 1919 | 4 New Baltimore |  |
| 2 | Prattsville | 30 July 1919 | 2 1919 | 2 Prattsville |  |
| 24 6 | Jewett | 10 February 1920 | 10 1920 | 6 Jewett |  |
| 64 1 | New Baltimore | 19 July 1920 | 13 1920 | 12 New Baltimore |  |
| 12 13 | Durham | 25 August 1920 | 12 1920 | 12 Durham |  |
| 9 10 | Catskill | 15 June 1922 | 9 1922 | 10 Catskill |  |
| 104 12 | Catskill | 24 July 1922 | 10 1922 | 10 Catskill |  |
|  |  | 13 May 1930 |  | 1 Greenville, Durham, Catskill | Consolidated by Com. 29 March 1930 |
|  |  | 29 April 1930 |  | 1 Greenville, Durham, Catskill, New Baltimore, Rhinecliff, Albany Co. | Dissolved 29 April 1930 |
|  |  | 8 July 1930 |  | 1 Durham, Greeneville, Catskill | Designation of dist. 13 May 1930 as C.R.S. |
|  |  | 10 April 1931 |  | 1 Durham, Greeneville, Catskill, Rhinecliff, Catskill, Greeneville | Designation of dist. 16 April 1931 |
|  |  | 28 October 1931 |  | 1 Hunter, Jewett | Assessment papers in folder |
|  |  | 30 April 1931 |  | 1 Hunter, Jewett | Designation of dist. 29 April 1931 as C.R.S. |
|  |  | 15 May 1931 |  | 1 Windham, Jewett, Lexington, Schodack & Durham | Laid out 15 May 1931. Meeting held 15 June 1931. Designation of dist. 30 June 1931 as C.R.S. |
|  |  | 1 June 1936 |  | 1 Gilboa (Schodack C) | 1 June 1936 to take effect 1 September 1936 |
|  |  | 1 March 1937 |  | 1 Rosburg (Del. Co.) | 1 March 1937 to take effect 1 July 1937 |
|  |  | 1 March 1937 |  | 1 Rosburg (Del. Co.) | 6 March 1937 to take effect 1 July 1937 |
|  |  | 6 March 1937 |  | 1 Rosburg (Del. Co.) | 6 March 1937 to take effect 1 July 1937 |
