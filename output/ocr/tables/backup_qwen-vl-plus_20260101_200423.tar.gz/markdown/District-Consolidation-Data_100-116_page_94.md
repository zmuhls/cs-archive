# County County

**Table Type:** Unknown

**Source:** District-Consolidation-Data_100-116.pdf (Page 94)

**Extraction Method:** full

**Processed:** 2026-01-01T19:45:53.040061

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 5 | Augusta -mid to Madison | Effective February 15, 1946 |  | CRS 1 Madison |  |
| CRS | N.S. dist 9 Lenoir-Ville (Lenokta) 1,2,3,4,5,6,11,12 Smithfield 7 Semale | Laid out June 1, 1949 | Meeting held June 23, 1949 | CRS 1 Henop |  |
| CRS | N.A. dist 2 Sullivan C.S. dist 1,2,3,4,5,6,7,9,10,11,12, Sullivan 13,15,16,17,18,19 14 Semale (and sundays) | Laid out June 7, 1949 | Meeting held June 30, 1949 | CRS 1 Sullivan |  |
