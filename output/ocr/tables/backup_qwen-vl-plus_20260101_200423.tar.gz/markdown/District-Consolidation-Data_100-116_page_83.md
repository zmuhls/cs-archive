# County County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 83)

**Extraction Method:** full

**Processed:** 2026-01-01T19:43:32.037612

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 147 | Greig | 13 May 1914 | 24 Jan 1917 | 1 Greig |  |
| 1417 | Denmark | 19 August 1918 | 15 Aug 1918 | 1 Denmark |  |
| 10419 | Martinsburg | 20 August 1918 | 3 Sept 1918 | 10 Martinsburg |  |
| 247 | High Market | 23 September 1918 | 3 Sept 1918 | 2 High Market |  |
| 8410 | Pinckney | 1 April 1919 | 1 Aug 1919 | 8 Pinckney | Appeal dismissed |
| 243 | Martinsburg | 30 August 1918 | 15 Aug 1919 | 2 Martinsburg | Appeal dismissed |
| 15 | Leyden | 27 June 1919 | 26 June 1919 | 5 Leyden |  |
| 2549 | Turin | 11 September 1919 | 15 Aug 1919 | 9 Turin | Appeal dismissed |
| 8 | West Turin | 11 September 1919 | 15 Aug 1919 | 2 Lowville |  |
| 68 | Osceola | 1 September 1919 | 15 Aug 1919 | 5 Osceola (Remebered) |  |
| 58415 | Leyden | 1 July 1919 | 27 July 1920 | 5 Leyden |  |
| 2411 | Leyden | 27 July 1920 | 29 Dec 1920 | 2 Leyden | Appeal dismissed |
| 375 | Montague | 25 June 1924 | 25 June 1924 | 3 Montague | Cent. Rural Sch. Laid out 30 Jan 1926 |
| 123456 | Lewis | 17 July 1926 | 17 July 1926 | 1 Lewis | Lewis & Leyden |
| 4 | Leyden | 17 July 1926 | 17 July 1926 | 1 Lewis | West Turin, Lewis, Ave., Oneyda Co. |
| 10 | Martinsburg | 4 August 1926 | 4 August 1926 | 7 West Turin | Lewis, Lew. Co. C. of Oneyda Co. |
| 574 | West Turin | 4 August 1926 | 4 August 1926 | 8 Watson |  |
| 173 | Greig | 29 December 1927 | 29 December 1927 | 4 Greig |  |
| 244 | High Market | 1 August 1928 | 1 August 1928 | 2 High Market |  |
| 8 | Martinsburg | 4 August 1928 | 4 August 1928 | 8 Turin of Martinsburg, Greig, Turin |  |
| 18 | Turin | 4 August 1928 | 4 August 1928 | 1 Greig |  |
| 367 | West Turin | 26 September 1930 | 1 Jan 1931 | 1 West Turin |  |
| 748 | High Market | 10 June 1930 | 9 Sept 1931 | 3 High Market |  |
| 5 | Martinsburg | 10 June 1930 | 9 Sept 1931 | 3 Martinsburg | Meeting held 17 July 1930 |
| 141074 | Leyden | 31 May 1935 | 30 July 1935 | 5 Leyden | Meeting held 15 June 1935 |
| 12 | Leyden & Ogdenale | 31 May 1935 | 30 July 1935 | 5 Leyden, West Turin | Saying out district |
| C.R.S. | High Market | 31 May 1935 | 30 July 1935 | C.R.S. | Meeting held 16 Oct 1935 |
| 19 | Martinsburg | 31 May 1935 | 30 July 1935 | C.R.S. | Laid out 2 Oct 1935 |
| 70 | Martinsburg | 31 May 1935 | 30 July 1935 | C.R.S. | Designation of dist. 25 Oct 1935 |
