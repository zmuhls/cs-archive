# Greene County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 65)

**Extraction Method:** full

**Processed:** 2026-01-01T19:39:55.863077

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Cairo | 19 July 1907 |  | 3 |  |
| 10 | New Baltimore | 22 August 1900 |  | 3 |  |
| 2 | Pratts ville | 4 May 1919 |  | 5 |  |
| 8 | Hunter | 7 June 1922 |  | 5 |  |
| 1 | Athens | 1913 |  | 1 |  |
| 3 | Catalice | 1900 |  | 3 |  |
