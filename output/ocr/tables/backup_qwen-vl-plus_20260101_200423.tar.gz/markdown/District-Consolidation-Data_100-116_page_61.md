# Fulton County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 61)

**Extraction Method:** full

**Processed:** 2026-01-01T19:39:24.257774

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 12 | Ephratah & Oppenheim | 15 May 1914 | 12 August 1914 | 1 | Consolidated |
| 20 | Johnstown & Ephratah | 6 May 1914 | 20 August 1914 | 11 | Johnstown taken out |
| 6 | Caroga | 26 April 1916 | 24 April 1916 | 3 | Caroga |
| 8,9,10 | Ephratah | 7 February 1923 | 27 May 1923 | 10 | Ephratah |
| 4 | Bleecker | 28 May 1923 | 28 May 1923 | 4 | Bleecker |
| 1,5,6 | Stratford | 16 May 1923 | 16 May 1923 | 1 | Stratford |
| 1,2,3,4,5,7,8,9 | Northampton | 20 April 1925 | 14 April 1925 | 12 | Northampton |
| 12 | Hope, Ham. Co. Northampton | May 6 1928 | 30 May 1928 | 1 | Hope, Ham. Co. |
| 1 | Salisbury, Herk. Co. | 1st July 1928 | 14 June 1928 | 1 | Salisbury, Herk. Co. |
| 1,2,3,4,5,7,8,9 | Caroga, C.R.S. | 1st July 1928 | 25 May 1928 | 1 | Caroga |
| 11 | Stratford etc Filling | 1st July 1928 | 14 June 1928 | 1 | Stratford |
| 1,2,3,4,5,7,8,9 | Broadalbin | 1st July 1928 | 11 June 1928 | 8 | Broadalbin |
| 1,2,3,4,5,7,8,9 | Mayfield | 1st July 1928 | 29 May 1928 | 6 | Mayfield |
| 1,2,3,4,5,7,8,9 | Broadalbin | 1st July 1928 | 29 May 1928 | 1 | Broadalbin Mayfield |
| 1,2,3,4,5,7,8,9 | Northampton | 1st July 1928 | 30 June 1928 | 6 | Northampton |
| 1,2,3,4,5,7,8,9 | Bleecker | 28 April 1932 | 28 April 1932 | 2 | Bleecker |
| 1,2,3,4,5,7,8,9 | Mayfield | 29 May 1937 | 15 June 1937 | 6 | Mayfield |
| 1,2,3,4,5,7,8,9 | Oppenheim | 17 May 1938 | 16 August 1938 | 10 | Oppenheim |
| 9,10,11,12 | Northampton | 5 November 1941 | 16 February 1941 | 1 | Northampton |
| 1,2,3,4,5,7,8,9 | Oppenheim | 16 February 1942 | 20 June 1942 | 10 | Oppenheim |
| 1,2,3,4,5,7,8,9 | Salisbury, Ham. Co. | 11 May 1942 | 30 June 1942 | 1 | Salisbury, Ham. Co. |
| 1,2,3,4,5,7,8,9 | Broadalbin | 11 May 1942 | 30 September 1944 | 1 | Broadalbin |
| 1,2,3,4,5,7,8,9 | Oppenheim | 11 May 1942 | 30 September 1944 | 1 | Oppenheim |
| 1,2,3,4,5,7,8,9 | Stratford | 11 May 1942 | 30 September 1944 | 1 | Stratford |
