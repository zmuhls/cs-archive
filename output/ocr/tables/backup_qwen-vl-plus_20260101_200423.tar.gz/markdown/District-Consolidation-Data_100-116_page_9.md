# Cattaraugus County

**Table Type:** Unknown

**Source:** District-Consolidation-Data_100-116.pdf (Page 9)

**Extraction Method:** full

**Processed:** 2026-01-01T16:00:00.900941

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 5 | Red House | 16 March 1936 | 16 June 1936 | 1 Red House |  |
| 3 | Red House | 20 March 1937 | 1 July 1937 | 3 Leon |  |
| 3 | Leon | 19 July 1937 | 20 Oct. 1937 | 3 Great Valley |  |
| 2 | Great Valley | 30 March 1938 | 1 July 1938 | 2 South Valley |  |
| 8 | South Valley | 11 Sept. 1938 | 1 Sept. 1938 | 1 Hinsdale |  |
| 3 | Hinsdale | 9 Aug. 1938 | 14 Nov. 1938 | 1 Rushford (Allegany) |  |
| 3 | Rushford (Allegany) | 10 April 1939 | 15 July 1939 | 5 Leon |  |
| 3 | Leon | 10 April 1939 | 15 July 1939 | 5 Leon |  |
| 5 | Farmerville | 24 July 1940 | 1 Nov. 1940 | CRS |  |
|  | Hinkford |  |  | CRS | U.S. dist. Yorkahine Abbeville Freedom |
|  | CRS | Land out 16 June 1941 | Meeting held 26 June 1941 | CRS | Yorkahine Abbeville Freedom |
|  | CRS | Designation of dist. 20 June 1941 | January 1941 | CRS | Yorkahine Abbeville Freedom |
| 12 | Freedom | 24 March 1941 | 1 July 1941 | 1 Rushford (Allegany) |  |
| 3 | Rushford (Allegany) | 28 April 1941 | 23 July 1941 | 2 Napoli |  |
| 3 | Napoli | 29 June 1942 | 1 Oct. 1942 | 1 Ran德尔 |  |
| 3 | Randolph | 16 March 1942 | 1 July 1942 | 1 Ran德尔 |  |
| 3 | Great Valley | 12 June 1942 | 12 Sept. 1942 | 1 Great Valley |  |
| 1,2,3,5,7,9,10,12 | Franklinville | Laid out + designated 2 May 1944 | Meeting held 16 June 1944 | CRS | Franklinville, Farmerville, Renda, Humphrey, Incheahs, Machine |
| 10 | Franklinville |  |  | CRS | Franklinville, Renda, Humphrey, Incheahs, Machine |
| 2,3,8,9 | Franklinville |  |  | CRS | Franklinville, Renda, Humphrey, Incheahs, Machine |
| 2,3,8,9 | Franklinville |  |  | CRS | Franklinville, Renda, Humphrey, Incheahs, Machine |
|  | Lackawana | 3 |  | CRS | Portville, Pottille (Allegany) |
|  | Portville |  |  | CRS | Portville, Pottille (Allegany) |
|  | Pottille (Allegany) |  |  | CRS | Portville, Pottille (Allegany) |
|  | Genoa |  |  | CRS | Genoa, Clarksville + Genoa |
|  | Clarksville |  |  | CRS | Genoa, Clarksville + Genoa |
|  | Genoa |  |  | CRS | Genoa, Clarksville + Genoa |
| 3 | Little Valley | Laid out May 11, 1946 | Meeting held June 6, 1946 | CRS | 1 Little Valley |
