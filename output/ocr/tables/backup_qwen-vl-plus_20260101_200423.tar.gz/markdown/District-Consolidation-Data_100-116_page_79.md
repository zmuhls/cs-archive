# County County

**Table Type:** Central Rural Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 79)

**Extraction Method:** full

**Processed:** 2026-01-01T19:42:57.833046

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Hounefield | 14 June 1938 |  | 1 | Housefield, Mendon |
| 2 | Hounefield, Henderson | 28 June 1938 | 18 July 1938 | 4 | Adams, Watertown |
| 3 | Hounefield, Adams, Watertown |  |  | 10 | Cape Vincent, Clayton & Lyme |
| 4 | Cape Vincent | 16 Sept 1938 | 21 Sept 1938 | 10 | Cape Vincent & Gne |
| 5 | Clayton | 6 Sept 1938 | 22 Sept 1938 | 8 | Clayton, Orleansville, Brownville |
| 6 | Clayton, Orleansville |  |  | 19 | Clayton, Orleansville, Brownville, Lyme, Orleans |
| 7 | Ellisburg | 2 February 1939 | 11 May 1939 | 5 | Ellisburg |
| 8 | Hounefield | 22 June 1939 | 19 Sept 1939 | 10 | Hounefield |
| 9 | Hounefield | 29 June 1939 | 19 Sept 1939 | 12 | Hounefield |
| 10 | Hounefield | 1 March 1940 | 1 July 1940 | 1 | Hounefield |
| 11 | Hounefield | 23 Sept 1940 | 24 Dec 1940 |  |  |
| 12 | Brownville, Paviilion | 28 April 1941 | 30 May 1941 | 15 | Brownville, Paviilion, 2, 4, 5, 6, 18 Brownville, 2, 4, 5, 6, 11 Paviilion |
| 13 | Antwerpo | 8 August 1941 | 8 Nov 1941 | 5 | Antwerpo |
| 14 | Antwerpo | 13 August 1941 | 13 Nov 1941 | 1 | Antwerpo |
| 15 | Philadelphia | 9 September 1941 | 9 Dec 1941 | 2 | Philadelphia |
| 16 | Wilma & Diana | 21 August 1941 | 5 Dec 1941 | 4 | Wilma & Diana |
| 17 | Le Ray | 28 Sept 1941 | 5 Dec 1941 | 3 | La Ray |
| 18 | Le Ray | 5 Sept 1941 | 5 Dec 1941 | 11 | Le Ray, Paviilion |
| 19 | Orleans, Clayton | 20 Dec 1941 | 5 June 1942 | 8 | Orleans, Clayton, Alexandria, Tamella, Le Ray, Jefferson Co. |
| 20 | Orleans | 22 June 1942 | 10 July 1942 | 18 | Orleans, Philadelphia, Le Ray, Clayton, Orleans |
| 21 | Alexandria | 27 May 1943 | 15 Sept 1943 | 4 | Alexandria, Orleans |
| 22 | Alexandria | 27 May 1943 | 15 Sept 1943 | 3 | Alexandria |
| 23 | Ellisburg | 15 June 1943 | 20 Sept 1943 | 2 | Ellisburg |
| 24 | Hounefield |  | 15 Sept 1944 | 1 | Hounefield |
