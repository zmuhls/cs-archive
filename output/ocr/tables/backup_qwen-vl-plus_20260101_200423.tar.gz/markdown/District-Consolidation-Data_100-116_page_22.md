# County County

**Table Type:** Unknown

**Source:** District-Consolidation-Data_100-116.pdf (Page 22)

**Extraction Method:** chunked

**Processed:** 2026-01-01T19:31:16.913767

---

| No. of dist. | NAME OF TOWN | DATE OF SCHOOL-MEETING ORGANIZING-DISTRICT | DATE ON WHICH PAPERS WERE APPROVED AT DEPARTMENT | No. of new dist. | REMARKS |
| --- | --- | --- | --- | --- | --- |
| 6,7,9 | X Van Etten | 14 July 1914 | 6 13,725 19-15 | 9 Van Etten |  |
| 14 8 | Van Etten | 1 August 1919 | 7 318,419 19-15 | 1 Van Etten |  |
| 14 4 | Van Etten | 15 June 1920 to take effect 15 Sept 1920 | 10 299,819 20-15 | 1 Van Etten |  |
| 14 3 | Ashland | 28 August 1925 | 2 17,591 Court | 1 Ashland |  |
|  | Van Etten & Spencer |  | Laid out 31 Aug. 1938 |  |  |
|  | Van Etten & Baldwin |  | Meeting held 15 Sept 1938 |  |  |
|  | Van Etten & Erin |  | Designation of dist. 19 Sept. 1938 |  |  |
|  | Baldwin, Erin-Chemung |  |  |  | Baldwin, Erin-Chemung Co. |
|  | Barton, Baldwin-Chemung |  |  |  | Syracuse Co., Newfield, Tompkins Co. |
|  | Barlow, Van Etten |  |  |  | Cayuga, Schuyler Co. |
|  | Newfield, Van Etten & Cayuga |  |  |  |  |
|  | Cathlin | 120 Jan. 1943 to take effect 1 May 1943 | 29 March 1950 total effect 1 July 1950 | 10 Cathlin | Horseheads & Elmy |
