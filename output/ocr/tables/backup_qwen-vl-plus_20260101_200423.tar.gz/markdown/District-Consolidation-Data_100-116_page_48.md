# Dutchess County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 48)

**Extraction Method:** full

**Processed:** 2026-01-01T19:36:27.030959

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 276 | Stanford | 28 September 1914 | 22 181 929 | 2 | Stanford |
| 14 2 | Dover | 5 July 1921 | 6 71 134 | 2 | Dover |
| 24 10 | Stanford | 15 March 1922 | 10 327 118 | 2 | Stanford |
| 54 7 | Stanford | 19 May 1927 | 15 199 000 | 1 | Stenford |
| 34 6 | Fishkill | 4 January 1928 | 1 123 456 | 3 | Fishkill |
| 7 | Pleasant Valley | 27 July 1928 | 10 144 233 | 3 | Pleasant Valley |
| 8 | Clinton | 1 August 1929 | 8 30100 | 2 | Hyde Park |
| 36 1 | Hyde Park | 1 October 1929 | 3 55100 | 1 | Clinton |
|  | Berkhamsted | 14 May 1930 | 15 August 1930 | 7 | Hyde Park |
| 1 4 | Pine Plains |  |  |  | Pine Plains |
| 5 | Milan |  |  |  | Milan |
| 6 | Pine Plains |  |  |  | Pine Plains |
|  | East Clinton |  |  |  | East Clinton |
| 10 | Clinton |  |  |  | Clinton |
| 5 6 | Milan |  |  |  | Milan |
| 3 | Pine Plains |  |  |  | Pine Plains |
|  | East Clinton |  |  |  | East Clinton |
| 5 6 | Milan |  |  |  | Milan |
| 3 | Pine Plains |  |  |  | Pine Plains |
|  | East Clinton |  |  |  | East Clinton |
| 1 4 | Milan |  |  |  | Milan |
| 1 4 5 6 8 9 | Red Hook | 6 October 1937 | 15 August 1938 | 7 | Red Hook, Milan |
|  | Red Hook | 26 October 1937 | 11 October 1938 | 1 | Hyde Park |
|  | Hyde Park | 21 August 1938 | 20 September 1938 | 1 | Wappingers, Pine Plains |
|  | Fishkill vs. Schuyler | 19 September 1938 |  |  | Fishkill, Wappingers |
|  | Fishkill vs. Schuyler | 22 April 1941 | 2 July 1941 | 2 | Hyde Park |
|  | Rhinebeck & Red Hook | 11 June 1941 | 15 September 1941 | 1 | Rhinebeck |
