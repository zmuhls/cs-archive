# Chenango County County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 25)

**Extraction Method:** full

**Processed:** 2026-01-01T19:31:48.875000

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 16 | Norwich & Guilford | 9 July 1913 | 16 July 1913 | 8 | Guilford |
| 8 | Norwich & New Berlin | 25 April 1914 | 21 April 1914 | 6 | Norwich |
| 7 | Columbus & New Berlin | 31 August 1914 | 31 August 1914 | 7 | Columbus |
| 16 | Norwich | 8 August 1913 | 8 August 1913 | 5 | Norwich |
| 77 | North Norwich | 10 March 1914 | 10 March 1914 | 2 | North Norwich |
| 167 | Otsego | 29 July 1914 | 29 July 1914 | 1 | Otsego |
| 168 | Oxford & Greene | 3 February 1914 | 3 February 1914 | 16 | Greene |
| 64 | Sherburne | 26 January 1914 | 26 January 1914 | 6 | Sherburne |
| 14 | Sherburne | 26 January 1914 | 26 January 1914 | 12 | Sherburne |
| 4 | McDonough | 7 October 1916 | 7 October 1916 | 12 | McDonough |
| 14 | Pharsalia | 8 September 1915 | 8 September 1915 | 14 | Pharsalia |
| 7 | Greene | 28 May 1915 | 28 May 1915 | 7 | Greene |
| 3 | North Norwich | 24 August 1917 | 24 August 1917 | 3 | North Norwich |
| 9 | Norwich | 1 February 1919 | 1 February 1919 | 9 | Norwich |
| 3 | North Norwich | 15 August 1919 | 15 August 1919 | 3 | North Norwich |
| 6 | Sherburne | 14 October 1919 | 14 October 1919 | 7 | Sherburne |
| 2 | Smyrna | 11 September 1920 | 11 September 1920 | 4 | Pharsalia |
| 10 | Linsclaein | 10 September 1920 | 10 September 1920 | 6 | Pitcher |
| 10 | North Norwich | 5 October 1920 | 5 October 1920 | 1 | Norwich |
| 11 | Plymouth | 6 September 1921 | 6 September 1921 | 10 | Plymouth |
| 19 | Smithville | 21 April 1923 | 21 April 1923 | 1 | Smithville |
| 24 | Plymouth | 22 May 1924 | 22 May 1924 | 2 | Plymouth |
| 24 | Pharsalia | 10 July 1924 | 10 July 1924 | 2 | Pharsalia |
| Part of New Berlin | 45 New Berlin | 2 August 1926 | 2 August 1926 | 5 | New Berlin |
| 14 | Pharsalia | 22 July 1927 | 22 July 1927 | 1 | Pharsalia |
| Part of Pharsalia | 5 Presto | 22 July 1927 | 22 July 1927 | 15 | Preston |
| 2 | Plymouth | 23 July 1928 | 23 July 1928 | 2 | Plymouth |
| 54 | Lincklaen | 1 August 1928 | 1 August 1928 | 8 | Lincklaen |
| 15 | Guilford | 1 September 1928 | 1 September 1928 | 14 | Guilford |
| 3 | McDonough | 6 September 1929 | 6 September 1929 | 4 | Pharsalia |
| 66 | Mc Donough | 28 August 1929 | 28 August 1929 | 7 | Mc Donough |
