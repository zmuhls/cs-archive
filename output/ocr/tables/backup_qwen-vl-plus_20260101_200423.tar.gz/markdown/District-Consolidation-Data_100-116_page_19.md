# Chautauqua County

**Table Type:** Central Rural Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 19)

**Extraction Method:** full

**Processed:** 2026-01-01T17:26:59.378292

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| CRS | Cherry Creek | 19 April 1948 | 27 June 1948 | 1 | Cherry Creek |
| CRS | Ellcott | 29 April 1946 | 17 January 1948 | 1 | Ellcott |
| CRS | Weatfield | 27 November 1945 | 30 April 1946 | 1 | Weatfield |
| CRS | Beattie | 7 June 1946 | 28 June 1947 | 1 | Beattie |
