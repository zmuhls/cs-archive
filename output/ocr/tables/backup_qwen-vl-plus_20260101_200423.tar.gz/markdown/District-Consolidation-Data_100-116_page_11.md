# Cayuga County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 11)

**Extraction Method:** full

**Processed:** 2026-01-01T16:00:11.093133

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Moravia | 19 December 1868 | 12 | 6 | No copy of original papers filed but account of meeting recorded from historical sketches |
| 6 | Genoa | 9 September 1912 | 13 September 1912 | 5 |  |
| 2 | Genoa | 31 August 1915 |  | 3 |  |
| 6 | Ledyard | 9 May 1919 |  | 5 |  |
| 4 | Locke | 17 September 1918 |  | 3 |  |
| 16 | Sterling |  |  |  | See papers in folder |
