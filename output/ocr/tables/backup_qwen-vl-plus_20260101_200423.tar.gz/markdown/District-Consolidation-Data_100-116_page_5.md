# County County

**Table Type:** Unknown

**Source:** District-Consolidation-Data_100-116.pdf (Page 5)

**Extraction Method:** full

**Processed:** 2026-01-01T15:13:24.922924

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 5 | Windsor | 13 Nov 1941 | 1 July 1942 | 1 | Windsor |
| 1 | Windsor | 20 May 1942 | 20 Aug 1942 | 1 | Windsor |
| 15 | Windsor | 21 May 1942 | 21 Aug 1942 | 1 | Windsor |
| 14 | Windsor | 24 March 1942 | 1 July 1942 | 1 | Windsor |
| 24 | Windsor | 2 Aug 1943 | 13 Oct 1943 | 1 | Triangle |
| 7 | Richford | 7 July 1943 | 11 Oct 1943 | 1 | Triangle |
| 8 | Triangle |  | 9 Oct 1943 |  | Triangle |
| 10 | Brattle |  |  |  | Triangle |
| 11 | Brattle |  |  |  | Triangle |
| 11 | Brattle |  |  |  | Triangle |
| 3 | Champlain |  |  |  | Triangle |
| 6 | Champlain |  |  |  | Colesville |
| 8 | Union (Barnes Co) |  | Effective August 22, 1947 | 2 | Union, Barnard |
| 16 | Union, Barnet Co | 3 May 1950 | Effective July 5, 1947 | 3 | Union |
|  | Barnet Co |  | Effective October 1, 1945 |  | Barnet |
|  | Barnet Co |  | Effective August 22, 1947 |  | Union, Barnet |
|  | Barnet Co |  | Effective July 5, 1947 |  | Union |
|  | Barnet Co |  | Effective October 1, 1945 |  | Barnet |
|  | Barnet Co |  | Effective August 22, 1947 |  | Union, Barnet |
|  | Barnet Co |  | Effective July 5, 1947 |  | Union |
|  | Barnet Co |  | Laid out June 5, 1950 |  | Michaud, Stetson, Colesville |
|  | Barnet Co |  | Meeting held June 26, 1950 |  | Michaud, Stetson, Colesville |
|  | Barnet Co |  | Laid out June 5, 1950 |  | Michaud, Stetson, Colesville |
|  | Barnet Co |  | Meeting held June 28, 1950 |  | Michaud, Stetson, Colesville |
|  | Barnet Co |  | Laid out June 5, 1950 |  | Michaud, Stetson, Colesville |
|  | Barnet Co |  | Meeting held June 28, 1950 |  | Michaud, Stetson, Colesville |
