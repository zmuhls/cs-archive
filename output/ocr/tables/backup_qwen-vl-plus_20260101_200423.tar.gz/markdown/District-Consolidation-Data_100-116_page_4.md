# County County

**Table Type:** Unknown

**Source:** District-Consolidation-Data_100-116.pdf (Page 4)

**Extraction Method:** chunked

**Processed:** 2026-01-01T15:12:52.821433

---

| No. | Town | Date Org | Meeting | Dept Approval | Dist | Remarks |
| --- | --- | --- | --- | --- | --- | --- |
| 12 | Vernal | 30 April 1936 | 19 May 1936 | 16 June 1936 | 1 Vernal | CRS |
| 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14 | Vernal |  |  |  |  | CRS |
|  | Windsor | 3 Aug 1937 | 4 Nov 1937 | 1 July 1938 | Windsor | CRS |
|  | Colerain | 26 March 1938 | 21 May 1938 | 1 Sept 1938 | Colerain | CRS |
|  | Windsor | 1 June 1938 |  | 15 Aug 1938 | Windsor | CRS |
|  | Barnbridge | 27 April 1938 |  |  | Barnbridge | CRS |
| 3 | Sands Point | 9 June 1938 | 29 June 1938 | 13 July 1938 | Sanford | CRS |
|  | Broome Co |  |  |  | Broome Co | CRS |
|  | and Delhi |  |  |  | Delhi | CRS |
|  | Sands Point | 800 Aug 1938 |  |  | Sands Point | CRS |
|  | Baldwin | 10 Aug 1938 |  |  | Baldwin | CRS |
|  | Union Valley | 11 Aug 1938 |  |  | Union Valley | CRS |
