# Jefferson County County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 76)

**Extraction Method:** full

**Processed:** 2026-01-01T19:42:22.258686

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 13 | Adams | 21 June 1899 | 9 September 1899 | 9 |  |
| 7 | Brownville | 9 March 1896 | 9 September 1896 | 9 | No detailed account of meeting received |
| 18 | Ellisburg | 11 May 1906 | 5 May 1906 | 5 |  |
| 7 | Rutland | 16 April 1917 | 3 April 1917 | 3 |  |
| 4 | Wilna & Diana | 6 January 1921 | 7 January 1921 | 7 |  |
