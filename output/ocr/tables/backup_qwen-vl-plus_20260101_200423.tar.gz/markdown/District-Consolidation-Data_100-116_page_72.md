# Herkimer County County

**Table Type:** Town School Units

**Source:** District-Consolidation-Data_100-116.pdf (Page 72)

**Extraction Method:** full

**Processed:** 2026-01-01T19:40:59.436775

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Newport | U.F.S. 1 and 2, 4, 5, 6 |  |  |  |
| 2 | Newport | U.F.S. 8 | 3 |  |  |
