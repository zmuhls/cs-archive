# Delaware County County

**Table Type:** Central Rural Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 45)

**Extraction Method:** full

**Processed:** 2026-01-01T19:36:04.638756

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 11 | Franklin | Effective October 15, 1945 | Effective October 31, 1945 | 16 Franklin | CRS |
| 16 | Franklin | 3 |  |  | CRS |
| 13 | Meridith | 3 |  |  | CRS |
| 17 | Delhi | 3 |  |  | CRS |
|  | CRS | E.C. Walton | Laid out Apr 19, 1949 |  | CRS |
|  | E.C. Walton | 12,13,14,15,16,17,18,19,20,21 (Walton) | Meeting Held May 24, 1949 |  | CRS |
|  | Franklin | 19,10,14,31 Franklin |  |  | CRS |
|  | Franklin |  |  |  | CRS |
