# Montgomery County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 100)

**Extraction Method:** full

**Processed:** 2026-01-01T19:47:40.811559

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 2 | Minden | 10 May 1915 | 5 May 1915 | 2 | St. Johnsville |
| 2 | St. Johnsville | 12 May 1915 | 12 May 1915 | 14 | Root |
| 8+14 | Root | 12 May 1915 | 12 May 1915 | 19 | Minden |
| 4+19 | Minden | 1 June 1915 | 1 June 1915 | 16 | Minden |
| 11+16 | Minden | 28 August 1926 | 28 August 1926 |  |  |
| 2 | St. Johnsville | 15 April 1942 | 15 April 1942 | CRS | 2 St. Johnsville |
| 30 | St. Johnsville | 30 April 1942 | 30 April 1942 | CRS | 2 St. Johnsville |
| 11 | Palatine | 30 April 1942 | 31 August 1942 | CRS | 1 Canajoharie, Palatine, Root, Minden, Charlotte, Mohawk, Montmorency, and Mechanicville |
| 7+8 | Canajoharie | 15 September 1944 | 5 June 1944 | CRS | 1 Canajoharie, Palatine, Root, Minden, Charlotte, Mohawk, Montmorency, and Mechanicville |
| 1,2,3,4,5,7,9,10 | Canajoharie | 15 September 1944 | 5 June 1944 |  |  |
| 10 | Root | 15 September 1944 | 5 June 1944 |  |  |
| 16 | Minden | 15 September 1944 | 5 June 1944 |  |  |
| 50,12 | Mohawk | 15 September 1944 | 5 June 1944 |  |  |
| 2,4,5,8,11 | Charlotte | 15 September 1944 | 5 June 1944 |  |  |
| 9 | Charlotte | 15 September 1944 | 5 June 1944 |  |  |
| 13 | Charlotte | 15 September 1944 | 5 June 1944 |  |  |
| 3 | Samuel | 15 September 1944 | 1 August 1945 | CRS | 2 St. Johnsville |
| 2 | St. Johnsville | 15 September 1944 | 1 August 1945 |  |  |
