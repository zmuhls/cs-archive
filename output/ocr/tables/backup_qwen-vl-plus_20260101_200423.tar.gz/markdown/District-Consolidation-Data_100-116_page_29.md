# Clinton County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 29)

**Extraction Method:** full

**Processed:** 2026-01-01T19:33:18.724312

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 2 | Saranac | 27 September 1916 |  | 3 |  |
| 13 | Plattsburgh | 17 January 1917 |  | 5 |  |
| 5 | Chazy | 27 June 1912 |  |  |  |
