# Chenango County

**Table Type:** Town School Units

**Source:** District-Consolidation-Data_100-116.pdf (Page 24)

**Extraction Method:** full

**Processed:** 2026-01-01T19:31:30.642569

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Guilford | U.F.S. 14 and 1,8,9,10,11,12,13,15,16,18 |  |  |  |
| 2 | Guilford | U.F.S. 4 and 2,3,5,6,7,17 |  |  |  |
| 1 | New Berlin | U.F.S. 2 and 13,9,10,11,12,15 |  |  |  |
| 2 | New Berlin | U.F.S. 5 and 4,6,7,8,13,14 |  |  |  |
