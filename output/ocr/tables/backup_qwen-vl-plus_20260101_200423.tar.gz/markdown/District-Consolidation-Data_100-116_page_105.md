# Niagara County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 105)

**Extraction Method:** full

**Processed:** 2026-01-01T19:48:37.030626

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Lewiston | 21 February 1898 |  | 3 |  |
| 12 | Newfane | 22 August 1913 |  | 3 |  |
| 18 | Royalton | 1 March 1917 |  | 5 |  |
| 4 | Niagara | 14 August 1925 |  | 5 |  |
| 6 | Fort Erie | 26 August 1947 |  | 6 |  |
