# Essex County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 56)

**Extraction Method:** full

**Processed:** 2026-01-01T19:37:38.773773

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 11 | Minerva | 21 August 1915 | 28 August 1915 | 5 | Indian Lake |
| 5 | Indian Lake | 29 April 1916 | 2 May 1916 | 1 | Schoon |
| 14 | Westport | 20 October 1917 | 20 October 1917 | 2 | Westport |
| 24 | Lewis | 24 November 1917 | 24 November 1917 | 11 | Lewis |
| 10 | Lewis | 8 September 1917 | 23 December 1917 | 5 | Lewis |
| 24 | Lewis | 24 December 1917 |  | 2 | Lewis |
| 14 | Moriah | 30 December 1918 |  | 1 | Moriah |
| 13 | Crown Point | 16 September 1918 |  | 18 | Crown Point |
| 7 | Crown Point | 16 September 1918 |  | 16 | Crown Point |
| 14 | Crown Point | 16 September 1918 |  | 3 | Crown Point |
| 2 | Lewis | 26 January 1919 |  | 1 | Elizabethtown |
| 4 | Elizabethtown | 15 January 1919 |  | 5 | Lewis |
| 54 | Lewis | 30 December 1918 |  | 10 | Chesterfield |
| 8 | Lewis | 8 December 1919 |  | 2 | Lewis |
| 6 | Moriah | 11 September 1919 |  | 12 | Moriah |
| 3 | Minerva | 2 November 1921 |  | 1 | Essex |
| 14 | Minerva | 30 July 1922 | 29 April 1922 | 1 | Minerva |
| 9 | Minerva | 25 July 1923 | 29 April 1922 | 1 | Minerva |
| 24 | Minerva | 1 August 1924 | 5 July 1924 | 2 | Minerva |
| 3 | Essex | 8 September 1925 | 27 April 1926 | 10 | Willsboro |
| 13 | Willsboro | 5 May 1926 | 27 April 1926 | 1 | Schoon |
| 3 | Willsboro | 24 August 1927 | 27 April 1926 | 10 | Willsboro |
| 4 | Keene | 12 August 1928 | 27 April 1926 | 1 | Keene |
| 12 | Keene | 15 June 1928 | 27 April 1926 | 1 | Keene |
| 6 | Keene | 16 September 1928 | 27 April 1926 | 6 | Keene |
| 17 | Schoon | 1 August 1929 |  | 1 | Schoon |
| 10 | Schoon | 1 August 1929 |  | 1 | Schoon |
| 18 | Keene | 15 July 1930 | 16 July 1930 | 1 | Keene |
| 23 | Keene | 15 July 1930 | 16 July 1930 | 2 | The Elba |
| 4 | Keene | 15 July 1930 | 15 August 1930 | 1 | Schoon |
| 12 | Moriah | 15 July 1930 | 15 August 1930 | 1 | Moriah |
| 7 | Chesterfield | 20 June 1930 | 20 June 1930 | 1 | Jay |
| 14 | Chesterfield | 20 June 1930 | 20 June 1930 | 1 | Jay |
| 19 | Jay | 1 July 1930 | 1 July 1930 | 1 | Chesterfield |
| 3 | Black Brook | 24 July 1930 | 24 July 1930 | 11 | Franklin |
