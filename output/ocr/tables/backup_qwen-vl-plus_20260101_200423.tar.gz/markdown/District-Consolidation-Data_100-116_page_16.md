# Chautauqua County

**Table Type:** Town School Units

**Source:** District-Consolidation-Data_100-116.pdf (Page 16)

**Extraction Method:** full

**Processed:** 2026-01-01T16:30:55.959889

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Stockton | U.F.S. 3 and 1,2,5,6 and 9 Stockton |  |  |  |
| 2 | Stockton | U.F.S. 7 and 4,8,10 Stockton |  |  |  |
| 14 | Hannover | Affidavit Filed |  | 5 |  |
