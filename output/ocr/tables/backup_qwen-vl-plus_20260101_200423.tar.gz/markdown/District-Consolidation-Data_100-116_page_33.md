# Clinton County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 33)

**Extraction Method:** full

**Processed:** 2026-01-01T19:33:51.624140

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 6-1 | Chazy | 8 June 1938 | 8 Sept 1938 | 1 Chazy |  |
|  | U.S.S dist | Champlain | Laid out 9 Aug 1938 | Meeting held 2 April 1941 | 1 Champlain |  |
|  | C.S. dists 2,3,4,6,7,8,9 Champlain | Designation of dist 9 May 1941 |  |  |  |
| 21 | Saranac | 13 June 1942 | 15 Sept 1942 | 1 Saranac |  |
| 13 | Chateauguay-Willsboro |  | 20 Oct 1942 | 1 Ausable |  |
| 10 | Boothmantown | 18 July 1942 |  | 1 Saranac |  |
| 6 | Saranac | 30 March 1943 | 3 July 1943 | 1 Saranac |  |
| 6 | Plattinging-Barnes-Dinorwic | 20 March 1943 | 2 July 1943 | 1 Saranac |  |
| 8 | Plattinging |  | 3 July 1943 |  |  |
| 11 | Plattsbury Saranac Schuyler Hall | 1 July 1943 | 2 July 1943 |  |  |
| 7 | Saranac | 1 July 1943 |  |  |  |
| 17 | Saranac Schuyler Hall | 1 July 1943 |  |  |  |
| 17 | Saranac and Black Brook | 1 Sept 1944 |  | 1 Saranac |  |
