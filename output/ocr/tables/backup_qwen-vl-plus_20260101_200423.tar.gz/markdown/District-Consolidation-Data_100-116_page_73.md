# Herkimer County County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 73)

**Extraction Method:** full

**Processed:** 2026-01-01T19:41:17.657252

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 8 89 | Stark | 2d 25 October 1913 | 12-13 | 8 Stark |  |
| 3 11X | Stark | 2d 3 October 1913 | 14-15 | 3 Stark |  |
| 8 10X | Warren | 2d 23 March 1914 | 16-17 | 8 Warren |  |
| 6 13X | Schuyler | 2d 9 September 1915 | 18-19 | 8 Schuyler |  |
| 3 4X | Ohio | 2d 24 October 1918 | 20-21 | 4 Ohio |  |
| 44 6X | Norway | wh 31 March 1919 | 22-23 | 4 Norway |  |
| 7 | Norway | wh 8 August 1919 | 24-25 | 7 Norway |  |
| 18 2X | Webb | wh 16 September 1919 | 26-27 | 1 Webb |  |
| 34 5X | Fairfield | 3d 21 April 1923 | 28-29 | 5 Fairfield |  |
| 14 2X | Fairfield | 3d 25 August 1924 | 30-31 | 2 Fairfield |  |
| 84 11X | Salisbury | C.R.S. with 1 Stratford, Fulton Co. 1st See | 32-33 | Newfield Litchfield |  |
| 25 5X | Litchfield | Meeting held 29 May 1931 | 34-35 | Columbia (Herkimer) |  |
| 5 4X | Plumfield | Meeting held 25 May 1931 | 36-37 | Plumfield, Richfield |  |
| 9 | Plumfield | Designation of 3d C.R.S. (Alton Co.) + 25 J. 1931 | 38-39 | Bridgewater + Buna (Chenango Co.) + Brookfield (Medina Co.) |  |
| 1 25X | Stark | Class 10 April 1931 | 40-41 | Stark + Little Falls |  |
| 3 | Stark + Little Falls | Meeting held 18 April 1934 | 42-43 | Webb (Montgomery Co.) |  |
| 4 | Springfield (Chenango Co.) | Demarcation of 17 April 1931 | 44-45 | Springfield (Stuts) |  |
| 4 4X | Ohio | Take effect 9 July 1931 | 46-47 | 4 Ohio |  |
| 5 | Springfield/Haven | 1 July 1932 | 48-49 | 1 Stark |  |
| 1 | Stark | 4 June 1932 | 50-51 | 1 Stark |  |
| 1 | Stark | 4 May 1932 | 52-53 | 1 Stark |  |
| 1 | Stark | 4 June 1932 | 54-55 | 1 Stark |  |
| U 3X | Newport/Russia | Laid out 24 May 1934 | 56-57 | 3 Newport, Russia |  |
| 3 | Newport | Meeting held 18 June 1934 | 58-59 | Neway (Ohio, Saline Co.) |  |
| 2,3,4 8X | Ohio | 10 June 1934 | 60-61 | Webb and Dryfield |  |
| 1 | Russia | 15 July 1934 | 62-63 | 1 Stark |  |
| 11 | Russia | 20 August 1934 | 64-65 | 3 Newport |  |
| 15 | Oppenheim | 12 June 1936 | 66-67 | 10 Oppenheim |  |
| 1 | Danube | 15 July 1936 to take effect 15 February 1937 | 68-69 | 1 Stark |  |
| 1 | Stark | 24 June 1937 to take effect 25 September 1937 | 70-71 | E.R.S. 1 Stark |  |
