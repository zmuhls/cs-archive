# Livingston County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 87)

**Extraction Method:** full

**Processed:** 2026-01-01T19:44:17.605811

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 164 | North Dansville | 16 April 1915 | 3-57722 4 Oct 1915 | 1 North Dansville |  |
|  | West Sparta | 21 Dec 1925 | 2 Denbille 26 Oct 1926 | 2 Denbille |  |
|  | Dansville, Steub | 3 June 1927 | 19 Jan 1927 | 11 Portage |  |
|  | Portage | 3 June 1927 | 19 Jan 1927 | 11 Portage |  |
|  | Castille | 9 May 1927 | 10 May 1927 | 1 North Dansville & 4 West Sparta, L.V. Co. |  |
|  | Nunda & Portage | 8 Nov 1927 | 14 Dec 1937 | 12 Nunda & Portage, L.V. Co. & Genesee Falls |  |
|  | Nunda & Genese | 15 March 1937 | 4 Nov 1937 | 12 Nunda & Portage, L.V. Co. & Genesee Falls |  |
|  | Portage & Genesee | 15 March 1937 | 4 Nov 1937 | 12 Nunda & Portage, L.V. Co. & Genesee Falls |  |
|  | Pattonville & Genese | 15 March 1937 | 4 Nov 1937 | 12 Nunda & Portage, L.V. Co. & Genesee Falls |  |
|  | Genesee Square | 15 March 1937 | 4 Nov 1937 | 12 Nunda & Portage, L.V. Co. & Genesee Falls |  |
|  | York, Leicester & Caledonia | 19 Sept 1938 | 20 Sept 1938 | C.R.S. 1 York, Leicester & Caledonia, Livingston Co. |  |
|  | Livenia, Conesus | 19 Sept 1938 | 20 Sept 1938 | C.R.S. 1 Livenia, Conesus Avon, Lima, Genesee, Livingston Co. |  |
|  | Nunda, West Sparta, Mount Morris & Portage | 22 July 1938 | 16 Aug 1938 | C.R.S. 1 Nunda, West Sparta, Mount Morris & Portage, Livingston Co. |  |
|  | Ossian to Dansville | 29 June 1939 | 28 Sept 1939 | 7 Ossian C.R.S. No Dansville |  |
|  | Sparta to West Sparta | 12 July 1939 | 15 Oct 1939 | 1 No Dansville |  |
|  | Dansville to Dansville | 28 Nov 1939 | 23 Sept 1939 | 1 No Dansville |  |
|  | Dansville to Dansville | 24 Aug 1939 | 28 Nov 1939 | 1 No Dansville |  |
|  | Dansville to Dansville | 12 July 1939 | 15 Oct 1939 | 1 No Dansville |  |
|  | Dansville to Dansville | 4 November 1939 | 1 July 1940 | 1 No Dansville |  |
|  | Dansville to Dansville | 8 July 1941 | 1 Oct 1941 | 1 No Dansville |  |
|  | Dansville to Dansville | 8 July 1941 | 14 Oct 1941 | 1 No Dansville |  |
|  | Aven & Binnie | 12 June 1943 | 12 July 1943 | C.R.S. 1 Aven & Binnie |  |
|  | Aven & Lima | 12 June 1943 | 12 July 1943 | C.R.S. 1 Aven & Lima |  |
|  | Aven, Monroe Co. & Lima | 12 June 1943 | 12 July 1943 | C.R.S. 1 Aven, Monroe Co. & Lima |  |
|  | Dansville, Steuben Co. | 12 June 1943 | 12 July 1943 | C.R.S. 1 No Dansville |  |
|  | Dansville, Steuben Co. | 15 Sept 1944 | 15 Sept 1944 | C.R.S. 1 No Dansville |  |
