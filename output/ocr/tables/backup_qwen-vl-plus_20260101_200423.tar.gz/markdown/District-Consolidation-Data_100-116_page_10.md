# County County

**Table Type:** Unknown

**Source:** District-Consolidation-Data_100-116.pdf (Page 10)

**Extraction Method:** full

**Processed:** 2026-01-01T16:00:06.528757

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | New Albion | 6 June 1946 | 25 June 1946 | 1 | New Albion |
| 3 | Allegany | 9 June 1947 | 30 June 1947 | 1 | Allegany |
| 1 | Elliotville | 30 October 1946 | 3 November 1946 | 1 | Elliotville |
| 2 | Carrolltown | 1 July 1954 | 31 July 1954 | 1 | Carrolltown (N.Y.) |
