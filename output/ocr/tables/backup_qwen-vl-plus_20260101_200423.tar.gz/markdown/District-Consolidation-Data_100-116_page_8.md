# County County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 8)

**Extraction Method:** chunked

**Processed:** 2026-01-01T15:59:40.012786

---

| No. of dist | NAME OF TOWN | DATE OF SCHOOL-MEETING ORGANIZING DISTRICT | DATE ON WHICH PAPERS WERE APPROVED AT DEPARTMENT | No. newdist. |
| --- | --- | --- | --- | --- |
| 1,2 (part of) | East Otto | 5 May 1942 | 10 1913-14 | 1 East Otto |
| 5 (part of) | Machias | 30 September 1913 | 1 1913-14 | 5 Machias |
| 11+14 | Machias | 24 October 1919 | 5 1913-14 | 8 Franklinville |
| 8 | Franklinville | 12 September 1919 | 5 1913-14 | 2 Freedom |
| 24 7 | Freedom | 1 December 1921 | 5 1913-14 | Humphrey |
| * Part of Humphrey | Humphrey | 15 September 1923 | 1 1913-14 | Great Valley |
| * 24 10 X Dayton | Dayton | 24 November 1924 | 4 1913-14 | Dayton |
| * Part of Lyndon + 1 Lyndon | Lyndon | 23 April 1925 | 1 1913-14 | Red House |
| 1,2,3,4,6 | Red House | 30 July 1927 | 3 1913-14 | 3 Napoli |
| Napoli | Napoli | 9 January 1928 | 2 1913-14 | 2 Otto |
| 1+2 | Kotto | 3 September 1929 | 1 1913-14 | 2 Salamance |
| 4+5 | Kotto | 29 July 1929 | 1 1913-14 | 3 Coldespring |
| 12346 | Red House | 30 July 1925 | 23 April 1927 | 1 |
| 12346 | Napoli | 20 January 1928 | 9 January 1929 | 3 |
| 12 | KOtto | 3 September 1928 | 3 September 1929 | 2 |
| 163 | Little Valley | 4 September 1929 | 29 July 1929 | 3 |
| 63 | Colasping | 29 July 1929 | 16 June 1931 | 1 |
| 13610 | Randolph | C.R.S. | Napoli Mandolay laid out 17 Jan 1931, Meeting held 12 Feb 1931 | Designation |
| 2345 | Connellsville | Cold spring | C.R.S. | Connellsville Napoli (area) |
| 12 | Canaida | 24 June 1931 | 1931 to take effect January 2, 1932 | Cannon |
| From East Otto | Order vacated, Meeting held Aug 8, 1934 and decision needed Aug 21, 1934 | U.S. dist 7 Hinadale | Laid out 2nd June 1934 | Meeting held 18 June 1934 |
| C.R.S. | 1. Hinadale + John | 2. Catt Co + Clarksville | Yorkshire + Ellsworth | East Otto + Franklinville |
| N. dist 3 | Achford | 5,8,9,11,14 | Ashford | Designation |
| 10 | Reese + South Oalfield | Meeting held 7 May 1935 | Designation | 25 June 1935 |
| 9 | Ellistville + East Otto | 13 | Mechas + Sillicottille | Designation |
| 20 | Great Valley | 28 Aug 1936 to take effect Dec 1936 | Great Valley | Designation |
| 10 | East Otto | 5 May 1942 | 17 1912-13 | 1 East Otto |
