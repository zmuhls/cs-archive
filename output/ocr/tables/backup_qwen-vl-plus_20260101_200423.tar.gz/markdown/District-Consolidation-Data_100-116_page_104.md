# Nassau County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 104)

**Extraction Method:** full

**Processed:** 2026-01-01T19:48:31.171337

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 7.9 + 10 | Oyster Bay | 7 December 1916 | 10 1930 | 9 | Oyster Bay |
| 16-17 | Hempstead | 21 October 1925 | 30 1925 | 2 | Hempstead |
| 22 | Hempstead + No. Hempstead | 3 January 1926 | 17 1926 | 3 | No. Hempstead |
| 5 | No. Hempstead + Hempstead | 11 November 1926 | 29 1926 |  |  |
| 13-24-43 | Oyster Bay + No. Hempstead | 3 November 1930 | 16 December 1930 | 15 | Oyster Bay + Hempstead |
| 16 | Oyster Bay | 7 November 1931 | 17 1931 | 7 | Oyster Bay |
| 8 | No. Hempstead | 8 November 1931 | 20 1932 | 7 | The Hempstead |
| U.S.S. 4, 1, 25, 29 | Hempstead | 25 September 1934 | 3 March 1934 | 3 | Hempstead |
| 19 | Oyster Bay | 6 June 1950 |  | 19 | Oyster Bay |
