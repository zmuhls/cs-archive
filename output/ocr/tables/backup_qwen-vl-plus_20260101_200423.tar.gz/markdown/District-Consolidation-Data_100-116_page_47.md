# Dutchess County County

**Table Type:** Town School Units

**Source:** District-Consolidation-Data_100-116.pdf (Page 47)

**Extraction Method:** full

**Processed:** 2026-01-01T19:36:14.189061

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Hyde Park | U.F.S. 1 and 3-5 |  |  |  |
| 2 | Hyde Park | U.F.S. 2 and dist. no. 4 |  |  |  |
| 1 | Red Hook | U.F.S. 3 and nos. 7-9 |  |  |  |
| 2 | Red Hook | U.F.S. 4 and nos. 1,5-8 |  |  |  |
