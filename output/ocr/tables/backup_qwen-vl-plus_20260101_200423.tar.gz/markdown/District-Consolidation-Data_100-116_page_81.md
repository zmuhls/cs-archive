# Lewis County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 81)

**Extraction Method:** full

**Processed:** 2026-01-01T19:43:07.442956

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 2 | Lowville | 5 July 1905 |  | 5 |  |
| 7 | New Bremen | 13 September 1909 |  | 3 |  |
| 6 | Osceola | 24 March 1920 |  | 5 |  |
| 10 | Lewis | 10 April 1923 |  | 3 |  |
| 16 | Denmark | 2 June 1924 |  | 3 |  |
