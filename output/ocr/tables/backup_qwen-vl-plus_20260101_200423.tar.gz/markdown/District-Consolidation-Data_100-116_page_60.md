# Franklin County County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 60)

**Extraction Method:** full

**Processed:** 2026-01-01T19:38:48.791156

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 10 | Bangor | 12 January 1914 | 10 February 1914 | 10 | Fort Covington |
| 447 | Brandon | 1 February 1915 | 4 February 1915 | 4 | Brandon |
| 7413 | Franklin | 25 August 1919 | 14 September 1919 | 7 | Franklin |
| 566 | Fort Covington | 23 June 1922 | 21 June 1922 | 6 | Fort Covington |
| 142 | Fort Covington | 2 June 1922 | 21 June 1922 | 1 | Fort Covington |
| 546 | Bangor | 22 June 1922 | 21 June 1922 | 5 | Bangor |
| 145 | Waverly | 28 March 1923 | 11 November 1923 | 1 | Waverly |
| 143 | Waverly | 19 May 1924 | 2 June 1924 | 1 | Waverly |
| 1284 | Waverly | 22 May 1924 | 26 June 1924 | 1 | Waverly |
| 344 | Brighton | 18 July 1925 | 18 July 1925 | 4 | Brighton |
| 142 | Duane | 6 August 1926 | 6 August 1926 | 2 | Duane |
| 344 | Duane | 6 August 1926 | 6 August 1926 | 3 | Duane |
| 142 | Santa Clara | 1 April 1927 | 15 April 1927 | 1 | Santa Clara |
| 5415 | Bellmont | 20 August 1928 | 6 August 1928 | 5 | Bellmont |
| 6+8 | Dickinson | 23 May 1932 | 30 August 1932 | 8 | Dickinson |
| 1473 | Bellmont | 26 July 1937 | 17 November 1937 | 3 | Bellmont-Malone |
| 6+1 | Franklin | 14 June 1938 | 15 September 1938 | 1 | Franklin |
| 604 | Bellmont | 27 June 1938 | 31 August 1938 | 4 | Bellmont |
| 6+4 | Bellmont | 27 January 1944 | 6 June 1945 | 4 | Bellmont |
| 6+8 | Chateaugay | 15 June 1949 | 15 June 1949 | 1 | Chateaugay |
|  |  | Meeting Held June 28, 1950 | Signed June 5, 1950 |  |  |
