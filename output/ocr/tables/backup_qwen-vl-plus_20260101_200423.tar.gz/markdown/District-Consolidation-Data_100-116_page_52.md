# Erie County County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 52)

**Extraction Method:** full

**Processed:** 2026-01-01T19:37:08.286407

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 14 | Seaford | 20 February 1946 | 9 April 1946 | 1 | Holland |
| 5 | West Seneca | 29 November 1945 | 15 April 1946 | 1 | Seneca |
| 2 | Lancaster |  |  | 1 | Lancaster |
| 3 | Amberst & Cheektowaga | 25 May 1948 | 28 September 1948 | 1 | Amberst |
| 8 | Amberst & Cheektowaga |  |  | 1 | Cheektowaga |
| 19 | Aurora |  |  | 1 | Aurora |
| 1 | Town of Grand Island |  |  | 1 | Grand Island |
| 1 | Clarence | 10 June 1946 | 27 June 1946 | 1 | Clarence |
| 1, 2, 3 | West Seneca | 24 May 1946 | 28 May 1946 | 1 | West Seneca |
| 3 | Newstead | 19 May 1949 | 25 June 1949 | 1 | Newstead |
| 12, 13, 15 | Alden | 12 November 1947 | 28 June 1949 | 1 | Alden |
| 1, 19, 11, 12, 13 | Alden |  |  | 1 | Alden |
| 5 | Clarence |  |  | 1 | Clarence |
| 4 | North Collins | 27 May 1949 | 23 June 1949 | 1 | North Collins |
| 3 | North Collins |  |  | 1 | North Collins |
| 5 | Everson |  |  | 1 | Everson |
| 7, 14, 15 | Amberst & Springville | 7 June 1950 | 20 June 1950 | 1 | Amberst and Springville |
| 16, 18 | Oran |  |  | 1 | Oran |
| 14, 15 | Brunn |  |  | 1 | Brunn |
| 1, 2, 4 | Grand Island | 22 February 1950 | 29 April 1950 | 1 | Grand Island |
