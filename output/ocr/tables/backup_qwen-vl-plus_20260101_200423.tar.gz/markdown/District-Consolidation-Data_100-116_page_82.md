# Lewis County

**Table Type:** Town School Units

**Source:** District-Consolidation-Data_100-116.pdf (Page 82)

**Extraction Method:** full

**Processed:** 2026-01-01T19:43:12.655722

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | West Turin | U.F.S. 7 and 3,4,5,6,8,9 |  |  |  |
| 2 | West Turin | U.F.S. 2 |  | 1 |  |
