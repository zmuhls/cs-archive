# Onondaga County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 112)

**Extraction Method:** full

**Processed:** 2026-01-01T19:55:40.042561

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 9 | Camillus | 17 May 1898 |  | 7 |  |
| 2 | Manlius | 27 July 1910 |  | 3 |  |
| 14 | De Witt | 4 November 1914 |  | 3 |  |
| 12 | Clay & Cicero | 24 February 1916 | 3 March 1916 | 5 |  |
| 6 | De Witt | 16 November 1915 |  | 5 |  |
| 19 | Skaneateles | 29 May 1919 |  | 5 |  |
| 5 | Onondaga, Camillus | 17 February 1920 |  | 5 |  |
| 26 | Onondaga | 9 November 1926 |  | 5 |  |
| 1 | Cicero | 31 May 1927 |  | 3 |  |
| 4 | Onondaga, Camillus | 25 May 1931 |  | 3 |  |
| 3 | Cicero | 3 May 1926 |  | 3 |  |
| 4 | Salina | 21 June 1927 |  | 3 |  |
| 4 | Geddes | 14 July 1936 | 7 August 1936 | 3 |  |
