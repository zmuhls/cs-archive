# Chautauqua County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 15)

**Extraction Method:** full

**Processed:** 2026-01-01T16:30:50.028152

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 3 | Stockton | 18 November 1876 |  | 6 |  |
| 7 | Stockton | 2 July 1901 |  | 7 |  |
| 1 | Westfield | 7 February 1868 |  | 9 |  |
| 3 | North Harmony | 9 May 1919 |  | 5 |  |
| 4 | Ellery | 13 May 1924 |  | 3 |  |
| 2 | Harmony (#16) | 5 October 1904 |  |  |  |
