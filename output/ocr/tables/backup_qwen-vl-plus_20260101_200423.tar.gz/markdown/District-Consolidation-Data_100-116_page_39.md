# County County

**Table Type:** Unknown

**Source:** District-Consolidation-Data_100-116.pdf (Page 39)

**Extraction Method:** full

**Processed:** 2026-01-01T19:34:51.639236

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 8 | Cincinnati Bustown Taylor | 15 May 1931 | 31 May 1931 | 1 | Cincinnati Millet Cuyler Treetown John Taylor + Treetown (Columbus) Schenectady (Broome co) Triangle (Broome co) |
| 26 | Columbus Cuyler | 13 July 1931 | 31 July 1931 | 1 | Designation of Tupton Cuyler dist. 1 of 33 as |
|  | *Part of 6 Scott + 1 Scott | 5 Aug 1933 | 31 Aug 1933 | 1 | Scott 2 Scott See * |
|  | Public | 29 April 1936 | 27 July 1936 | 1 | Public |
| 9 | Freemont | 24 May 1938 | 25 August 1938 | 1 | Freemont Marathon, Treetown |
| 15 | Virgil | 23 May 1938 | 25 August 1938 | 1 | Virgil |
| 2 | German (Chering Co) | 10 March 1939 | 1 July 1939 | 1 | German |
| 3 | Chenango | 27 May 1941 | 28 August 1941 | 1 | Chenango |
|  | Warford | 19 June 1941 | 19 September 1941 | 1 | Warford |
|  | Marathon | 21 May 1942 | 19 August 1942 | 1 | Marathon |
|  | Harford |  |  | 1 | Harford |
|  | Marathon |  |  | 1 | Marathon |
|  | Canton Imp. Co. | 11 May 1942 | 9 August 1942 | 1 | Canton Imp. Co. |
|  | Canton Imp. Co. | 15 August 1942 | 15 November 1942 | 1 | Canton Imp. Co. |
|  | Marathon |  |  | 1 | Marathon |
|  |  | Effective October 1, 1945 |  |  |  |
|  | Laid out May 4, 1946 Meeting held June 4, 1946 |  |  |  |  |
|  | Homer |  |  | 1 | Homer |
|  | Scott |  |  | 1 | Scott |
|  | Marathon |  |  | 1 | Marathon |
|  | Virgil |  |  | 1 | Virgil |
|  | Cottonville + Sulin | 12 June 1950 | 29 June 1950 | 1 | Cottonville + Sulin |
|  | Cottonville + Sulin | 12 June 1950 | 29 June 1950 | 1 | Cottonville + Sulin |
|  | Cottonville + Sulin | 12 June 1950 | 29 June 1950 | 1 | Cottonville + Sulin |
|  | Cottonville + Homer | 12 June 1950 | 29 June 1950 | 1 | Cottonville + Homer |
|  | Cottonville + Homer | 12 June 1950 | 29 June 1950 | 1 | Cottonville + Homer |
|  | Cottonville + Homer | 12 June 1950 | 29 June 1950 | 1 | Cottonville + Homer |
|  | Cottonville + Homer | 12 June 1950 | 29 June 1950 | 1 | Cottonville + Homer |
|  | Cottonville + Homer | 12 June 1950 | 29 June 1950 | 1 | Cottonville + Homer |
|  | Cottonville + Virgil | 12 June 1950 | 29 June 1950 | 1 | Cottonville + Virgil |
|  | Cottonville | 12 June 1950 | 29 June 1950 | 1 | Cottonville |
|  | Effective June 30, 1950 |  |  |  | City of Cortland |
