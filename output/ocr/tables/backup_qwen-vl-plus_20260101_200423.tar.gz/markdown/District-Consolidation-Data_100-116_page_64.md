# Genesee County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 64)

**Extraction Method:** full

**Processed:** 2026-01-01T19:39:50.836277

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 34 | Byron | 9 October 1916 | 3 October 1916 | 3 | Byron |
| 4 | Stafford | 9 October 1916 | 4 October 1916 | 7 | Bergen |
| 8 | Byron | 24 October 1916 | 7 October 1916 | 22 | Bergen |
| 24 | Bergen | 15 June 1923 | 7 June 1923 | 23 | Bergen |
| 7 | C.R.S. |  |  |  |  |
| 16 | Pavilion | 15 October 1935 | 15 October 1935 | 1 | Pavilion, Bethany |
| 5 | Corning | 15 October 1935 | 15 October 1935 | 1 | Corning, Middlebury |
| 2 | Pavilion | 15 October 1935 | 15 October 1935 | 1 | Pavilion, Bethany |
| 11 | Middlebury | 15 October 1935 | 15 October 1935 | 1 | Middlebury, Wyoming |
| 23 | Alexander | 25 May 1937 | 11 June 1937 | 2 | Alexander, Batavia |
| 4 | Alexander | 25 May 1937 | 11 June 1937 | 2 | Alexander, Batavia |
| 7 | Batavia | 25 May 1937 | 11 June 1937 | 2 | Bethany, Darlington |
| 6 | Bethany | 25 May 1937 | 11 June 1937 | 2 | Bethany, Darlington |
| 11 | Batavia | 25 May 1937 | 11 June 1937 | 2 | Batavia, Alexander |
| 12 | Darion | 25 May 1937 | 11 June 1937 | 2 | Darion, Alexander |
| 15 | Elba | 25 May 1937 | 9 June 1937 | 1 | Elba, Byron |
| 14 | Elba | 25 May 1937 | 9 June 1937 | 1 | Elba, Batavia |
| 17 | Elba | 25 May 1937 | 9 June 1937 | 1 | Elba, Batavia |
| 6 | Oakfield | 25 May 1937 | 9 June 1937 | 1 | Oakfield, Stafford |
| 23 | Pamphlete | 23 August 1938 | 1 September 1938 | 2 | Pamphlete, Darion |
| 4 | Pamphlete | 23 August 1938 | 1 September 1938 | 2 | Pamphlete, Darion |
| 5 | Pamphlete | 23 August 1938 | 1 September 1938 | 2 | Pamphlete, Darion |
| 9 | Darion | 23 August 1938 | 1 September 1938 | 2 | Darion, Alexander |
| 11 | Batavia | 23 August 1938 | 1 September 1938 | 2 | Batavia, Alexander |
| 10 | Pamphlete | 23 August 1938 | 1 September 1938 | 2 | Pamphlete, Darion |
| 3 | C.R.S. | 25 May 1949 | 23 June 1949 | 1 | Oakfield |
| 2 | Lockfield | 25 May 1949 | 23 June 1949 | 1 | Lockfield |
| 3 | Alabama | 25 May 1949 | 23 June 1949 | 1 | Alabama |
| 10 | Alabama | 25 May 1949 | 23 June 1949 | 1 | Alabama |
| 14 | Ty (Village) | 25 May 1949 | 16 June 1949 | 1 | Le Roy (Plym) |
| 2 | Ty (Village) | 25 May 1949 | 16 June 1949 | 1 | Le Roy (Plym) |
| 3 | Hary | 25 May 1949 | 16 June 1949 | 1 | Le Roy (Plym) |
| 11 | Hary | 25 May 1949 | 16 June 1949 | 1 | Le Roy (Plym) |
