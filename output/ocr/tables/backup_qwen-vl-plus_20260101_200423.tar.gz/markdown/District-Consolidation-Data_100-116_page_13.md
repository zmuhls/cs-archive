# Cayuga County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 13)

**Extraction Method:** full

**Processed:** 2026-01-01T16:29:29.512386

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 5 4 6 | Scato | 3 September 1914 | 24 July 1914 | 5 Scato | and item |
| 12 3 | Genoa | 27 January 1915 | 25 January 1915 | 2 Genoa | King Ferry |
| 4 6 7 | Venice | 11 September 1914 | 25 September 1914 | 6 Genoa | notacized |
| 6 9 | Ledyard | 2 September 1919 | 2 September 1919 | 6 Ledyard |  |
|  | Parts of Summerhill and 2 Summerhill | 3 September 1920 | 25 September 1920 | 2 Summerhill |  |
|  | Scipio Venice | Cent. Rural Sch. | M. Y. 27 August 1920 | 4 Scipio, Venice |  |
|  | Scipio Ledyard | Out Cent. Rural Sch. 10 December 1925 | 3 January 1926 | 4 Scipio, Venice |  |
|  | Scipio Ledyard Venice | Meeting held 9 January 1926 | 29 January 1926 | 12 |  |
|  | Venice Ledyard | Designation of dist. | 29 January 1926 | 12 |  |
| 24 6 | Locke | 31 July 1926 | 6 June 1926 | 2 Locke |  |
|  | Part of 10 Sempronius 1 Sempronius | 31 July 1926 | 21 July 1926 | 13 Sempronius |  |
|  | Sempronius | 27 July 1927 | 27 July 1927 | 6 Sempronius | to take effect 1 August |
|  | Part of 20 Sempronius 4 1 Sempronius | 31 August 1927 | 31 August 1927 | 17 Sempronius |  |
|  | Genoa Venice | Landau 11 May 1931 Meeting | 22 June 1931 | 2 Genoa, Venice, Ledyard | Designation of dist. |
|  | Ledyard Venice | Meeting held 9 June 1931 | 22 June 1931 | 12 |  |
|  | Ledyard Venice | Meeting held 9 June 1931 | 22 June 1931 | 12 | Cayuga, Steaming, Imphius c. |
| C.R.S. | Springport | 17 October 1935 | 12 December 1935 | 1 Springport, Fleming, Aurelius, Ledyard | Designation of dist. |
| C.R.S. | Aurelius Fleming | 22 November 1935 | 22 November 1935 | 1 Springport, Fleming, Aurelius, Ledyard |  |
| C.R.S. | Mentz Montgumery | 20 May 1936 | 21 August 1936 | 4 Scipio, Venice, Ledyard |  |
| C.R.S. | Empire Montgumery | 24 January 1937 | 17 May 1937 | 4 Scipio, Venice, Ledyard |  |
| C.R.S. | Montgumery Throop | 10 February 1937 | 10 February 1937 | 1 Mentz, Montgumery, Brutus, Congrest, Cato, Aurelius |  |
|  | Brutus Montgumery | 5 October 1936 | 22 October 1936 | Throop | Laid out 5 October 1936 Meeting held 10 October 1936 Designation of dist. |
|  | Brutus Montgumery | 5 July 1937 | 5 July 1937 | Scipio | Transferred acceleration of boundaries |
