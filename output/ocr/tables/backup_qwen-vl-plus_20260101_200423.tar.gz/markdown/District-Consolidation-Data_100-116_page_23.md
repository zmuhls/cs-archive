# Chenango County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 23)

**Extraction Method:** full

**Processed:** 2026-01-01T19:31:25.935925

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 7 | Mc Donough | 1 May 1912 |  |  |  |
