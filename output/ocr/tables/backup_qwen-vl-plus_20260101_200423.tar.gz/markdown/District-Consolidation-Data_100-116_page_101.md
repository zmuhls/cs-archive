# Nassau County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 101)

**Extraction Method:** full

**Processed:** 2026-01-01T19:47:48.609295

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 192 | Oyster Bay | 7 December 1916 | 7 11 1916 10 153 1920 3 11 1916 | 9 | Oyster Bay |
|  | Hempstead | 16 4 17 | 22 1 1926 | 2 | Hempstead No. Hempstead |
|  | Hempstead | 13 24 6 30 | 5 5 1925 21 10 1925 | 15 | Oyster Bay The Hempstead |
|  | Oyster Bay | 16 11 1930 | 15 16 12 1931 | 19 | Oyster Bay |
|  | Hempstead | 7 8 1932 | 7 13 1932 | 19 | The Hempstead |
|  | Hempstead | 25 September 1934 | 1 March 1934 | 3 | Hempstead |
|  | Oyster Bay | 6 June 1950 |  | 19 | Oyster Bay |
