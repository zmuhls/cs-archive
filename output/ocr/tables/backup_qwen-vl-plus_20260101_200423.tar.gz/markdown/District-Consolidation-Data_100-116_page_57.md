# 103 County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 57)

**Extraction Method:** full

**Processed:** 2026-01-01T19:37:52.059963

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1,3,4,7,4,10 | Teunderoga | 19 June 1930 | 24 July 1930 | 1 | Teunderoga Compact and Hague, Warren Co. |
| 7 | Teunderoga + Hague | 2 July 1930 | 15 Dec 1930 | 1 | Elizabethtown |
| 2,4,11 | Elizabethtown | 25 July 1930 |  | 1 | Minerva Compact + Chester (Warren Co.) |
| 1,4,6,13 | Minerva | 13 Nov 1930 | 3 Jan 1931 | 1 |  |
| 7 | Chester | 2 Dec 1930 |  | 1 |  |
| 1,3,4,5,4,7,8 | North Hudson | 22 April 1931 | 22 Jan 1931 | 1 | Schroon |
| X | Schroon |  |  | 1 |  |
| 5,8,9,7,0,1 | Westport | 18 May 1931 |  | 1 | Assumption Fielder |
| 1 | Westport + Eqault |  |  | 1 |  |
| 3 | Westport + Moriah | 11 Jan 1931 |  | 1 | Designation Moriah, Elizabeth |
| 6 | Elizabethtown + Westport | 1 Jan 1931 |  | 1 |  |
| 7,6,2,1 | Essex + Lewis + Westport | 28 September 1931 | 28 December 1931 | 1 | Lewis |
| 5,4,11 | Lewis |  |  | 1 |  |
| 3, Crown Point | 15 July 1935 | 30 March 1935 | 3 | Crown Point | None |
|  | Crown Point | 30 March 1935 | 30 June 1936 |  | Appealed - Appellate Hist. and Vacating order reversed (Oct 18, 1935) |
| 3, Crown Point | 25 March 1936 |  | 3 | Crown Point | None |
| 40, 41 | Moriah | 5 April 1938 | 5 July 1938 | 1 | Moriah |
| 50 | Elizabethtown | 15 June 1938 | 15 Sept 1938 | 1 | Elizabeth Town |
| C.R.S. | Elizabethtown, Westport, Lewis |  |  | 1 | Elizabethtown, Westport, Lewis or Chesterfield |
| 2,3,4,9,7 | Elizabethtown + Lewis + Elderfield |  |  | 1 |  |
| 5 | Lewis + Elderfield |  |  | 1 |  |
| 12 | Moriah | 3 February 1939 | 16 May 1939 | 1 | Moriah |
| 1,2,4,9,5,7,8,9 | Willsboro | 2 October 1941 | 29 October 1941 | 1 | Willsboro, Essex or Lewis |
| 3 | Willsboro + Lewis |  |  | 1 |  |
| 10 | Chesfield + Williboro | 18 July 1942 | 20 October 1942 | 1 | Clinton Co. |
| 13 | Chesfield (Clinton Co.) |  |  | 1 |  |
| 1 | Minerva | 21 March 1944 | 1 July 1944 | 1 | Minerva |
