# Cattaraugus County

**Table Type:** Town School Units

**Source:** District-Consolidation-Data_100-116.pdf (Page 7)

**Extraction Method:** full

**Processed:** 2026-01-01T15:13:35.245167

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Dayton | U.F.S. 2 and 3,4,7+10 Dayton |  |  |  |
| 2 | Dayton | U.F.S. 9 and 1,5,6+8 Dayton |  |  |  |
