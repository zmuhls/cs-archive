# Monroe County

**Table Type:** Central Rural Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 97)

**Extraction Method:** full

**Processed:** 2026-01-01T19:47:15.041369

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| CRS | W.S. dist. of Parma | Laid out Meeting held |  | 1 | Parma |
|  | C.S. dist. 1,2,5,7,9,10,11,12,13 Women 5,7,11 Member 6,7,13 Green 10 Chillicothe |  |  |  |  |
| CRS | H.S. dist. Ogden | Laid out Meeting held |  | 1 | Ogden |
|  | C.S. dist. 2,5,12,18 Ogden 3,8,13 Parma (2nd meeting) 2 Gatta in Green (2nd meeting) |  |  |  |  |
| CRS | H.S. dist. + Rigas, Ogden + Sweden | Laid out May 23, 1950 Meeting held June 14, 1950 |  | 1 | Rigas, Ogden, Chillicothe, Sweden |
|  | C.S. dist. 1,5,6,10 Rigas 7 Ogden + Rigas 10 Ogden + Chillicothe 6 Chillicothe + Sweden 4 Chillicothe 6 Chillicothe + Rigas |  |  |  |  |
