# Jefferson County

**Table Type:** Town School Units

**Source:** District-Consolidation-Data_100-116.pdf (Page 77)

**Extraction Method:** full

**Processed:** 2026-01-01T19:42:27.368702

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Ellisburg | U.F.S. 25 | 1,2,3,4,5,6,7,12,17 & 27 |  |  |
| 2 | Ellisburg | 18 | 8,9,10,13,14,15,16,19,20,21,22,23,24 & 26 |  |  |
| 1 | Lyme |  | 1,2,8,9 & 10 |  |  |
| 2 | Lyme |  | 3,6,7,11,12,13,14 & 15 |  |  |
| 1 | Rutland |  | 4,5 & 12 |  |  |
| 2 | Rutland |  | 1,2,3,6,9,10 & 11 |  |  |
