# Madison County County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 89)

**Extraction Method:** full

**Processed:** 2026-01-01T19:44:30.918915

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Smithfield | 25 June 1896 |  | 5 |  |
| 3 | Hamilton | 22 October 1912 |  | 5 |  |
| 1 | Fenner | 21 October 1896 |  | 9 |  |
