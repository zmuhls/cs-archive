# Madison County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 91)

**Extraction Method:** full

**Processed:** 2026-01-01T19:44:52.898826

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 245 | Georgetown | 23 January 1914 | 15 April 1914 | 2 | Georgetown |
| 4589 | Lebanon | 8 April 1914 | 8 May 1914 | 4 | Lebanon |
| 576 | Nelson | 12 October 1914 | 16 October 1914 | 5 | Nelson |
| 173 | Smithfield | 25 August 1914 | 14 October 1914 | 1 | Smithfield |
| 146 | Lebanon | 4 September 1915 | 4 October 1915 | 16 | Lebanon |
| 2413 | Eaton | 3 May 1915 | 15 May 1915 | 2 | Eaton |
| 145 | Georgetown | 14 August 1916 | 18 September 1918 | 1 | Georgetown |
| 9126 | Brookfield | 18 September 1918 | 26 September 1919 | 9 | Brookfield |
| 5412 | Stockbridge | 5 June 1919 | 26 April 1920 | 5 | Stockbridge |
| 10517 | Eaton | 8 September 1919 | 10 August 1920 | 10 | Eaton |
| 649 | Lenox | 10 August 1920 | 29 July 1921 | 9 | Lenox |
| 5134 | Brookfield | 6 September 1921 | 6 September 1921 | 5 | Brookfield |
| 3689 | Columbus | 6 September 1921 | 6 September 1921 | 5 | Brookfield |
| 4 | Georgetown | 1 April 1922 | 1 July 1922 | 1 | Georgetown |
| 4 | Smithfield | 29 May 1923 | 23 August 1923 | 4 | Smithfield |
| 12840 | Stockbridge | 31 July 1922 | 18 September 1922 | 1 | Stockbridge |
| 1246 | Stockbridge | 18 September 1922 | 32 September 1922 | 1 | Stockbridge |
| 3 | DeRuyter | 31 July 1925 | 5 May 1927 | 6 | DeRuyter |
| 69 | Georgetown | 5 May 1927 | 11 November 1927 | 5 | DeRuyter |
| 1 | Madison | 19 June 1926 | 9 November 1926 | 1 | DeRuyter |
| 15 | Hamilton | 4 September 1926 | 1 July 1926 | 1 | DeRuyter |
| 144 | DeRuyter | 24 August 1927 | 12 August 1927 | 1 | DeRuyter |
| 68 | Nelson | 24 August 1927 | 16 August 1927 | 11 | Nelson |
| 128912 | Stockbridge | 14 May 1928 | 31 July 1928 | 12 | Stockbridge |
| 610914 | Stockbridge | 14 May 1928 | 14 May 1928 | 12 | Stockbridge |
| 56 | Lebanon | 14 May 1928 | 14 May 1928 | 6 | Lebanon |
| 916122 | Brookfield | 14 May 1928 | 10 January 1929 | 9 | Brookfield |
| 14 | Cazenovia | 30 March 1929 | 20 April 1929 | 2 | Cazenovia |
| 15 | Cazenovia | 30 March 1929 | 5 September 1929 | 2 | Cazenovia |
| 243 | Nelson | 27 May 1929 | 27 May 1929 | 11 | Nelson |
| 9411 | Nelson | 27 May 1929 | 27 May 1929 | 11 | Nelson |
