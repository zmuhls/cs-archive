# Hamilton County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 70)

**Extraction Method:** full

**Processed:** 2026-01-01T19:40:51.774595

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 3 | Arietta & Wells | 26 September 1914 | 3 August 1915 | 2 Wells | No. new dist. |
| 46 | Minerra, Essex Co. | 21 August 1915 | 28 April 1916 | 5 Indian Lake & Wells |  |
| 11 | Indian Lake, Ham.C. | 1 Central Rural.Sch. design. as 1 | 1 May 1916 | 2 Benson |  |
| 1,2,3,4,5 | Wells | 24 April 1916 | 13 May 1916 | 1 Lake Pleasant |  |
|  | Hope (C.R.S) | 23 July 1927 | 4 July 1927 | 1 Wells |  |
| 1,3,4,5,7 | Indian Lake | 16 June 1928 | 21 July 1928 | 1 Indian Lake |  |
| 1,2,6,8 | Indian Lake | 1 May 1929 | 3 July 1929 | 1 Benson |  |
| 1 | Benson | 12 May 1931 | 11 May 1931 | 1 Benson |  |
| 3 | Wells, Arietta Rep. | 30 June 1936 | 19 January 1937 | 1 Wells |  |
|  | Munichampton (Fulton Co.) | 30 September 1944 |  | 1 Northampton |  |
| 1,2 | Morehouse Only | July 1945 | 17 October 1945 | 2 Morehouse |  |
|  | King Lake x Arietta Dist. | 25 July 1947 | 27 April 1948 | 1 King Lake |  |
|  | Arietta | 17 November 1948 | 1 February 1949 | 1 Arietta |  |
