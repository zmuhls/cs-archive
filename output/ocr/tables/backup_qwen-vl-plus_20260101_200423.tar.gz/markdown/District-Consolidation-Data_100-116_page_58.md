# Franklin County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 58)

**Extraction Method:** full

**Processed:** 2026-01-01T19:37:57.295322

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 8 | Dickinson | 23 July 1907 |  | 3 |  |
| 1 | Fort Covington | 3 October 1864 |  | 9 |  |
| 1 | Harrietstown | 20 January 1890 |  | 5 |  |
| 16 | Burke | In papers |  |  |  |
