# Livingston County

**Table Type:** Town School Units

**Source:** District-Consolidation-Data_100-116.pdf (Page 86)

**Extraction Method:** full

**Processed:** 2026-01-01T19:44:01.629235

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Livonia | U.F.S. 9 and 3,5,7,8,10+11 | 4 1,6 13 |  |  |
| 2 | Livonia |  |  |  |  |
| 1 | Nunda | U.F.S. 1 2,4,8,9,10+11 | 12 3,5,6+7 |  |  |
| 2 | Nunda |  |  |  |  |
