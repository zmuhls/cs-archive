# County County

**Table Type:** Unknown

**Source:** District-Consolidation-Data_100-116.pdf (Page 88)

**Extraction Method:** full

**Processed:** 2026-01-01T19:44:26.645221

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 10 | West Fanta | 1 Sept. | 1944 | March Danaville | CRS |
| 9 | Danaville | Effective Nov. | 15, 1944 | North Danaville | CRS |
| 10 | Danaville | Effective Nov. | 15, 1944 | North Danaville | CRS |
| 3 | North Danaville | Effective Aug. | 15, 1945 | CRS | CRS |
| 6 | Summit & Perry | Effective Oct. | 1, 1945 | North Danaville | CRS |
| 9 | Summit | Effective Nov. | 30, 1945 | North Danaville | CRS |
| 5 | Grosland | Laid out Apr. | 23, 1947 | Meeting held May 19, 1947 | 1 Generoso |
| 4 | Grosland |  |  |  |  |
| 1, 6, 7, 8, 9, 10 | Grosland |  |  |  |  |
| 12, 3, 5, 8 | Grosland |  |  |  |  |
| 5 | California | Laid out June | 7, 1950 | Meeting held June 23, 1950 | CRS |
| 4 | California |  |  | Whitman & Rip (Manville) | CRS |
| 2, 3 | California |  |  | Faulkner City (Generoso) | CRS |
| 1 | California |  |  | Faulkner City (Generoso) | CRS |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
