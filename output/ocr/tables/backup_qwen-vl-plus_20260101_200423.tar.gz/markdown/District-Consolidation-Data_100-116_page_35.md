# Columbia County

**Table Type:** Town School Units

**Source:** District-Consolidation-Data_100-116.pdf (Page 35)

**Extraction Method:** full

**Processed:** 2026-01-01T19:34:00.934539

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Kinderhook | U.F.S. 1 and nos. 6 + 7 |  |  |  |
| 2 | Kinderhook | U.F.S. 2 and nos. 3 4 5 + 8 |  |  |  |
