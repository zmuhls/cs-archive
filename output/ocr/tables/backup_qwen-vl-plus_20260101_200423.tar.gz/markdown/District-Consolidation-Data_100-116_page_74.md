# Herkimer County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 74)

**Extraction Method:** full

**Processed:** 2026-01-01T19:42:11.139414

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 2,3,4,6 | German Flatts | Laid out 11 May 1937 |  | C.R.S. 2 German Flatts Little Falls Columbia |  |
| 5,9 | German Flatts & Little Falls | Meeting held 26 May 1931 |  | C.R.S. 1 Winfield |  |
| 7,12 | Columbia German Flatts | Designation 4 June 1937 |  | C.R.S. 2 Fairfield, Newport, Norway, Schuyler, and Herkimer Co. and Deerfield Onida |  |
| 30 | Winfield | 31 March 1938 to take effect 1 July 1938 | 1 June 1938 to take effect 1 Sept 1938 | C.R.S. Winfield |  |
| 5 | Richfield (Chenango Co.) |  |  | C.R.S. Richfield |  |
| 5,7,10,11 | Newport | Laid out 26 May 1938 | Meeting held 16 June 1938 Designation of dist. 23 June 1938 | C.R.S. 1 Winfield |  |
| 9 | Newport & Schuyler |  |  | C.R.S. 2 Fairfield, Newport, Norway, Schuyler, and Herkimer Co. and Deerfield Onida |  |
| 10 | Newport (Chenango Co.) |  |  | C.R.S. 1 Stark |  |
| 11 | Homer (Chenango Co.) |  |  | C.R.S. 2 Paris, Oneida Co. |  |
| 14 | Homer (Chenango Co.) | 31 March 1939 to take effect 1 July 1939 | 28 Aug 1939 | C.R.S. 1 Winfield, Otsego Co. |  |
| 16 | Richfield (Chenango Co.) | 29 May 1939 | 22 Sept 1939 | C.R.S. 1 Stark |  |
| 17 | Winfield German Flatts | 22 June 1939 |  | C.R.S. 1 Winfield |  |
| 18 | Winfield | 1 April 1940 | 1 July 1940 | C.R.S. 1 Stark |  |
| 19 | Richfield (Chenango Co.) | 16 May 1940 | 10 August 1940 | C.R.S. 2 Paris, Oneida Co. |  |
| 20 | Onteora | 20 June 1940 | 26 Sept 1940 | C.R.S. 1 Winfield, Otsego Co. |  |
| 21 | Kitchfield | 12 June 1940 | 11 Sept 1940 | C.R.S. 1 Stafford, Fulton Co. |  |
| 22 | Parks (Oneida Co.) | 5 Mar 1941 | 10 Feb 1941 | C.R.S. 2 Manheim-Salisbury |  |
| 23 | Stratford (Sullivan Co.) | 16 Feb 1942 | 30 June 1942 | C.R.S. 1 Homer (Chenango Co.) |  |
| 23,5,7,10 | Salisbury | Laid out 21 April 1942 | Meeting held 4 May 1942 Designation of dist. 24 July 1942 | C.R.S. 1 Winfield |  |
| 18,6 | Salisbury | 15 May 1942 to take effect 15 August 1942 | 1 Oct 1942 | C.R.S. 2 Fairfield |  |
| 8,9 | Newport | 26 June 1942 | 15 Nov 1942 | C.R.S. 1 Amenia |  |
| 6 | Winfield | 30 August 1942 |  | C.R.S. 3 Johnville-Montgomery Co. |  |
| Part of | Johnville | Effective April 2, 1945 |  | C.R.S. 1 Winfield |  |
| 13 | Amenia (Oneida Co.) | Effective August 1, 1945 |  | C.R.S. 1 Amenia |  |
| 17 | Peter (Otsego Co.) | Effective October 1, 1945 |  | C.R.S. 3 Johnville-Montgomery Co. |  |
| 23 | Shenango (Montgomery Co.) | Effective October 1, 1945 |  | C.R.S. 1 Winfield |  |
| 3 | Shenango (Montgomery Co.) | Effective October 1, 1945 |  | C.R.S. 1 Winfield |  |
| 1 | Winfield | Effective October 1, 1945 |  | C.R.S. 1 Winfield |  |
