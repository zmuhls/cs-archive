# Montgomery County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 99)

**Extraction Method:** full

**Processed:** 2026-01-01T19:47:28.634837

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 14 | Minden | 18 March 1893 |  | 5 |  |
| 12 | Amsterdam | 24 March 1866 |  | 3 |  |
| 7 | Anajoharie | 24 October 1872 |  |  |  |
| 3 | Palestine | 30 June 1948 |  |  | (Copy of papers filed 10/25/52) |
