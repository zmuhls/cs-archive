# Madison County

**Table Type:** Town School Units

**Source:** District-Consolidation-Data_100-116.pdf (Page 90)

**Extraction Method:** full

**Processed:** 2026-01-01T19:44:36.203426

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Brookfield | U.F.S. 12 and 15,20,23,27,28 |  |  |  |
| 2 | Brookfield | U.F.S. 9 | 2,3,16,17,18,19,21,22,24,26 |  |  |
| 3 | Brookfield | U.F.S. 5 | 7,10,13,14,25,29 |  |  |
| 1 | Eaton | U.F.S. 2 | 1,3,6,11,12,16 |  |  |
| 2 | Eaton | U.F.S. 8 | 4,5,7,9,10,14,15,17 |  |  |
