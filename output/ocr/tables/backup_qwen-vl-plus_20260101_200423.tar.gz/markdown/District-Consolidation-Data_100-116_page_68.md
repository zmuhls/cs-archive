# Greene County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 68)

**Extraction Method:** full

**Processed:** 2026-01-01T19:40:40.481334

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 2 | Prattville T Rosburg | 21 December 1943 | 1 April 1944 |  | CRS. Gilboa-Schoharie Co. |
|  | Gilboa (Schoharie) |  |  |  | CRS. Gilboa |
|  | Prattville Rynfort |  |  |  | CRS. Gilboa |
|  | Gilboa (Schoharie Co) |  |  |  | CRS. Gilboa |
|  | Prattville & Ashland |  |  |  | CRS. Gilboa |
|  | Ashland |  |  |  | CRS. Gilboa |
|  | Windham |  | 25 February 1944 | 1 June 1944 | CRS. Windham |
|  | Prattville |  |  |  | CRS. Windham |
|  | Waterloo (Albany Co) |  | 30 Sept. 1944 |  | CRS. Greenville |
|  | Greenville |  |  |  | CRS. Greenville |
|  | U.S. Sub | Laid out June 17, 1947 | Meeting held June 30, 1947 |  | CRS. Copseck |
|  | Cohoes |  |  |  |  |
|  | Cohoes |  |  |  |  |
|  | New Baltimore |  |  |  |  |
