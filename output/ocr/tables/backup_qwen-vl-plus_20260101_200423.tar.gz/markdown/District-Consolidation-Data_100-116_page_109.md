# Oneida County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 109)

**Extraction Method:** full

**Processed:** 2026-01-01T19:49:46.744113

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 4128 | Paris | 24 June 1913 | 16 June 1914 | 4 | Paris |
| 485 | Paris | 24 June 1915 | 16 June 1915 | 4 | Paris |
| 911 | Paris | 24 June 1916 |  | 9 | Paris |
| 12514 | Sangerfield | 20 August 1915 | 11 February 1916 | 12 | Sangerfield |
| 6416 | Western | 5 August 1915 | 11 February 1916 | 16 | Western |
| 6415 | Kirkland | 34 September 1916 | 9 September 1916 | 6 | Kirkland |
| 6414 | Boonville | 7 September 1915 | 1 September 1915 | 6 | Boonville |
| 6412 | Vernon | 13 February 1917 | 28 March 1919 | 6 | Vernon |
| 179 | Trenton | 28 March 1919 | 13 February 1919 | 10 | Trenton |
| 45610 | Marshall | 9 June 1919 | 12 July 1920 | 4 | Marshall |
| 4914 | Boonville | 30 April 1921 | 12 July 1920 | 11 | Boonville |
| 115 | Lee | 16 May 1922 | 30 April 1921 | 4 | Lee |
| 3411 | Westmoreland | 24 September 1922 | 16 May 1922 | 1 | Westmoreland |
| 4510 | Forestport | 28 April 1923 | 28 April 1923 | 3 | Forestport |
| 710 | Forestport | 28 April 1923 | 28 April 1923 | 3 | Forestport |
| 243 | Vernon | 26 April 1924 | 26 April 1924 | 3 | Vernon |
| 249 | Verona | 23 August 1924 | 23 August 1924 | 9 | Verona |
| 10 | Verona | 16 September 1926 | 16 September 1926 | 10 | Verona |
| 124 | New Hartford | 16 August 1926 | 16 August 1926 | 1 | New Hartford |
| 2 | Deerfield | 17 October 1926 | 17 October 1926 | 6 | Deerfield |
| 6413 | Lee | 3 May 1927 | 3 May 1927 | 6 | Lee |
| 6411 | Florence | 21 April 1927 | 21 April 1927 | 8 | Camden |
| 10711 | Remsen | 21 January 1928 | 21 January 1928 | 11 | Remsen |
| 1410 | Forestport | 28 February 1928 | 28 February 1928 | 10 | Forestport |
| 12549 | Sangerfield | 28 October 1928 | 28 October 1928 | 1 | Sangerfield |
| 45 | Marshall | 13 November 1928 | 13 November 1928 | 1 | Marshall |
| 6413 | Annsville | 25 January 1929 | 25 January 1929 | 6 | Annsville |
| 4 | Madison | 28 June 1929 | 28 June 1929 | 1 | Madison |
| 641 | Paris | 28 June 1930 | 28 June 1930 | 2 | Paris |
| 458 | Bridgewater | 31 July 1930 | 31 July 1930 | 2 | Bridgewater |
| 1 | Bridgewater | 28 August 1930 | 28 August 1930 | 1 | Bridgewater |
| 20 | Paris | 31 August 1930 | 31 August 1930 | 1 | Paris |
