# Jefferson County County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 78)

**Extraction Method:** full

**Processed:** 2026-01-01T19:42:44.630432

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 9+10 | Wilna | 30 October 1913 | 9-18 1914 | 10-12 1914 | 13 1914 |
| 9+10 | Philadelphia | 2 September 1915 | 9-10 1915 | 84 1977 | 14 1916 |
| 10+16 | Lyme | 1 August 1914 | 10-16 1914 | 60 1922 | 15 1916 |
|  | Wilna | 9 March 1923 | 9-23 1923 | 23 1923 | 17 1916 |
|  | Adams & Rodman | 8 December 1925 | 8-12 1925 | 71 1926 | 3 Wilna |
| 6+8 | Antwerp | 8 July 1926 | 8-12 1926 | 71 1926 | 6 Antwerp |
|  | Ellisburg & Lorraine | 27 January 1929 | 27-1 1929 | 55 1929 | Central Sch. Dist. No. 1 of the Towns of Ellisburg and Lorraine |
|  | Lorraine & Ellisburg | 24 September 1930 | 24-9 1930 | 112 1930 | Design. of dist. 24 June 1929 |
|  | Caye Vincent | 16 September 1930 | 16-9 1930 | 123 1930 | 15 Caye Vincent |
|  | Rutland | 1+3 Rutland | 1+3 1930 | 123 1930 | 1 Rutland |
|  | Henderson | 18 April 1930 | 18-4 1930 | 56 1930 | Meeting Field |
|  | Henderson + Ellisburg | 24 April 1931 | 24-4 1931 | 26 1931 | Ellisburg, Henderson |
|  | Ellisburg & Henderson | 22 December 1930 | 22-12 1930 | 27 1930 | Design. of dist. 22 Dec. 1930 |
|  | Ellisburg, Adams | 30 April 1931 | 30-4 1931 | 32 1931 | Design. of dist. 3 June 1931 |
|  | Adams & Rodman | 15 June 1931 | 15-6 1931 | 13 1931 | Lorraine Rodman |
|  | Adams & Rodman | 14 July 1931 | 14-7 1931 | 16 1931 | Ellisburg |
|  | Rutland | 29 January 1933 | 29-1 1933 | 13 1933 | Order revoked 13 Jan. 1933 |
|  | Waltmanstown + Pamelia | 6 May 1933 | 6-5 1933 | 10 1933 | 10 Rodman |
|  | Waltmanstown + Pamelia | 15 February 1933 | 15-2 1933 | July 1933 | 7 Portland 15 Dennisfield 15 Brownsville |
|  | Rodman | 15 October 1933 | 15-10 1933 | 15 1933 | 8 Rodman |
|  | Ellisburg | 4 September 1935 | 4-9 1935 | 4 1936 | 2 Ellisburg |
|  | Ellisburg | 28 May 1936 | 28-5 1936 | 31 1936 | 2 Ellisburg |
|  | Ellisburg | 27 June 1936 | 27-6 1936 | 25 1936 | 2 Ellisburg |
|  | Ellisburg | 27 June 1936 | 27-6 1936 | 25 1936 | 2 Ellisburg |
|  | Adams | 22 July 1937 | 22-7 1937 | 22 1937 | 5 1937 |
|  | Adams | 11 September 1937 | 11-9 1937 | 5 1937 | 10 1937 |
|  | Adams | 11 June 1937 | 11-6 1937 | 5 1937 | 10 1937 |
