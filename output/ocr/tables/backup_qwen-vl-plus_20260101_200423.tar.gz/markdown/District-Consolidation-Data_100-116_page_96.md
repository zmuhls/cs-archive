# County County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 96)

**Extraction Method:** chunked

**Processed:** 2026-01-01T19:47:07.683428

---

| No. of dist. | NAME OF TOWN | DATE OF SCHOOL-MEETING ORGANIZING-DISTRICT | DATE ON WHICH PAPERS WERE APPROVED AT DEPARTMENT | No. new dist. |
| --- | --- | --- | --- | --- |
| 3,5 + 10 | Rush | 5 August 1919 | 3 August 1919 | 10 Rush |
| 4 + 15 | Hamlin | 30 April 1919 | 10 April 1919 | 6 Hamlin |
| 6 + 4 | Riga | 25 June 1923 | 4 June 1923 | 4 Riga |
|  | Ogden | 29 August 1918 | 22 August 1918 | 7 Ogden |
|  | Sweden | 19 July 1927 | 17 July 1927 | 1 Sweden |
| 1,2,3,4,7 | Clarkson | Designation of dist. 17 Aug. 1927 | 24 July 1927 | Parma & Clarkson |
| 3,7,9,8 | Parma | Laid out 30 April 1925 | 30 April 1925 | Brighton |
| 3,11,16 | Greece C.R.S. | Meeting held 21 March 1928 | 15 September 1944 | Greece |
|  | Webster | Laid out April 27, 1948 | Meeting held May 26, 1948 |  |
|  | Henrietta | Laid out May 26, 1948 | Meeting held June 24, 1948 | Henrietta |
|  | Penfield | April 1950 - October 1, 1950 | Meeting held Oct 23, 1946 | Penfield |
|  | Rush | Laid out Sept 30, 1946 | Meeting held Nov 14, 1946 | Rush |
