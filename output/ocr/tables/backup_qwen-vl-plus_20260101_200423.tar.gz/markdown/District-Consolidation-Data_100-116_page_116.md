# Ouradaga County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 116)

**Extraction Method:** full

**Processed:** 2026-01-01T19:56:47.599599

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Dewitt | annexed to Common | 3 Aug 1954 | 3 | Dewitt |
| 2 | Dewitt |  | 3 Aug 1954 | 3 | Dewitt |
