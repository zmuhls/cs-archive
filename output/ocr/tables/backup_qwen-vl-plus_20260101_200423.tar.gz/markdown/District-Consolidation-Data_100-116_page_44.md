# Delaware County

**Table Type:** Central Rural Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 44)

**Extraction Method:** full

**Processed:** 2026-01-01T19:35:56.856159

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| C.R.S | Colchester | 21 July 1938 | 3 Aug 1938 | 1 | Colchester, Hanover, Hancock, Walton |
|  | Colchester & Hanover | 2 Aug 1938 | 20 July 1938 | 2 | Andes, and Torrington |
|  | Andes | 3 Aug 1938 |  | 3 | Delaware County |
| C.R.S | Stanford | 11 Aug 1938 | 30 Aug 1938 | 2 | Stanford, Hotright, Delhi, Harperfield |
|  | Worthington & Steand | 24 May 1938 |  | 4 | Meredith & Bonina |
|  | Stanford & Hotright | 24 May 1938 |  | 5 |  |
|  | Harnerfield | 15 Aug 1938 |  | 6 |  |
|  | Harpfield & Hotright | 15 Aug 1938 |  | 7 |  |
| C.R.S | Middletown | 20 July 1938 | 15 Aug 1938 | 1 | Middletown, Andes, Borina, Roxbury |
|  | Middletown & Andes | 15 Aug 1938 |  | 2 | Delaware Co., Hadenberg |
|  | Andes & Middletown | 25 Aug 1938 |  | 3 | Ulster Co. |
|  | Harpfield & Middletown | 25 Aug 1938 |  | 4 |  |
|  | Rosburg & Middletown | 25 Aug 1938 |  | 5 |  |
| C.R.S | Davenport | 10 Sept 1938 | 22 Sept 1938 | 1 | Davenport, Hotright, Harnerfield, Meredith |
|  | Davenport & Hotright | 21 Sept 1938 |  | 2 | Delaware Co., Maryland |
|  | Davenport, Harnerfield & Mayfield | 21 Sept 1938 |  | 3 | Worcester, Winkles, Summertown |
|  | Hotright & Davenport | 21 Sept 1938 |  | 4 | Schodack Co. |
|  | Summit, Warrington & Harnerfield | 21 Sept 1938 |  | 5 |  |
| C.R.S | Sanford | 20 March 1939 | 1 July 1939 | 1 | Sanford |
|  | Sanford & Torrington | 20 March 1939 | 30 June 1939 | 2 | Roxbury |
| C.R.S | Middletown | 21 March 1939 | 1 July 1939 | 1 | Middletown |
|  | Andes & Middletown | 21 March 1939 | 20 Aug 1940 | 2 | Andes |
|  | Andes & Delhi | 11 May 1940 | 20 Aug 1940 | 3 | Delhi & Bonina |
|  | Andes, Delhi & Bonina | 17 May 1940 | 20 Aug 1940 | 4 |  |
|  | Middletown | 17 May 1940 | 20 Aug 1940 | 5 |  |
| C.R.S | Sidney | 16 April 1941 | 15 June 1941 | 1 | Sidney, Franklin, Unadilla, Oak Co. |
|  | Sidney & Unadilla | 3 May 1941 | 20 Aug 1941 | 2 | Unadilla, Utica Co. |
|  | Sidney, Franklins & Unadilla | 3 May 1941 | 20 Aug 1941 | 3 | Delaware Co. |
|  | Unadilla | 15 May 1941 | 15 Aug 1941 | 4 | Guilford, Chenango Co. |
| C.R.S | Franklin | 16 May 1941 | 20 Aug 1941 | 1 | Franklin |
|  | Franklin | 24 May 1941 | 25 Aug 1941 | 2 |  |
|  | Franklin | 8 May 1941 | 15 Aug 1941 | 3 |  |
|  | Franklin | 25 March 1942 | 1 July 1942 | 4 | Unadilla (Utica Co.) |
|  | Franklin | 22 May 1942 | 2 Sept 1942 | 5 | Andes |
|  | Franklin | 24 Aug 1943 | 24 Nov 1943 | 6 |  |
