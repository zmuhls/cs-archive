# Clinton County

**Table Type:** Town School Units

**Source:** District-Consolidation-Data_100-116.pdf (Page 30)

**Extraction Method:** full

**Processed:** 2026-01-01T19:33:24.125716

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Dannemora | U.F.S. 1 and 243 |  |  |  |
| 2 | Dannemora | U.F.S. 4 and 5 |  |  | Chagy |
