# Hamilton County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 69)

**Extraction Method:** full

**Processed:** 2026-01-01T19:40:43.686525

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 2 | Long Lake | 18 December 1920 |  | 5 |  |
