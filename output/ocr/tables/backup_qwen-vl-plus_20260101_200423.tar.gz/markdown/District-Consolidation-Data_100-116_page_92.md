# Madison County County

**Table Type:** Central Rural Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 92)

**Extraction Method:** full

**Processed:** 2026-01-01T19:45:28.980360

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | C.R.S. | 5 June 1929 | 21 July 1929 | 1 | Central Sch. dist. Fennimore, Nelson |
| 2 | Smyrna | 24 June 1929 | 25 June 1929 | 2 | Hamilton |
| 3 | Sheboygan Falls | 24 June 1929 | 25 June 1929 | 2 | Hamilton |
| 4 | Lebanon | 24 June 1929 | 25 June 1929 | 2 | Hamilton |
| 5 | Madison | 24 June 1929 | 25 June 1929 | 2 | Hamilton |
| 6 | Hamilton | 22 May 1930 | 1 September 1930 | 14 | Hamilton |
| 7 | Hamilton | 22 May 1930 | 1 September 1930 | 14 | Hamilton |
| 8 | Stockbridge | 30 June 1930 | 15 September 1930 | 1 | Stockbridge |
| 9 | Stockbridge | 30 June 1930 | 15 September 1930 | 1 | Stockbridge |
| 10 | Brookfield | 15 September 1930 | 10 December 1930 | 13 | Brookfield |
| 11 | Brookfield | 15 October 1930 | 15 January 1931 | 9 | Brookfield |
| 12 | Brookfield | 10 November 1930 | 9 November 1930 | 10 | Hamilton |
| 13 | De Ruyter | 4 December 1930 | 14 April 1931 | 7 | De Ruyter |
| 14 | De Ruyter | 31 December 1930 | 14 April 1931 | 7 | De Ruyter |
| 15 | Madison | 30 December 1930 | 23 January 1931 | 12 | Madison |
| 16 | Augusta (Nudie) | 20 December 1930 | 23 January 1931 | 12 | Madison |
| 17 | Hamilton | 15 May 1931 | 20 August 1931 | 1 | Hamilton |
| 18 | Coganomia | 27 May 1931 | 31 August 1931 | 7 | Coganomia |
| 19 | Brookfield | 20 June 1931 | 25 September 1931 | 13 | Brookfield |
| 20 | Blanchfield (Althoeg) | 27 June 1931 | 10 December 1931 | 2 | Blanchfield (Althoeg) |
| 21 | De Ruyter (Madison) | 26 May 1931 | 17 September 1931 | 4 | De Ruyter |
| 22 | Angler (Cotter) | 26 May 1931 | 17 September 1931 | 4 | De Ruyter |
| 23 | Georgetown (Madison) | 30 June 1931 | 17 September 1931 | 4 | Georgetown |
| 24 | Smyrna | 15 May 1931 | 1 September 1931 | 2 | Hamilton |
| 25 | Lebanon | 1 September 1931 | 1 December 1931 | 2 | Hamilton |
| 26 | Stockbridge | 1 September 1931 | 1 December 1931 | 2 | Hamilton |
| 27 | Blanchfield (Althoeg) | 25 September 1931 | 25 October 1931 | 12 | Brookfield |
| 28 | Coganomia | 16 July 1931 | 15 October 1931 | 12 | Brookfield |
| 29 | Coganomia | 15 May 1933 | 15 August 1933 | 12 | Brookfield |
| 30 | Coganomia | 10 July 1933 | 15 October 1933 | 12 | Brookfield |
| 31 | Coganomia | 14 July 1933 | 15 October 1933 | 12 | Brookfield |
| 32 | Cathedral | 10 July 1933 | 15 October 1933 | 12 | Brookfield |
| 33 | Stockbridge | 4 June 1934 | 4 September 1934 | 1 | Stockbridge |
| 34 | Hamilton | 20 June 1934 | 1 November 1934 | 9 | Lebanon |
| 35 | Hamilton | 15 September 1934 | 15 December 1934 | 9 | Lebanon |
| 36 | Hamilton | 8 November 1934 | 1 February 1935 | 1 | Hamilton |
