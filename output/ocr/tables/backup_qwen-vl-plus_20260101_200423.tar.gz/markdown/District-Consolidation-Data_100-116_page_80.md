# County County

**Table Type:** Central Rural Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 80)

**Extraction Method:** full

**Processed:** 2026-01-01T19:43:03.670912

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| CRS | Alexandria | Laid out April 30, 1945 | Meeting Held June 1, 1945 | 2 | Alexandria |
| CRS | Alexandria | May 18, 1950 | Effective May 1950 | 7 | Rodman & Seneca |
|  |  | Apr 2 1953 |  | 3 | Adams etc |
