# Delaware County

**Table Type:** Town School Units

**Source:** District-Consolidation-Data_100-116.pdf (Page 41)

**Extraction Method:** full

**Processed:** 2026-01-01T19:35:02.797565

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Middletown | U.F.S.17 and 3,6,9,10,11,12,13,15,16,18,20,22,23,24,25,26 |  |  |  |
| 2 | Middletown | U.F.S.21 and 5,7,8,14,19 |  |  |  |
| 1 | Stamford | U.F.S.1 and dist. no 7 |  |  |  |
| 2 | Stamford | U.F.S.4 and 2,3,5,6,8,9,10 |  |  |  |
