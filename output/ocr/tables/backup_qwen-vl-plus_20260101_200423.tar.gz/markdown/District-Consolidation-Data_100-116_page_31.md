# Clinton County

**Table Type:** Central Rural Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 31)

**Extraction Method:** full

**Processed:** 2026-01-01T19:33:29.703965

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 128,12,137,14 | Chazy | 6 July 1915 | 20 July 1916 |  | Chazy Central Consolidated Rural Sch. |
| 6,7,29,13 | Champlain | 6 January 1916 | 7 January 1916 |  | Chazy = Champlain & Mooers |
| 8,9,41 | Mooers |  |  |  |  |
