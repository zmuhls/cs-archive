# Oneida County County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 107)

**Extraction Method:** full

**Processed:** 2026-01-01T19:49:20.769582

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 4 | Paris | 1 November 1870 |  | 9 |  |
| 11 | Sangerfield | 12 February 1872 |  | 9 |  |
| 1 | Whitestown | 12 October 1887 |  | 9 |  |
| 3 | Trenton | 25 February 1910 |  | 5 |  |
| 12 | Vernon | 6 May 1913 | 25 June 1913 | 5 |  |
| 4 | New Hartford | 21 April 1913 | 5 May 1913 | 6 |  |
| 8 | New Hartford | 7 October 1913 | 22 October 1913 | 5 |  |
| 8 | Vernon & Oneida | 16 June 1916 |  | 5 |  |
| 4 | Marshall | 1 November 1920 |  | 3 |  |
| 12 | Western | see papers in folder |  |  |  |
| 1 | Trenton | 7 December 1911 |  |  |  |
| 1 | Augusta | see papers in folder |  | 5 |  |
| 4 | Augusta |  |  | 5 |  |
| 3 | Lee | 15 May 1871 |  |  |  |
