# Herkimer County County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 71)

**Extraction Method:** full

**Processed:** 2026-01-01T19:40:56.178011

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Herkimer | 20 January 1865 |  | 3 | Time and result of meeting reed - no details |
| 1 | Webb | 19 January 1909 |  |  |  |
| 1 | Stark | 18 November 1930 | 12 December 1930 | 3 |  |
| 1 | Frankfort | 28 October 1907 |  |  |  |
| 2 | Herkimer | 17 June 1948 |  | 2 | Herkimer |
