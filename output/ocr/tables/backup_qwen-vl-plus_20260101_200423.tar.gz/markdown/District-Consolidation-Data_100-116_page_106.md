# Niagara County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 106)

**Extraction Method:** full

**Processed:** 2026-01-01T19:49:11.392616

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 142 | X Porter | 7 September 1917 | 1 August 1918 | 1 | Newpapers rec'd 429 560 Cad. 2.127635 |
| 45 | Niagara | 14 August 1925 | 22 February 1926 | 4 | Niagara |
|  | Vill. of Lasalle annexed to Niagara Falls | 6 May 1927 | L. 1927 Ch.530 |  | C.R.S. 1 Somermet's Hartland |
|  | E.R.S. | 10 June 1931 | 26 June 1937 |  | Niagara Co. Yale & Ridgeway (Ulane Co.) |
|  | 1 Wilson | 11 June 1941 | 11 July 1941 |  | C.R.S. 1 Wilson, Newfane, Porter & Cambria |
|  | 2 Wilson | 24 June 1941 | 19 July 1941 |  | C.R.S. 1 Newfane + Wilson |
|  | 10 Wilson & Cambria | 12 June 1941 | 25 June 1941 | 1 | Meeting held 25 June 1941 Designation of dist. 19 July 1941 23 March 1942 to take effect 1 July 1942 |
|  | 11 Porter |  |  |  | C.R.S. 1 Porter |
|  | Royalton & Hartland | 7 June 1944 | 29 June 1944 |  | C.R.S. 1 Royalton, Hartland & Lockport Niagara Co. Shell & Ridgway (Albany Co. & Ulster Co.) |
|  | Royalton & Shelley |  | 1 September 1945 |  | C.R.S. 1 Newfane |
|  | Royalton & Lockport |  | 1 September 1945 |  | C.R.S. 1 Newfane |
|  | Royalton & Ridgway |  |  |  | C.R.S. 1 Newfane |
|  | Royalton & Royalton |  |  |  | C.R.S. 1 Newfane |
|  | Newfane |  |  | 3 |  |
|  | Newfane |  |  |  | C.R.S. 1 Newfane |
|  | Newfane |  |  |  | C.R.S. 1 Newfane |
|  | X Sduit & Sliweton | 1 May 1947 | 27 May 1947 |  | Laid out May 1, 1947 Meeting held May 27, 1947 |
|  | X Sduit & Sliweton |  |  |  | C.R.S. 1 Sduit & Sliweton |
|  | X Sduit & Sliweton |  |  |  | C.R.S. 1 Sduit & Sliweton |
|  | X Sduit & Sliweton |  |  |  | C.R.S. 1 Sduit & Sliweton |
|  | X Sduit & Sliweton |  |  |  | C.R.S. 1 Sduit & Sliweton |
|  | X Sduit & Sliweton |  |  |  | C.R.S. 1 Sduit & Sliweton |
|  | X Sduit & Sliweton |  |  |  | C.R.S. 1 Sduit & Sliweton |
|  | X Sduit & Sliweton |  |  |  | C.R.S. 1 Sduit & Sliweton |
|  | X Sduit & Sliweton |  |  |  | C.R.S. 1 Sduit & Sliweton |
|  | X Sduit & Sliweton |  |  |  | C.R.S. 1 Sduit & Sliweton |
|  | X Sduit & Sliweton |  |  |  | C.R.S. 1 Sduit & Sliweton |
|  | Wheatfield cons into City of North Tonawanda effective July 1, 1951 |  |  |  |  |
|  | Lockport and 3 Consolidated into City School district of the City of Lockport effective July 1, 1953 |  |  |  |  |
