# Oneida County

**Table Type:** Town School Units

**Source:** District-Consolidation-Data_100-116.pdf (Page 108)

**Extraction Method:** full

**Processed:** 2026-01-01T19:49:27.918280

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Augusta | U.F.S. 7 | 1910 |  |  |
| 2 | Augusta | 4 | 2.5.6.11.13.14 |  |  |
| 1 | Paris | 4 | 1.2.6.8 |  |  |
| 2 | Paris | 9 | 5.7 |  |  |
| 1 | Trenton | 1 | 4.5.7.9.12 |  |  |
| 2 | Trenton | 2 | 6.11.13 |  |  |
| 3 |  | 3 | 8.10 |  |  |
| 1 | Verona | 1 | 2.4.7.8.12.13.15.16.17.22.25 |  |  |
| 2 | Verona | 11 | 6.9.10.14.18.19.20.21.23.24 |  |  |
| 12 | Western |  | See Folder |  |  |
