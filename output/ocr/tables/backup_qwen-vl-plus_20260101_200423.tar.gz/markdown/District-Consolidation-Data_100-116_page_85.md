# Livingston County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 85)

**Extraction Method:** full

**Processed:** 2026-01-01T19:43:54.767839

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | North Dansville | 26 October 1882 |  | 9 |  |
| 2 | Springwater | 24 August 1903 |  | 9 |  |
| 7 | York | 6 July 1903 |  | 5 |  |
| 9 | Lima | 26 August 1918 |  | 5 |  |
| 4 | Conesus | 9 May 1922 |  | 3 |  |
