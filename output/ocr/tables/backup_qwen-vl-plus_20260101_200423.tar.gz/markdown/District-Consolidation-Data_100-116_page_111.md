# County County

**Table Type:** Consolidated Districts

**Source:** District-Consolidation-Data_100-116.pdf (Page 111)

**Extraction Method:** chunked

**Processed:** 2026-01-01T19:55:28.216079

---

| No. | Town | Date of School-Meeting | Date of Approval | Remarks |
| --- | --- | --- | --- | --- |
| 1 | Paris | 13 June 1938 | 13 Sept 1938 | CRS Paris |
| 2 | Paris | 1 Aug 1938 | 5 Nov 1938 | CRS Northfield |
| 3 | Hartland | 11 Aug 1938 | 11 Nov 1938 | CRS Sangertield |
| 4 | Bromfield | 22 March 1939 | 1 July 1939 | CRS Caledland |
| 5 | Bromfield | 12 June 1940 | 11 Sept 1940 | CRS 2 Paris |
| 6 | Manhall | 29 March 1941 | 1 July 1941 | CRS 1 Sangertield |
| 7 | Rome | 25 March 1941 | 1 July 1941 | CRS 2 Rome |
| 8 | Camden | 12 June 1943 | 12 June 1943 | CRS 1 Camdens, Amnivilly |
| 9 | Camden | 30 June 1943 | 30 June 1943 | Florence, Vinna and Bee, Oneyida Co. |
| 10 | Camden | 12 July 1943 | 12 July 1943 | and Williamstown and Constantia, Orunge Co. |
| 11 | Western | 26 August 1943 | 24 Nov 1943 | CRS 16 Western |
| 12 | Western | 1 Sept 1944 | 1 Sept 1944 | CRS 1 Grennan |
| 12 | Camden | 12 June 1943 | Laid out 12 June 1943 | 10 Camdens, Annville, Florence, Vinna and Bee, Onida Co. and Williamstown and Constantia, Orunge Co. |
|  | Annville | 30 June 1943 | Meeting held 30 June 1943 | Designation of district 12 July 1943 |
| 13 | Annville | 26 August 1943 | To take effect 24 Nov 1943 | 16 Western |
| 14 | Western | 1 Sept 1944 | Laid out 1 Sept 1944 | 1 Western |
| 15 | Austria, Nerkin Co. | 15 Sept 1944 | Laid out 15 Sept 1944 | 1 Trenton |
| 16 | Bonville | 26 June 1945 | Pai out & designated 13 June 1944 | 1 Bonville, Ave. |
|  | Bonville Ave. | 15 July 1945 | Meeting held 30 June 1944 | Oneyda Co + Lyndale, Lake Co. |
| 17 | Bonville Ave. | 9 July 1945 | Effective April 2, 1945 | CRS |
|  | Bonville Ave. | 10 July 1945 | Effective October 1, 1945 | CRS |
|  | Bonville Ave. | 12 July 1945 | Effective February 15, 1946 | 2 Paris |
| 18 | Westen, Ave. of Bonville | 2 June 1946 | Laid out June 10, 1946 | 1 Medium-Middlet |
|  | Westen, Ave. of Bonville | 29 June 1946 | Meeting held June 29, 1946 | 1 Rutherford |
| 19 | New Hartford | 2 June 1946 |  | CRS |
|  | New Hartford | 29 June 1946 |  | CRS |
| 20 | New Hartford | 8 June 1946 |  | CRS |
|  | New Hartford | 29 June 1946 |  | CRS |
| 21 | New Hartford | 8 June 1946 |  | CRS |
|  | New Hartford | 29 June 1946 |  | CRS |
| 22 | New Hartford | 8 June 1946 |  | CRS |
|  | New Hartford | 29 June 1946 |  | CRS |
| 23 | New Hartford | 8 June 1946 |  | CRS |
|  | New Hartford | 29 June 1946 |  | CRS |
| 24 | New Hartford | 8 June 1946 |  | CRS |
|  | New Hartford | 29 June 1946 |  | CRS |
| 11 | Western | 26 Aug 1943 | 24 Nov 1943 | 16 Western |
| 12 | Annville | 26 Aug 1943 | 24 Nov 1943 | 16 Western |
| 13 | Annville | 26 Aug 1943 | 24 Nov 1943 | 16 Western |
| 14 | Annville | 26 Aug 1943 | 24 Nov 1943 | 16 Western |
| 15 | Annville | 26 Aug 1943 | 24 Nov 1943 | 16 Western |
| 16 | Annville | 26 Aug 1943 | 24 Nov 1943 | 16 Western |
| 17 | Annville | 26 Aug 1943 | 24 Nov 1943 | 16 Western |
| 18 | Annville | 26 Aug 1943 | 24 Nov 1943 | 16 Western |
| 19 | Annville | 26 Aug 1943 | 24 Nov 1943 | 16 Western |
| 20 | Annville | 26 Aug 1943 | 24 Nov 1943 | 16 Western |
| 21 | Annville | 26 Aug 1943 | 24 Nov 1943 | 16 Western |
| 37 | Hornell | 26 Aug 1943 | 24 Nov 1943 | 16 Western |
| 38 |   |   |   | C.R.S. |
| 39 |   |   | 1 Sept 1944 | Grennan |
| 40 |   |   | 15 Sept 1944 | 1 Trenton |
| 41 | Bonville | 26 June 1943 |   | C.R.S. |
| 42 |   | 15 July 1943 |   | Bonville, Ave. |
| 43 |   | 10 Aug 1943 |   | Oreida Co. + Lymndale |
| 44 |   | 1943 |   | Lymndale, Luneo |
| 45 |   |   |   | Western + Shufeld |
| 46 |   |   |   | C.R.S. |
| 47 |   |   |   | Western + Shufeld |
| 48 |   |   |   | C.R.S. |
| 11 | Western | 26 August 1943 to take effect 24 Nov 1943 |  | 16 Western |
| 12 | America, Nerkin Co. | 1 Sept 1944 |  | 1 Grennan |
| 13 | Breckton | 15 Sept 1944 |  | 1 Trenton |
| 2 | Bonville | 26 June 1946 |  | 1 Bonville, Ave. |
| 3 | Bonville Ave. | 15 Sept 1944 |  | 1 Bonville, Ave. |
| 4 | Bonville |  |  | 1 Bonville, Ave. |
| 5 | Bonville | 10 June 1944 |  | 1 Bonville, Ave. |
| 6 | Bonville | 10 June 1944 |  | 1 Bonville, Ave. |
| 7 | Bonville | 26 June 1946 |  | 1 Bonville, Ave. |
| 8 | Bonville | 26 June 1946 |  | 1 Bonville, Ave. |
| 1 | Weston | 26 August 1943 | 24 November 1943 | 16 Weston |
| 10 | Austria | 1 September 1944 |  | 10 Austria |
| 13 | Schenectady | 15 September 1944 |  | 1 Schenectady |
| 2 | Bonville | 26 June 1943 | 13 June 1944 | 11 Bonville, Ave. |
| 3 | Bonville Ave. | 15 September 1944 |  | 10 Bonville, Ave. |
| 4 | Bonville | 10 September 1944 |  | 10 Bonville |
| 5 | Bonville | 15 September 1944 |  | 10 Bonville |
| 6 | Bonville | 15 September 1944 |  | 10 Bonville |
| 7 | Bonville | 15 September 1944 |  | 10 Bonville |
| 8 | Bonville | 15 September 1944 |  | 10 Bonville |
| 9 | Bonville | 15 September 1944 |  | 10 Bonville |
| 10 | Bonville | 15 September 1944 |  | 10 Bonville |
| 2 | Paris | 13 June 1938 | 13 Sept 1938 | CRS 2 Paris |
| 2 | Paris | 1 Aug. 1938 | 5 Nov. 1938 | CRS 2 Paris |
| 1 | Hartland | 11 Aug. 1938 | 11 Nov. 1938 | CRS 1 Hartland |
| 10 | Fourport | 22 March 1939 | 1 July 1939 | CRS 10 Fourport |
| 2 | Paris | 12 June 1940 | 11 Sept. 1940 | CRS 2 Paris |
| 1 | Sanginfield | 29 March 1941 | 1 July 1941 | CRS 1 Sanginfield |
| 2 | Rome | 25 March 1941 | 1 July 1941 | CRS 2 Rome |
| 1 | Camden | Laid out 12 June 1943 | Meeting held 30 June 1943 | CRS 1 Camdens, Annivilly, Florence, Vinna and Bee, Oreida Co. and Williamstown and Constantia, Orange Co. |
| 12 | Annville | 12 July 1943 | Designation of district 12 July 1943 |  |
| 11 | Western | 26 August 1943 | 24 Nov. 1943 | CRS 16 Western |
| 16 | Western | 1 Sept. 1944 | 1 Sept. 1944 | CRS 16 Western |
| 1 | Trenton | 15 Sept. 1944 | 15 Sept. 1944 | CRS 1 Trenton |
| 1 | Bonville | 26 June 1944 | 13 June 1944 | CRS 1 Bonville, Ave. Oreida Co. and Lyndale, Luneau |
| 3 | Bonville | 15 Sept. 1944 | 15 Sept. 1944 | CRS 3 Bonville |
| 40 | Bonville | Laid out 30 June 1944 | Meeting held 30 June 1944 | CRS 40 Bonville |
| 8 | Bonville | 9 July 1945 | Effective April 2, 1945 | CRS 8 Bonville |
| 3 | Bonville | 1 Oct. 1945 | Effective Oct. 1, 1945 | CRS 3 Bonville |
| 3 | Bonville | 15 Feb. 1946 | Effective Feb. 15, 1946 | CRS 3 Bonville |
| 7 | New Hartford | Laid out June 10, 1946 | Meeting held June 29, 1946 | CRS 1 New Hartford |
| 7 | New Hartford | 12 Kirklund |  | CRS 7 New Hartford |
| 7 | Venner | Laid out May 26, 1950 | Meeting held June 21, 1950 | City School district of the City of Sherill |
| 7 | Venner | 15 June 1950 | 15 June 1950 | CRS 7 Venner |
| 7 | Venner | 15 June 1950 | 15 June 1950 | CRS 7 Venner |
| 7 | Venner | 15 June 1950 | 15 June 1950 | CRS 7 Venner |
| 7 | Venner | 15 June 1950 | 15 June 1950 | CRS 7 Venner |
| 7 | Venner | 15 June 1950 | 15 June 1950 | CRS 7 Venner |
| 85 | Weston | 15 Sept. 1944 | 15 Sept. 1944 | 16 Weston |
| 86 | Weston | 15 Sept. 1944 | 15 Sept. 1944 | 16 Weston |
| 87 | Weston | 15 Sept. 1944 | 15 Sept. 1944 | 16 Weston |
| 88 | Weston | 15 Sept. 1944 | 15 Sept. 1944 | 16 Weston |
| 89 | Weston | 15 Sept. 1944 | 15 Sept. 1944 | 16 Weston |
| 90 | Weston | 15 Sept. 1944 | 15 Sept. 1944 | 16 Weston |
| 91 | Weston | 15 Sept. 1944 | 15 Sept. 1944 | 16 Weston |
| 92 | Weston | 15 Sept. 1944 | 15 Sept. 1944 | 16 Weston |
| 93 | Weston | 15 Sept. 1944 | 15 Sept. 1944 | 16 Weston |
| 94 | Weston | 15 Sept. 1944 | 15 Sept. 1944 | 16 Weston |
| 95 | Weston | 15 Sept. 1944 | 15 Sept. 1944 | 16 Weston |
| 96 | Weston | 15 Sept. 1944 | 15 Sept. 1944 | 16 Weston |
| 11 | Western | 15 Sept. 1944 | 15 Sept. 1944 | 16 Western |
| 12 | Austin | 5 June 1945 | 5 June 1945 |  |
| 13 | Brockton | 26 June 1945 | 26 June 1945 |  |
| 14 | Bonville | 24 June 1947 | 24 June 1947 | 11 Bonville, Ave. |
| 15 | Bonville | 15 June 1947 | 15 June 1947 |  |
| 16 | Bonville | 15 June 1947 | 15 June 1947 |  |
| 17 | Bonville | 15 June 1947 | 15 June 1947 |  |
| 18 | Bonville | 15 June 1947 | 15 June 1947 |  |
| 19 | Bonville | 15 June 1947 | 15 June 1947 |  |
| 20 | Bonville | 15 June 1947 | 15 June 1947 |  |
| 109 | Western | 26 August 1943 | 24 Nov 1943 | 16 Western |
| 110 |  |  | 1 Sept 1944 | 1 German |
| 111 |  |  | 15 Sept 1944 | 1 Trenton |
| 112 | Bonville | 24 June 1943 |  | 1 Bonville, Ave |
| 113 | Bonville Ave | 15 June 1943 |  | Oreida Co. + Lyndale |
| 114 | Bonville |  |  | Lyndale, Lake Co. |
| 115 | Western, Ave of Bonville | 10 June 1943 |  | Western & Southfie |
| 116 | Bonville | 10 June 1943 |  | CRS |
| 117 | Western | 9 June 1943 |  | CRS |
| 118 | New Hartford | June 10, 1946 | June 27, 1946 | 1 New Hartford |
| 119 | Vernon | May 26, 1940 | June 21, 1940 | City School district of the City of Sherill |
| 120 | Vernon | 15 June 1940 |  | City of Sherill |
| 11 | Western | 12.3.4.1917 | 1 Sept 1917 | 16 Western |
| 16 | Glovers | 26 Aug 1918 | 26 Aug 1918 |  |
| 17 | Bonville | 24.6.8.10.1919 | 15 Sept 1919 | 11 Bonville |
| 18 | Bonville | 10.11.1919 | Laid out 13 June 1920 |  |
| 19 | Bonville | 10.11.1919 | Laid out 13 June 1920 |  |
| 20 | Bonville | 10.11.1919 | Laid out 13 June 1920 |  |
| 21 | Bonville | 10.11.1919 | Laid out 13 June 1920 |  |
| 22 | Bonville | 10.11.1919 | Laid out 13 June 1920 |  |
| 23 | Bonville | 10.11.1919 | Laid out 13 June 1920 |  |
| 24 | Bonville | 10.11.1919 | Laid out 13 June 1920 |  |
| 25 | Bonville | 10.11.1919 | Laid out 13 June 1920 |  |
| 26 | Bonville | 10.11.1919 | Laid out 13 June 1920 |  |
| 133 | Western | 26 Aug 1943 | 24 Nov 1943 | 16 Western |
| 134 |  |  | 1 Sept 1944 | 1 Germain |
| 135 |  |  | 15 Sept 1944 | 1 Trenton |
| 136 | Bonville | 26 June 1944 | 12 July 1944 | 1 Bonville, Ave |
| 137 |  | 12 July 1944 | 13 June 1944 |  |
| 138 |  | 12 July 1944 | 13 June 1944 |  |
| 139 | Bonville Ave | 15 June 1944 | 13 June 1944 |  |
| 140 |  | 15 June 1944 | 13 June 1944 |  |
| 141 | Western, Ave of Bonville | 10 June 1944 | 13 June 1944 |  |
| 142 | Burlington, Westland Bonville | 10 June 1944 | 13 June 1944 |  |
| 143 | Ave of Western | 10 June 1944 | 13 June 1944 |  |
| 144 | Western - Medford | 10 June 1944 | 13 June 1944 |  |
| 145 | Weston | 26 August 1943 | 24 Nov 1943 | 16 Weston |
| 146 | Weston | 1 Sept 1944 | 1 Sept 1944 | 10 Weston |
| 147 | Weston | 15 Sept 1944 | 15 Sept 1944 | 1 Trenton |
| 148 | Bonville | 26 June 1943 | 26 June 1943 | 1 Bonville, Ave |
| 149 | Bonville | 15 June 1943 | 15 June 1943 | 2 Bonville |
| 150 | Bonville | 10 June 1943 | 10 June 1943 | 3 Bonville |
| 151 | Bonville | 11 June 1943 | 11 June 1943 | 4 Bonville |
| 152 | Bonville | 12 June 1943 | 12 June 1943 | 5 Bonville |
| 153 | Bonville | 13 June 1943 | 13 June 1943 | 6 Bonville |
| 154 | Bonville | 14 June 1943 | 14 June 1943 | 7 Bonville |
| 155 | Bonville | 15 June 1943 | 15 June 1943 | 8 Bonville |
| 156 | Bonville | 16 June 1943 | 16 June 1943 | 9 Bonville |
| 157 | New Hartford | 2 June 1946 | 10 June 1946 | Laid out 2 June 1946 Meeting held 29 June 1946 |
| 158 | New Hartford | 2 June 1946 | 10 June 1946 | Meeting held 29 June 1946 |
| 159 | New Hartford | 2 June 1946 | 10 June 1946 | CRS |
| 160 | New Hartford | 2 June 1946 | 10 June 1946 | Laid out 2 June 1946 Meeting held 29 June 1946 |
| 161 | New Hartford | 2 June 1946 | 10 June 1946 | Meeting held 29 June 1946 |
| 162 | New Hartford | 2 June 1946 | 10 June 1946 | CRS |
| 163 | New Hartford | 2 June 1946 | 10 June 1946 | Laid out 2 June 1946 Meeting held 29 June 1946 |
| 164 | New Hartford | 2 June 1946 | 10 June 1946 | Meeting held 29 June 1946 |
| 165 | New Hartford | 2 June 1946 | 10 June 1946 | CRS |
| 166 | New Hartford | 2 June 1946 | 10 June 1946 | Laid out 2 June 1946 Meeting held 29 June 1946 |
| 167 | New Hartford | 2 June 1946 | 10 June 1946 | Meeting held 29 June 1946 |
| 168 | New Hartford | 2 June 1946 | 10 June 1946 | CRS |
| 11 | Western | 26 August 1943 to take effect 24 Nov 1943 | 1 Sept 1944 | 16 Western CRS |
| 12 | Western | 24 June 1943 | 15 Sept 1944 | 1 Trenton CRS |
| 13 | Austria | 10 June 1943 | 15 Sept 1944 | 1 Bonnville, Ave. Oreida Co. + Lyndale, Lyndale CRS |
| 14 | Brockton | 10 June 1943 |  | Brockton CRS |
| 15 | Brockton | 10 June 1943 |  | Brockton CRS |
| 16 | Brockton | 10 June 1943 |  | Brockton CRS |
| 17 | Brockton | 10 June 1943 |  | Brockton CRS |
| 18 | Brockton | 10 June 1943 |  | Brockton CRS |
| 19 | Brockton | 10 June 1943 |  | Brockton CRS |
| 20 | Brockton | 10 June 1943 |  | Brockton CRS |
| 21 | Brockton | 10 June 1943 |  | Brockton CRS |
| 22 | Brockton | 10 June 1943 |  | Brockton CRS |
| 23 | Brockton | 10 June 1943 |  | Brockton CRS |
| 24 | Brockton | 10 June 1943 |  | Brockton CRS |
| 25 | Brockton | 10 June 1943 |  | Brockton CRS |
| 26 | Brockton | 10 June 1943 |  | Brockton CRS |
| 27 | Brockton | 10 June 1943 |  | Brockton CRS |
| 28 | Brockton | 10 June 1943 |  | Brockton CRS |
| 29 | Brockton | 10 June 1943 |  | Brockton CRS |
| 30 | Brockton | 10 June 1943 |  | Brockton CRS |
| 181 | Weston | 26 Aug 1943 | 24 Nov 1943 | 16 |
| 182 | Weston | 1 Sept 1944 |  | 1 |
| 183 | Weston | 15 Sept 1944 |  | 1 |
| 184 | Bonville | 26 June 1943 | 13 June 1944 | 1 |
| 185 | Bonville | 10 June 1943 |  | 1 |
| 186 | Bonville | 11 June 1943 |  | 1 |
| 187 | Bonville | 15 June 1943 |  | 1 |
| 188 | Bonville | 19 June 1943 |  | 1 |
| 189 | Bonville | 20 June 1943 |  | 1 |
| 190 | Bonville | 23 June 1943 |  | 1 |
| 191 | Bonville | 27 June 1943 |  | 1 |
| 192 | Bonville | 29 June 1943 |  | 1 |
| 11 | Western | 26 August 1943 | 24 November 1943 | 16 Western |
| 12 | Western |  |  | 16 Western |
| 13 | Austria | 1 September 1944 |  | 1 German |
| 14 | Brockton | 15 September 1944 |  | 1 Trenton |
| 15 | Bonville | 26 June 1943 | 10 October 1943 | 1 Bonville, Ave |
| 16 | Bonville | 15 June 1943 | 15 June 1943 | 1 Bonville, Ave |
| 17 | Bonville | 19 June 1943 | 19 June 1943 | 1 Bonville, Ave |
| 18 | Bonville | 19 June 1943 | 19 June 1943 | 1 Bonville, Ave |
| 19 | Bonville | 19 June 1943 | 19 June 1943 | 1 Bonville, Ave |
| 20 | Bonville | 19 June 1943 | 19 June 1943 | 1 Bonville, Ave |
| 21 | Bonville | 19 June 1943 | 19 June 1943 | 1 Bonville, Ave |
| 22 | Bonville | 19 June 1943 | 19 June 1943 | 1 Bonville, Ave |
| 23 | Bonville | 19 June 1943 | 19 June 1943 | 1 Bonville, Ave |
| 24 | Bonville | 19 June 1943 | 19 June 1943 | 1 Bonville, Ave |
| 25 | Bonville | 19 June 1943 | 19 June 1943 | 1 Bonville, Ave |
| 26 | Bonville | 19 June 1943 | 19 June 1943 | 1 Bonville, Ave |
| 27 | Bonville | 19 June 1943 | 19 June 1943 | 1 Bonville, Ave |
| 28 | Bonville | 19 June 1943 | 19 June 1943 | 1 Bonville, Ave |
| 29 | Bonville | 19 June 1943 | 19 June 1943 | 1 Bonville, Ave |
| 30 | Bonville | 19 June 1943 | 19 June 1943 | 1 Bonville, Ave |
| 205 | Bonville | 26 June 1910 | 15 September 1910 | 16 Western |
| 206 | Bonville | 3 June 1911 | 1 September 1911 | 16 Western |
| 207 | Bonville | 10 June 1911 | 1 September 1911 | 16 Western |
| 208 | Bonville | 11 June 1911 | 1 September 1911 | 16 Western |
