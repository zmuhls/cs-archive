# Erie County

**Table Type:** Union Free Schools

**Source:** District-Consolidation-Data_100-116.pdf (Page 50)

**Extraction Method:** full

**Processed:** 2026-01-01T19:36:41.764008

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 8 | Hamburg | 12 March 1903 |  | 5 |  |
| 3 | Newstead | 18 December 1883 |  |  |  |
| 3 | West Seneca | 24 September 1912 | 23 September 1913 | 7 |  |
| 13 | Hamburg | 27 August 1920 |  | 5 |  |
| 3 | Collins | 1 August 1923 |  | 5 |  |
| 1 | Evans | 12 July 1923 |  | 7 |  |
| 1 | West Seneca | 25 March 1925 |  | 5 |  |
| 2 | Hamburg | 14 November 1897 |  |  |  |
| 11 | Cheektowaga | 31 May 1932 |  |  |  |
| 6 | Evans | see paper in folder |  |  |  |
| 3 | Evans Eden | 24 May 1937 | 9 July 1937 |  |  |
| 10 | Cheektowaga | 30 August 1940 | 24 October 1940 |  |  |
| 2 | Clarence Amherst | 19 June 1942 | 18 September 1942 | 5 |  |
| 4 | Cheektowaga | 28 November 1945 | 11 January 1946 |  |  |
| 5 | West Seneca | 29 November 1945 | 29 November 1945 | 1445 |  |
| .2 | Cheektowaga | 29 March 1949 | 25 April 1949 | 1449 |  |
