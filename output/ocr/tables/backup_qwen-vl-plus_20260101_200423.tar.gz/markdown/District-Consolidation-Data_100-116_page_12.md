# Cayuga County

**Table Type:** Town School Units

**Source:** District-Consolidation-Data_100-116.pdf (Page 12)

**Extraction Method:** full

**Processed:** 2026-01-01T16:29:09.883338

---

| n | town | date_org | date_appr | n_new | rmk |
| --- | --- | --- | --- | --- | --- |
| 1 | Genoa | U.F.S. 2 and 10, 11 & 12 Genoa |  |  |  |
| 2 | Genoa | U.F.S. 6 and 5, 8, 9 & 13 Genoa |  |  |  |
